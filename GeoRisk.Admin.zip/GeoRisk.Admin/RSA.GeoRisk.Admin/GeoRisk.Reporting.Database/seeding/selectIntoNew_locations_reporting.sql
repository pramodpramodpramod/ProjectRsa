﻿USE [GLOBAL_EXPOSURE]
	GO
	
	SET ANSI_NULLS ON
	GO

	SET QUOTED_IDENTIFIER ON
	GO

	--CREATE view [dbo].[locations_vw_currency] 
	--as 
	select 
		l.ObjectID, 
		b.batchID,
		b.Description batchDescription,
		p.producingOperation prodOpShort,
		po.Value producingOperation, 
		lob.Value lineOfbusiness, 
		ps.Value policySystem, 
		p.policyNumber, 
		p.nameOfInsured, 
		ly2.grossPremiumSum, 
		--ly.rsaShare * 100 as rsaShare,  
		--ly.grossPremium,
		l.locationEffectiveDate, 
		l.locationDeletionDate, 
		l.localClientName, 
		l.hazardCategory,                 
		--CASE 

		--        WHEN l.netTotalSumInsured IS NULL THEN 0 
		--        WHEN l.currency = 'CAD' THEN l.netTotalSumInsured 
		--        ELSE Round(Cast((l.netTotalSumInsured * cuc.Rate) as numeric(19,2)), 2) 
		--END [netTotalSumInsuredCAD], 
		--CASE 

		--        WHEN l.netTotalSumInsured IS NULL THEN 0 
		--        WHEN l.currency = 'USD' THEN l.netTotalSumInsured 
		--        ELSE Round(Cast((l.netTotalSumInsured * cus.Rate) as numeric(19,2)), 2) 
		--END [netTotalSumInsuredUSD], 
		--CASE 

		--        WHEN l.netTotalSumInsured IS NULL THEN 0 
		--        WHEN l.currency = 'EUR' THEN l.netTotalSumInsured 
		--        ELSE Round(Cast((l.netTotalSumInsured * cue.Rate) as numeric(19,2)), 2) 
		--END [netTotalSumInsuredEUR], 
		CASE 

				WHEN l.netTotalSumInsured IS NULL THEN 0 
				WHEN l.currency = 'GBP' THEN l.netTotalSumInsured 
				ELSE Round(Cast((l.netTotalSumInsured * cub.Rate) as numeric(19,2)), 2) 
		END [netTotalSumInsuredGBP], 
		--CASE 

		--        WHEN l.netTotalSumInsured IS NULL THEN 0 
		--        ELSE Round(l.netTotalSumInsured, 2) 
		--END [netTotalSumInsured],         
		--CASE 

		--        WHEN l.grossTotalSumInsured IS NULL THEN 0 
		--        WHEN l.currency = 'CAD' THEN l.grossTotalSumInsured 
		--        ELSE Round(Cast((l.grossTotalSumInsured * cuc.Rate) as numeric(19,2)), 2) 
		--END [grossTotalSumInsuredCAD], 
		--CASE 

		--        WHEN l.grossTotalSumInsured IS NULL THEN 0 
		--        WHEN l.currency = 'USD' THEN l.grossTotalSumInsured 
		--        ELSE Round(Cast((l.grossTotalSumInsured * cus.Rate) as numeric(19,2)), 2) 
		--END [grossTotalSumInsuredUSD], 
		--CASE 

		--        WHEN l.grossTotalSumInsured IS NULL THEN 0 
		--        WHEN l.currency = 'EUR' THEN l.grossTotalSumInsured 
		--        ELSE Round(Cast((l.grossTotalSumInsured * cue.Rate) as numeric(19,2)), 2) 
		--END [grossTotalSumInsuredEUR], 
		CASE 

				WHEN l.grossTotalSumInsured IS NULL THEN 0 
				WHEN l.currency = 'GBP' THEN l.grossTotalSumInsured 
				ELSE Round(Cast((l.grossTotalSumInsured * cub.Rate) as numeric(19,2)), 2) 
		END [grossTotalSumInsuredGBP], 
		--CASE 
		--        WHEN l.grossTotalSumInsured IS NULL THEN 0 
		--        ELSE Round(l.grossTotalSumInsured, 2) 
		--END [grossTotalSumInsured], 
		--CASE 

		--        WHEN l.netEstimatedMaximumLoss IS NULL THEN 0 
		--        WHEN l.currency = 'CAD' THEN l.netEstimatedMaximumLoss 
		--        ELSE Round(Cast((l.netEstimatedMaximumLoss * cuc.Rate) as numeric(19,2)), 2) 
		--END [netEstimatedMaximumLossCAD], 
		--CASE 

		--        WHEN l.netEstimatedMaximumLoss IS NULL THEN 0 
		--        WHEN l.currency = 'USD' THEN l.netEstimatedMaximumLoss 
		--        ELSE Round(Cast((l.netEstimatedMaximumLoss * cus.Rate) as numeric(19,2)), 2) 
		--END [netEstimatedMaximumLossUSD], 
		--CASE 

		--        WHEN l.netEstimatedMaximumLoss IS NULL THEN 0 
		--        WHEN l.currency = 'EUR' THEN l.netEstimatedMaximumLoss 
		--        ELSE Round(Cast((l.netEstimatedMaximumLoss * cue.Rate) as numeric(19,2)), 2) 
		--END [netEstimatedMaximumLossEUR], 
		CASE 

				WHEN l.netEstimatedMaximumLoss IS NULL THEN 0 
				WHEN l.currency = 'GBP' THEN l.netEstimatedMaximumLoss 
				ELSE Round(Cast((l.netEstimatedMaximumLoss * cub.Rate) as numeric(19,2)), 2) 
		END [netEstimatedMaximumLossGBP], 
		--CASE 

		--        WHEN l.netEstimatedMaximumLoss IS NULL THEN 0 
		--        ELSE Round(l.netEstimatedMaximumLoss, 2) 
		--END [netEstimatedMaximumLoss], 
		--CASE 

		--        WHEN l.grossEstimatedMaximumLoss IS NULL THEN 0 
		--        WHEN l.currency = 'CAD' THEN l.grossEstimatedMaximumLoss 
		--        ELSE Round(Cast((l.grossEstimatedMaximumLoss * cuc.Rate) as numeric(19,2)), 2) 
		--END [grossEstimatedMaximumLossCAD], 
		--CASE 

		--        WHEN l.grossEstimatedMaximumLoss IS NULL THEN 0 
		--        WHEN l.currency = 'USD' THEN l.grossEstimatedMaximumLoss 
		--        ELSE Round(Cast((l.grossEstimatedMaximumLoss * cus.Rate) as numeric(19,2)), 2) 
		--END [grossEstimatedMaximumLossUSD], 
		--CASE 

		--        WHEN l.grossEstimatedMaximumLoss IS NULL THEN 0 
		--        WHEN l.currency = 'EUR' THEN l.grossEstimatedMaximumLoss 
		--        ELSE Round(Cast((l.grossEstimatedMaximumLoss * cue.Rate) as numeric(19,2)), 2) 
		--END [grossEstimatedMaximumLossEUR], 
		CASE 

				WHEN l.grossEstimatedMaximumLoss IS NULL THEN 0 
				WHEN l.currency = 'GBP' THEN l.grossEstimatedMaximumLoss 
				ELSE Round(Cast((l.grossEstimatedMaximumLoss * cub.Rate) as numeric(19,2)), 2) 
		END [grossEstimatedMaximumLossGBP], 
		--CASE 

		--        WHEN l.grossEstimatedMaximumLoss IS NULL THEN 0 
		--        ELSE Round(l.grossEstimatedMaximumLoss, 2) 
		--END [grossEstimatedMaximumLoss], 
		cu.Value currency, 
		--CASE 
		--	WHEN supa.wholeAddress IS NULL
		--	THEN ltrim(rtrim(ISNULL(supa.subBuildingRef,'') + ' ' + ISNULL(supa.buildingNumber,'') + ' ' + ISNULL(supa.buildingName,'') + ' ' + ISNULL(supa.streetName,'')  + ' ' + ISNULL(supa.district,'') + ' ' + ISNULL(supa.city,'')  + ' ' + ISNULL(supa.postalCode,'')  + ' ' + ISNULL(supa.subRegion,'') + ' ' + ISNULL(supa.region,'')))
		--	ELSE supa.wholeAddress
		--END supBestAddress,
		--CASE
		--	WHEN sysa.wholeAddress IS NULL
		--	THEN ltrim(rtrim(ISNULL(sysa.subBuildingRef,'') + ' ' + ISNULL(sysa.buildingNumber,'') + ' ' + ISNULL(sysa.buildingName,'') + ' ' + ISNULL(sysa.streetName,'')  + ' ' + ISNULL(sysa.district,'') + ' ' + ISNULL(sysa.city,'')  + ' ' + ISNULL(sysa.postalCode,'')  + ' ' + ISNULL(sysa.subRegion,'') + ' ' + ISNULL(sysa.region,'')))
		--	ELSE sysa.wholeAddress
		--END sysBestAddress,
		--CASE
		--	WHEN l.bestAddressType = 'SYS' THEN
		--		CASE
		--			WHEN sysa.wholeAddress IS NULL
		--			THEN ltrim(rtrim(ISNULL(sysa.subBuildingRef,'') + ' ' + ISNULL(sysa.buildingNumber,'') + ' ' + ISNULL(sysa.buildingName,'') + ' ' + ISNULL(sysa.streetName,'')  + ' ' + ISNULL(sysa.district,'') + ' ' + ISNULL(sysa.city,'')  + ' ' + ISNULL(sysa.postalCode,'')  + ' ' + ISNULL(sysa.subRegion,'') + ' ' + ISNULL(sysa.region,'')))
		--			ELSE sysa.wholeAddress
		--		END
		--	WHEN l.bestAddressType = 'SUP' THEN
		--		CASE 
		--			WHEN supa.wholeAddress IS NULL
		--			THEN ltrim(rtrim(ISNULL(supa.subBuildingRef,'') + ' ' + ISNULL(supa.buildingNumber,'') + ' ' + ISNULL(supa.buildingName,'') + ' ' + ISNULL(supa.streetName,'')  + ' ' + ISNULL(supa.district,'') + ' ' + ISNULL(supa.city,'')  + ' ' + ISNULL(supa.postalCode,'')  + ' ' + ISNULL(supa.subRegion,'') + ' ' + ISNULL(supa.region,'')))
		--			ELSE supa.wholeAddress
		--		END
		--END
		ltrim(rtrim(ISNULL(la.subBuildingRef,'') + ' ' + ISNULL(la.buildingNumber,'') + ' ' + ISNULL(la.buildingName,'') + ' ' + ISNULL(la.streetName,'')  + ' ' + ISNULL(la.district,'') + ' ' + ISNULL(la.city,'')  + ' ' + ISNULL(la.postalCode,'')  + ' ' + ISNULL(la.subRegion,'') + ' ' + ISNULL(la.region,''))) 
		bestAddress,
		la.country countryA2,
		cou.Value country, 
		CASE 
			WHEN ga.Value IS NULL 
			THEN '' 
			ELSE ga.Value 
		END geocodeAccuracy, 
		CASE 
			WHEN gs.Value IS NULL 
			THEN '' 
			ELSE gs.Value 
		END geocodeSource, 
		at.Value addressType, 
		l.uniqueLocationIdentifier, 
		l.Shape 
	into [Reporting].[dbo].[locations_reporting]
	from 
		dbo.POLICY p 
	left outer join 
		dbo.BatchProcessJob bpj 
		--below, the column p.BatchProcessJobID is nullable, hence we must do a left outer join, otherwise we risk losing records
		on p.BatchProcessJobID = bpj.ObjectID 
	CROSS APPLY
	(
		SELECT  Sum(ly.grossPremium) as grossPremiumSum
		FROM    dbo.POLICYLAYER ly
		WHERE   p.[ObjectID] = ly.FK_POLICY_ObjectID
	) ly2
	--LEFT OUTER JOIN 
	--    dbo.POLICYLAYER ly 
	--	--below, the column p.producingOperation is non-null, but we restrict return values with a 'PRIMARY' search term, 
	--	--hence we cannot do a join, and must do a left outer join
	--    ON p.ObjectID = ly.FK_POLICY_ObjectID 
	--    AND ly.layerIdentifier = 'PRIMARY'   
	LEFT OUTER JOIN 
		dbo.Batch b
		--below bpj.FK_Batch_BatchID is nullable, hence we must do a left outer join, otherwise we risk losing records
		ON bpj.FK_Batch_BatchID = b.BatchID
	join 
		dbo.Lookup_ProducingOperation po 
		--below, the column p.producingOperation is non-null, hence we can do a join, rather than a left outer join
		on p.producingOperation = po.Code 
	join 
		dbo.Lookup_LineOfBusiness lob 
		--below, the column p.lineOfBusiness is non-null, hence we can do a join, rather than a left outer join
		on p.lineOfBusiness = lob.Code 
	join 
		dbo.Lookup_PolicySystem ps 
		--below, the column p.policySystem is non-null, hence we can do a join, rather than a left outer join
		on p.policySystem = ps.code 
	--this is an inner join, because we only want to include locations matching with policies
	join 
		dbo.LOCATION l 
		on p.ObjectID = l.FK_POLICY_ObjectID 
	JOIN
		dbo.LOCATIONADDRESS la 
		--below, the column l.ObjectID is non-null, and l.bestAddressType is a foreign key hence there will
		--always be a match to join on - we can do a join, rather than a left outer join
		on l.ObjectID = la.FK_LOCATION_ObjectID 
		and l.bestAddressType = la.addressType 
	--this needs to be a left outer join because it could be a null value in the supa table
	--LEFT OUTER JOIN 
	--	(	SELECT * 
	--		FROM dbo.LOCATIONADDRESS 
	--		WHERE addressType = 'SUP'
	--	)	as supa
	--	ON l.ObjectID = supa.FK_LOCATION_ObjectID
	----this needs to be a left outer join because it could be a null value in the sysa table
	--LEFT OUTER JOIN 
	--	(	SELECT * 
	--		FROM dbo.LOCATIONADDRESS 
	--		WHERE addressType = 'SYS'
	--	)	as sysa
	--	ON l.ObjectID = sysa.FK_LOCATION_ObjectID
	join 
		dbo.Lookup_AddressType at 
		--below, the column la.addressType is non-null, hence we can do a join, rather than a left outer join
		on la.addressType = at.code 
	join 
		dbo.Lookup_Currency cu 
		--below, the column l.currency is non-null, hence we can do a join, rather than a left outer join
		on l.currency = cu.Code 
	--left outer join 
	--    dbo.CURRENCYRATES cus 
	--    ON   
	--            cus.CurrFrom = l.currency 
	--    AND 
	--            cus.CurrTo = 'USD'         
	left outer join 
		dbo.CURRENCYRATES cub 
		ON 
				cub.CurrFrom = l.currency 
		AND 
				cub.CurrTo = 'GBP' 
	--left outer join 
	--    dbo.CURRENCYRATES cue 
	--    ON 
	--            cue.CurrFrom = l.currency 
	--    AND 
	--            cue.CurrTo = 'EUR' 
	--left outer join 
	--    dbo.CURRENCYRATES cuc 
	--    ON 
	--            cuc.CurrFrom = l.currency 
	--    AND 
	--            cuc.CurrTo = 'CAD' 
	left outer join 
		dbo.Lookup_GeocodeAccuracy ga
		--below, the column la.geocodeAccuracy is nullable, hence we must do a left outer join, otherwise we risk losing records
		on la.geocodeAccuracy = ga.Code 
	left outer join 
		dbo.Lookup_GeocodeSource gs 
		--below, the column la.geocodeSource is nullable, hence we must do a left outer join, otherwise we risk losing records
		on la.geocodeSource = gs.Code 
	join 
		dbo.Lookup_Country cou 
		--below, the column la.country is a non-nullable FK, hence we can do a join
		on la.country = cou.Code 
	WHERE   
		( 

				bpj.JobStatus = 'Live' 
		OR 
				( 


						bpj.JobStatus is null 
				and 
						l.live = 1 
				) 
		) 
	GO