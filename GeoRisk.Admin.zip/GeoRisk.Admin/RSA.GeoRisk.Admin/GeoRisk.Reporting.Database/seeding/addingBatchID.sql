﻿/****** Script for SelectTopNRows command from SSMS  ******/

SET XACT_ABORT, NOCOUNT ON
	
	BEGIN TRY
		BEGIN TRANSACTION
		
		Use [Reporting]
		
		CREATE TABLE [dbo].[BusinessArea](
			[Id] [int] IDENTITY(1,1) NOT NULL,
			[Name] [nvarchar](100) NULL,
			[DisplayName] [nvarchar](50) NULL,
		PRIMARY KEY CLUSTERED 
		(
			[Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		
		SET IDENTITY_INSERT [dbo].[BusinessArea] ON

		INSERT INTO [dbo].[BusinessArea]
				   ([Id],[Name]
				   ,[DisplayName])
			 VALUES
					(1,'UK Commercial','UK Commercial'),
					(2,'UK Personal','UK Personal'),
					(3,'Risk Managed Europe','Risk Managed Europe'),
					(4,'WIP','WIP'),
					(5,'Ireland Commercial','Ireland Commercial'),
					(6,'Ireland Personal','Ireland Personal'),
					(7,'Canada Commercial','Canada Commercial'),
					(8,'Canada Personal','Canada Personal'),
					(9,'Denmark Commercial','Denmark Commercial'),
					(10,'Denmark Personal','Denmark Personal'),
					(11,'Norway Commercial','Norway Commercial'), 
					(12,'Norway Personal','Norway Personal') ,
					(13,'Sweden Commercial','Sweden Commercial'),
					(14,'Sweden Personal','Sweden Personal'),
					(15,'Bahrain','Bahrain'),
					(16,'Oman','Oman'),
					(17,'Saudi Arabia','Saudi Arabia'),
					(18,'UAE','UAE')

		SET IDENTITY_INSERT [dbo].[BusinessArea] OFF

		
		CREATE TABLE [dbo].[ReportingBatch]
		(
			[Id]  INT            IDENTITY (1, 1) NOT NULL, 
			[BatchId]            nvarchar(8) NOT NULL,
			[Description]        nvarchar(50) NULL,
			[BusinessAreaId]	 INT NULL, 
			PRIMARY KEY CLUSTERED ([Id] ASC), 
			CONSTRAINT [FK_Batch_To_BusinessArea] FOREIGN KEY ([BusinessAreaId]) REFERENCES [BusinessArea]([Id])
		)

		SET IDENTITY_INSERT [dbo].[ReportingBatch] ON
		INSERT INTO [dbo].[ReportingBatch]
				([Id],[BatchId],[Description],[BusinessAreaId])
			VALUES	(1,'BAH_MAIN','Bahrain Main',15),
					(2,'CAN_COMM','RSA Canada Commercial inc mid-market, GSL, UC',7),
					(3,'CAN_ENGI','RSA Canada Equipment Breakdown',7),
					(4,'CAN_GSLC','RSA Canada GSL and GCAN GSL',7),
					(5,'CAN_PERS','RSA Canada Personal Lines including UC',8),
					(6,'CNS_COMM','CNS Commercial Lines',7),
					(7,'CNS_PERS','CNS Personal Lines',8),
					(8,'COA_MAIN','Coast Main File',7),
					(9,'DEN_COMM','Denmark Commercial Lines Multi-Layered',9),
					(10,'DEN_PERS','Denmark Personal Lines Multi-Layered',10),
					(11,'IRE_BENC','Ireland Commercial Lines ISMIS',5),
					(12,'IRE_BENP','Ireland Personal Lines ISMIS',6),
					(13,'IRE_FACR','Ireland Non-Proportional FAC',null),
					(14,'IRE_GENC','Ireland Commercial lines Genius',5),
					(15,'IRE_GENP','Ireland Personal Lines Genius',6),
					(16,'IRE_KENN','Ireland KennCo Scheme',6),
					(17,'IRE_NIRE','Northern Ireland Transactions',5),
					(18,'JON_PERS','Johnson Personal Lines',8),
					(19,'NOR_COMP','Norway Complex File',11),
					(20,'OMA_MAIN','Oman Main',16),
					(21,'RSK_BELG','Risk Managed Belgium with Limits',3),
					(22,'RSK_FRAN','Risk Managed France with Limits',3),
					(23,'RSK_NETH','Risk Managed Netherlands with Limits',3),
					(24,'RSK_REAL','Risk Managed Real Estate with Limits',3),
					(25,'RSK_SPAI','Risk Managed Spain with Limits',3),
					(26,'RSK_UKUK','Risk Managed UK with Limits',3),
					(27,'SAU_MAIN','Saudi Arabia Main',17),
					(28,'SWE_COMM','Sweden Commercial Lines Multi-Layered',13),
					(29,'SWE_PERS','Sweden Personal Lines Multi-Layered',14),
					(30,'UAE_MAIN','United Arab Emirates Main',18),
					(31,'UK_ACTUR','UK Acturis Locations',1),
					(32,'UK_AFBK3','UK PL 03 Affinity/Broker',2),
					(33,'UK_AFOT5','UK PL 05 Affinity Other',2),
					(34,'UK_AISPR','UK AIS Commercial Property',1),
					(35,'UK_AIUA1','UK AIUA',1),
					(36,'UK_CANDE','UK Construction and Engineering',1),
					(37,'UK_CARVN','UK PL 14 Caravanguard',2),
					(38,'UK_CIPOP','UK CI POPA Locations',1),
					(39,'UK_CLR06','UK PL 06 Clearchoice',2),
					(40,'UK_CQEPO','UK CQE Property Owners',1),
					(41,'UK_CYB02','UK PL 02 NAG',2),
					(42,'UK_DIFCE','UK DIFC Engineering',1),
					(43,'UK_DIFCP','UK DIFC Property',1),
					(44,'UK_HNW09','UK PL 09 HNW/MNW inc Oak',2),
					(45,'UK_ICCI1','UK ICCI Commercial',1),
					(46,'UK_JLWIS','UK PL 16 JL',2),
					(47,'UK_MARCQ','UK Marine CQE',1),
					(48,'UK_MARLN','UK Marine London',1),
					(49,'UK_MARNT','UK Marine North',1),
					(50,'UK_MARSH','UK Marine Ship Construction',1),
					(51,'UK_MARST','UK Marine South',1),
					(52,'UK_MCREA','UK Multi Client Real Estate',1),
					(53,'UK_MCREG','UK Multi Client Regions',1),
					(54,'UK_MCSME','UK Multi Client SME',1),
					(55,'UK_MRTHN','UK PL MT MoreThan',2),
					(56,'UK_MTLEG','UK PL MT MoreThan_Legacy',2),
					(57,'UK_NATBK','UK PL 07 & 08 National Broker',2),
					(58,'UK_OTBRK','UK PL 10 Other Broker',2),
					(59,'UK_OTHCM','UK PL 15 Other Commercial Schemes',2),
					(60,'UK_PEN12','UK PL 12 PEN/OIM',2),
					(61,'UK_PYSHD','UK PL 13 Paymentshield',2),
					(62,'UK_REGIO','UK Regions Commercial',1),
					(63,'UK_TESCO','UK PL 17 Tesco',2),
					(64,'UK_TOWER','UK Tower Commercial',1),
					(65,'UK_TWG11','UK PL 11 Towergate',2),
					(66,'UK_UKDOM','UK UKRIS Domestic',1),
					(67,'UK_UKRIS','UK UKRIS',1),
					(68,'UK_YBS01','UK PL 01 YBS',2),
					(69,'WIP_MAIN','Wholesale International Property Book',4),
					(70,'ARGEXIST','',null),
					(71,'BATCHTTS','',null),
					(72,'BRA_MAIN','',15),
					(73,'CHI_MAIN','',null),
					(74,'CNAEXIST','',null),
					(75,'CNS_MAIN','',7),
					(76,'CNSEXIST','',7),
					(77,'COL_MAIN','',null),
					(78,'DEN_COMP','',9),
					(79,'DEN_MAIN','',9),
					(80,'EGAIADEN','',9),
					(81,'EGAIAIR2','',5),
					(82,'EGAIAIR3','',5),
					(83,'ELC_MAIN','',null),
					(84,'ENDAVA02','',null),
					(85,'ENDAVA05','',null),
					(86,'ENDAVADI','',null),
					(87,'ENDAVRSK','',null),
					(88,'ENSF161M','',null),
					(89,'ENSF163N','',null),
					(90,'ENUKTEST','',null),
					(91,'GCA_MAIN','',7),
					(92,'IND_MAIN','',null),
					(93,'IRE_MAIN','',5),
					(94,'ITA_MAIN','',null),
					(95,'JMETER02','',null),
					(96,'JON_MAIN','',7),
					(97,'JONEXIST','',7),
					(98,'MEXEXIST','',null),
					(99,'NOR_MAIN','',null),
					(100,'RSK_CPLX','',3),
					(101,'RSK_LGCY','',3),
					(102,'RSK_MAIN','',3),
					(103,'RSK_REGI','',3),
					(104,'RSK_REOS','',3),
					(105,'RSK_TEST','',null),
					(106,'RSK_TOWE','',3),
					(107,'RSKEXIST','',3),
					(108,'RSK-TEST','',null),
					(109,'RSKUKEXI','',3),
					(110,'RUS_MAIN','',null),
					(111,'SWE_MAIN','',13),
					(112,'UK_AFFIN','',1),
					(113,'UK_BROKE','',2),
					(114,'UK_HMELG','',2),
					(115,'UK_MAREU','',1),
					(116,'UK_MARIN','',1),
					(117,'UK_MORET','',2),
					(118,'UK_OAKPE','',2),
					(119,'UK_OIMPE','',2),
					(120,'UK_OTHNW','',2),
					(121,'UK_PAYME','',2),
					(122,'UK_RTAIL','',2),
					(123,'UK_TULP1','',1),
					(124,'UK_WIPDB','',4),
					(125,'URU_MAIN','',null),
					(126,'WIP_DBUK','',4),
					(127,'WIP_UKDB','',4)
		SET IDENTITY_INSERT [dbo].[ReportingBatch] OFF
		
		ALTER TABLE [dbo].[High_Risk_Locations_Geographic]
		ADD [batchDescription] nvarchar(50) NULL
		ALTER TABLE [dbo].[Locations_In_Wrong_Countries]
		ADD [batchDescription] nvarchar(50) NULL
		ALTER TABLE [dbo].[GrossTSIGBP_ByLOB]
		ADD BatchID nvarchar(8) null;
		ALTER TABLE [dbo].[GrossTSIGBP_ByProdOp]
		ADD BatchID nvarchar(8) null;
		ALTER TABLE [dbo].[GrossTSIGBP_ByProdOp]
		ADD businessArea nvarchar(250) null;
		ALTER TABLE [dbo].[locationsByLOB]
		ADD BatchID nvarchar(8) null;
		ALTER TABLE [dbo].[locationsByProdOp]
		ADD BatchID nvarchar(8) null;
		ALTER TABLE [dbo].[locationsByProdOp]
		ADD businessArea nvarchar(250) null;
		ALTER TABLE [dbo].[locationsByProdOp]
		ADD lineOfbusiness nvarchar(50) null;
		ALTER TABLE [dbo].[NetTSIGBP_ByProdOpGeocodeAccuracy]
		ADD BatchID nvarchar(8) null;

		ALTER TABLE [dbo].[DataAccuracy] ALTER COLUMN [ReportingRegion] VARCHAR (250) NULL;
		
		--update High_Risk_Locations_Geographic to include batch Description
		update [High_Risk_Locations_Geographic]
		set batchDescription = [ReportingBatch].Description
		From [High_Risk_Locations_Geographic] LEFT JOIN [ReportingBatch] ON High_Risk_Locations_Geographic.BatchID= ReportingBatch.BatchId

		update DataAccuracy
		set batchDescription = [ReportingBatch].Description
		From DataAccuracy LEFT JOIN [ReportingBatch] ON DataAccuracy.BatchID= ReportingBatch.BatchId

		update DataAccuracy
		set ReportingRegion = h.DisplayName
		From DataAccuracy 
		LEFT JOIN
			(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
				LEFT JOIN
					(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
				ON rb.BusinessAreaId = i.Id
			) as h
		ON DataAccuracy.BatchID= h.BatchId

		update [Locations_In_Wrong_Countries]
		set batchDescription = [ReportingBatch].Description
		From [Locations_In_Wrong_Countries] LEFT JOIN [ReportingBatch] ON [Locations_In_Wrong_Countries].BatchID= ReportingBatch.BatchId
		
		EXEC sp_rename 'locationsByProdOp.prodOpLocationCount', 'locationCount', 'COLUMN';
		
		UPDATE [dbo].[ReportTypes]
		SET [reportType] = 'Number of Locations by Business Area'
			,[Description] = 'The total count of locations for each Business Area.'
		WHERE [reportType] = 'Number of Locations by Producing Operation'

		UPDATE [dbo].[ReportTypes]
		SET [reportType] = 'Gross TSI (GBP) by Business Area'
			,[Description] = 'The Gross Total Sums Insured in GBP for each Business Area.'
		WHERE [reportType] = 'Gross TSI (GBP) by Producing Operation'

		

		EXEC('ALTER PROCEDURE [dbo].[generateGrossTSIGBP_ByLOB] 
			AS
			BEGIN
				SET NOCOUNT ON;
				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Gross TSI (GBP) by Line of Business''),GETDATE())

				--get the identity value of the single record that was inserted into the reports table
				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[GrossTSIGBP_ByLOB]
				SELECT  
					@IdentityValue,
					--b.Value ProducingOperation, 
					c.Value LineOfBusiness, 
					COUNT (*) Location_Count, 
					SUM([grossTotalSumInsuredGBP]) GrossTSI_GBP,
					MAX(c.Code) LOBShort,
					MAX(b.Code) ProdOpShort,
					a.batchID

				FROM [dbo].[locations_reporting] as a
				LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
				ON a.producingOperation = b.Value
				LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_LineOfBusiness] as c
				ON a.lineOfBusiness = c.Value
				GROUP BY c.Value, b.Value, a.batchID
				ORDER BY c.Value, b.Value, a.batchID
			END')

		EXEC('ALTER PROCEDURE [dbo].[generateGrossTSIGBP_ByProdOp] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Gross TSI (GBP) by Business Area''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[GrossTSIGBP_ByProdOp]
				SELECT  
					@IdentityValue,
					b.Value ProducingOperation, 
					COUNT (*) Location_Count, 
					SUM([grossTotalSumInsuredGBP]) GrossTSI_GBP,
					MAX(b.Code) ProdOpShort,
					a.batchID,
					h.DisplayName as businessArea

				FROM [dbo].[locations_reporting] as a
				LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
				ON a.producingOperation = b.Value
				LEFT JOIN
				(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
					LEFT JOIN
						(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
					ON rb.BusinessAreaId = i.Id
				) as h

				on a.batchID = h.BatchId
				GROUP BY b.Value,a.batchID, h.DisplayName
				ORDER BY b.Value,a.batchID

			END')

		EXEC('ALTER PROCEDURE [dbo].[generateLocationsByLOB] 
				AS
				BEGIN
					SET NOCOUNT ON;

					declare @IdentityOutput table ( ID int )

					insert into [Reporting].[dbo].[Reports]
							([reportTypeId],[date])
					output inserted.reportId into @IdentityOutput
					values
							((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Number of Locations by Line of Business''),GETDATE())

					declare @IdentityValue int
					select @IdentityValue = (select ID from @IdentityOutput)

					Insert into [Reporting].[dbo].[locationsByLOB]
					SELECT  
						@IdentityValue,
						c.Value LineOfBusiness, 
						COUNT (*) Location_Count, 
						MAX(c.Code) LOBShort,
						MAX(b.Code) ProdOpShort,
						a.batchID

					FROM [dbo].[locations_reporting] as a
					LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
					ON a.producingOperation = b.Value
					LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_LineOfBusiness] as c
					ON a.lineOfBusiness = c.Value
					GROUP BY c.Value, b.Value,a.batchID
					ORDER BY c.Value, b.Value,a.batchID
				END')

		EXEC('ALTER PROCEDURE [dbo].[generateLocationsByProdOpReport] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Number of Locations by Business Area''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[locationsByProdOp]
			
				SELECT @IdentityValue,
					[prodOpShort],
					max([producingOperation]) as prodOpLong,
					count([prodOpShort]) locationCount,
					lr.batchID as batchId,
					h.DisplayName as businessArea,
					lr.lineOfbusiness
	  
				FROM [dbo].[locations_reporting] lr

				LEFT JOIN
						(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
							LEFT JOIN
								(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
							ON rb.BusinessAreaId = i.Id
						) as h
				on lr.batchID=h.BatchId

				group by lr.prodOpShort, lr.batchID, h.DisplayName, lr.lineOfbusiness

			END')

		EXEC('ALTER PROCEDURE [dbo].[generateNetTSIGBP_ByProdOpGeocodeAccuracy] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

		
				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Geocode Accuracy''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				insert into [dbo].[NetTSIGBP_ByProdOpGeocodeAccuracy]
				SELECT 
					@IdentityValue,
					producingOperation, 
					CASE geocodeAccuracy 
					  WHEN ''Administrative Area'' THEN ''Settlement'' 
					  WHEN ''City / Locality'' THEN ''Settlement''  
					  WHEN ''Country'' THEN ''Country''  
					  WHEN ''Point of Interest'' THEN ''Street''
					  WHEN ''Postal Code Full'' THEN ''Postcode''  
					  WHEN ''Postal Code Partial'' THEN ''Postcode''  
					  WHEN ''Property Interpolated'' THEN ''Property''  
					  WHEN ''Property Rooftop'' THEN ''Property''  
					  WHEN ''Street'' THEN ''Street''  
					  ELSE '''' 
					END as geocodeAccuracy,
					COUNT(*) NumberOfLocations,
					SUM(netTotalSumInsuredGBP) netTSI_GBP,
					MAX(GeocodingTable.prodOpShort),
					batchID
			
				FROM 
					(SELECT	
					producingOperation,
					prodOpShort,
					geocodeAccuracy,
					netTotalSumInsuredGBP,
					batchID
					FROM [dbo].[locations_reporting]) GeocodingTable
				where geocodeAccuracy is not null and geocodeAccuracy <> ''''
		  
				GROUP BY producingOperation, geocodeAccuracy, batchID
				ORDER BY producingOperation, geocodeAccuracy, batchID
			END')

		EXEC('alter PROCEDURE [dbo].[generateDataAccuracyReport] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Batch Upload Accuracy''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[DataAccuracy]

				SELECT
					@IdentityValue,
					a.FK_Batch_BatchID,
					h.DisplayName,
					a.RecordsProcessed,
					a.ProcessingComplete,
					(a.RecordsProcessed-b.TotalLocationsGaia) LocationsDroppedOff,
					b.TotalLocationsGaia,
					c.LocationsOldDeletionDate,
					d.noTSI,
					e.PremiumAtZero,
					f.LatestInceptionDate,
					g.SuppliedGeocodes,
					d.batchDescription
				FROM 

					(select FK_Batch_BatchID, RecordsProcessed, ProcessingComplete from [GLOBAL_EXPOSURE].[dbo].[BatchProcessJob]
					 where JobStatus = ''live'') as a

				LEFT JOIN 

					(select batchID, count(*) as TotalLocationsGaia from [dbo].[locations_reporting] 
					 group by batchID) as b

				ON a.FK_Batch_BatchID = b.batchID 

				LEFT JOIN

					(select batchID, count(*) as LocationsOldDeletionDate from [dbo].[locations_reporting] 
					 where locationDeletionDate < GETDATE ()
					 group by batchID) as c

				ON b.batchID = c.batchID

				LEFT JOIN 

					(select batchID, max(batchDescription) as batchDescription ,count(*) as noTSI from [dbo].[locations_reporting]
					 where netTotalSumInsuredGBP = 0
					 group by batchID) as d
		 
				ON a.FK_Batch_BatchID = d.batchID

				LEFT JOIN

					(select batchID, count(*) as PremiumAtZero from [dbo].[locations_reporting]--[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
					 where grossPremiumSum <= 0
					 group by batchID) as e

				ON a.FK_Batch_BatchID = e.batchID

				LEFT JOIN

					(select batchID, COUNT(*) SuppliedGeocodes from [dbo].[locations_reporting]-- [GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
					WHERE addressType = ''Supplied''
					GROUP BY batchID) as g

				ON a.FK_Batch_BatchID = g.batchID

				LEFT JOIN

					(select batchID, max(locationEffectiveDate) as LatestInceptionDate from [dbo].[locations_reporting]
					 where locationEffectiveDate <= GETDATE ()
					 group by batchID) as f

				ON a.FK_Batch_BatchID = f.batchID

				LEFT JOIN
				(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
					LEFT JOIN
						(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
					ON rb.BusinessAreaId = i.Id
				) as h

				on a.FK_Batch_BatchID = h.BatchId

				ORDER BY a.FK_Batch_BatchID

			END')

		EXEC('ALTER PROCEDURE [dbo].[getHighRiskLocations] 
			@reportId int
			AS
			BEGIN
				SET NOCOUNT ON;
				SELECT 
				  IntersectingCountryName,
				  h.BatchID,
				  MAX(producingOperation) as producingOperation,
				  MAX(po.code) as prodOpShort,
				  Classification,
				  count(*) as [Number_of_Locations],
				  rb.Description as batchDescription
				FROM [Reporting].[dbo].[High_Risk_Locations_Geographic] as h
				LEFT JOIN
				[dbo].[ReportingBatch] as rb
				ON h.BatchID = rb.BatchId, 
				[GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as po
				where reportId=@reportId and h.producingOperation = po.Value COLLATE Latin1_General_CI_AS

				group by h.BatchID, IntersectingCountryName, Classification, rb.Description
				order by [Number_of_Locations] desc
				
			END')

		EXEC('ALTER PROCEDURE [dbo].[getHighRiskLocationsByIntersectingCountryName] 
			@reportId int,
			@IntersectingCountryName nvarchar(200),
			@batch nvarchar(50)

			AS
			BEGIN

				SELECT 	
				  producingOperation,
				  IntersectingCountryName,
				  policyNumber,			   
				  nameOfInsured,
				  lineOfBusiness, 
				  bestAddress,
				  geocodeAccuracy,
				  BatchID as batchId,
				  netEstimatedMaximumLossGBP,
				  grossEstimatedMaximumLossGBP,
				  netTotalSumInsuredGBP,
				  grossTotalSumInsuredGBP,
				  SHAPE.STAsText()  as Shape
			  FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
			  where reportId=@reportId and IntersectingCountryName = @IntersectingCountryName and @batch=batchId	  
			END')

		EXEC('ALTER PROCEDURE [dbo].[getHighRiskLocationsByRegionForExport]

			@reportId int,
			@regionDisplayName nvarchar(50)

			AS
			BEGIN
		
				IF(@regionDisplayName = ''Global'')
					SELECT 	
						producingOperation,
						[producingOffice],
						IntersectingCountryName,
						policyNumber,	
						[policySystem],[policyNotes],[localClientName],	   
						nameOfInsured,
						lineOfBusiness, [locationEffectiveDate],[locationDeletionDate],
						bestAddress,[locationNotes],
						geocodeAccuracy,
						BatchID as batchId,
						netEstimatedMaximumLossGBP,
						grossEstimatedMaximumLossGBP,
						netTotalSumInsuredGBP,
						grossTotalSumInsuredGBP,[rsaShare],[layerCurrency],[attachmentPoint],[lossLimit],[exposureType],[peril],[hazardCategory],[Classification],[RSAApproach],[businessDescription],[productSchemeName],
						SHAPE.STAsText() as Shape
					FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
					where reportId=@reportId 
				ELSE 
					SELECT 	
						producingOperation,
						[producingOffice],
						IntersectingCountryName,
						policyNumber,	
						[policySystem],[policyNotes],[localClientName],	   
						nameOfInsured,
						lineOfBusiness, [locationEffectiveDate],[locationDeletionDate],
						bestAddress,[locationNotes],
						geocodeAccuracy,
						BatchID as batchId,
						netEstimatedMaximumLossGBP,
						grossEstimatedMaximumLossGBP,
						netTotalSumInsuredGBP,
						grossTotalSumInsuredGBP,[rsaShare],[layerCurrency],[attachmentPoint],[lossLimit],[exposureType],[peril],[hazardCategory],[Classification],[RSAApproach],[businessDescription],[productSchemeName],
						SHAPE.STAsText() as Shape
					FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
					where reportId=@reportId and batchId in (select [BatchId] from [dbo].[ReportingBatch] where [BusinessAreaId] = (Select Id from [dbo].[BusinessArea] Region where DisplayName=@regionDisplayName))	  
			END')

		EXEC('ALTER PROCEDURE [dbo].[generateLocationsInWrongCountries]
		
			AS
			BEGIN
				SET NOCOUNT ON;
		
				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Locations In Wrong Countries''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				insert [Reporting].[dbo].[Locations_In_Wrong_Countries]
					select * from(
					SELECT
						@IdentityValue as reportId,
						Exposures.producingOperation,
						Exposures.BatchID,
						Exposures.country,
						--Exposures.countryA2,
						Exposures.policyNumber,
						Exposures.nameOfInsured,
						Exposures.lineOfBusiness,
						Exposures.Shape,
						Exposures.bestAddress,
						Exposures.netEstimatedMaximumLossGBP,
						GLOBAL_COUNTRIES.Name,
						GLOBAL_COUNTRIES.[CountryCodeA2] as Country_A2CODE,
						Exposures.countryA2 as Expsoure_A2CODE,
						Exposures.prodOpShort,
						rb.Description as batchDescription 

					FROM [Reporting].[dbo].[locations_reporting] Exposures
					LEFT JOIN
						[dbo].[ReportingBatch] as rb
					ON Exposures.BatchID = rb.BatchId
					LEFT JOIN [base].[dbo].[GLOBAL_COUNTRIES_UPDATE] GLOBAL_COUNTRIES
					ON GLOBAL_COUNTRIES.Shape.STContains(Exposures.Shape) = 1) wrong_country
			
					where
					wrong_country.Country_A2CODE <> wrong_country.Expsoure_A2CODE
			END')

		COMMIT TRANSACTION

		PRINT 'All done...'

		
	END TRY
	BEGIN CATCH
		IF @@trancount > 0 ROLLBACK TRANSACTION
		DECLARE @msg nvarchar(2048) = error_message()  
		RAISERROR (@msg, 16, 1)
		--RETURN 55555
	END CATCH

   

   
      
		