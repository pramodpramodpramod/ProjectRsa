﻿USE [Reporting]
GO

INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Number of Locations by Country')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Batch Upload Accuracy')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Locations within High Risk Countries')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Locations In Wrong Countries')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Geocode Accuracy')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Data Currency')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Gross TSI (GBP) by Producing Operation')
INSERT INTO [dbo].[ReportTypes] ([reportType]) VALUES ('Number of Locations by Producing Operation')

GO

--reportTypeId	reportType
--1	Number of Locations by Country
--2	Batch Upload Accuracy
--3	Locations within High Risk Countries
--4	Locations In Wrong Countries
--5	Geocode Accuracy
--6	Data Currency
--7	Gross TSI (GBP) by Producing Operation
--8	Number of Locations by Producing Operation