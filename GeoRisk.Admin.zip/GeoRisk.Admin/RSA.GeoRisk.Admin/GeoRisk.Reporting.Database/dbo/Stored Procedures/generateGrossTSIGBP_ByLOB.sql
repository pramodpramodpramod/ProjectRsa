﻿

	-- ==========================================================================================
	-- Author:		Mike Blom
	-- Create date: April 28th
	-- Description:	Selects line of businnes counts and exposure by Gross TSI GBP for each operation
	-- ==========================================================================================
	CREATE PROCEDURE [dbo].[generateGrossTSIGBP_ByLOB] 
		
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Selects line of businnes counts and exposure by net EML GBP for each operation --
		declare @IdentityOutput table ( ID int )

		-- Generating a new report, so let's insert that into the reports table
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
				((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Gross TSI (GBP) by Line of Business'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		Insert into [Reporting].[dbo].[GrossTSIGBP_ByLOB]
		SELECT  
			@IdentityValue,
			--b.Value ProducingOperation, 
			c.Value LineOfBusiness, 
			COUNT (*) Location_Count, 
			SUM([grossTotalSumInsuredGBP]) GrossTSI_GBP,
			MAX(c.Code) LOBShort,
			MAX(b.Code) ProdOpShort

		FROM [dbo].[locations_reporting] as a
		LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
		ON a.producingOperation = b.Value
		LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_LineOfBusiness] as c
		ON a.lineOfBusiness = c.Value
		GROUP BY c.Value, b.Value
		ORDER BY c.Value, b.Value

	END



