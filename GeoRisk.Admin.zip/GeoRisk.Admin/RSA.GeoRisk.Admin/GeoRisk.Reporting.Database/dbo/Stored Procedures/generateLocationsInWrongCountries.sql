﻿CREATE PROCEDURE [dbo].[generateLocationsInWrongCountries]
		-- Add the parameters for the stored procedure here
		
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		
		declare @IdentityOutput table ( ID int )

		--insert a record to show that we've generated a Monthly CRESTA Join, also insert the date
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
				((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Locations In Wrong Countries'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		insert [Reporting].[dbo].[Locations_In_Wrong_Countries]
			select * from(
			SELECT
				@IdentityValue as reportId,
				Exposures.producingOperation,
				Exposures.BatchID,
				Exposures.country,
				--Exposures.countryA2,
				Exposures.policyNumber,
				Exposures.nameOfInsured,
				Exposures.lineOfBusiness,
				Exposures.Shape,
				Exposures.bestAddress,
				Exposures.netEstimatedMaximumLossGBP,
				GLOBAL_COUNTRIES.Name,
				GLOBAL_COUNTRIES.[CountryCodeA2] as Country_A2CODE,
				Exposures.countryA2 as Expsoure_A2CODE,
				Exposures.prodOpShort

			FROM [Reporting].[dbo].[locations_reporting] Exposures
			INNER JOIN [base].[dbo].[GLOBAL_COUNTRIES_UPDATE] GLOBAL_COUNTRIES
			--ON 1=1
			--WHERE GLOBAL_COUNTRIES.Shape.STContains(Exposures.Shape) = 1 and 	
			ON GLOBAL_COUNTRIES.Shape.STContains(Exposures.Shape) = 1) wrong_country
			where 
			wrong_country.Country_A2CODE <> wrong_country.Expsoure_A2CODE
	END

