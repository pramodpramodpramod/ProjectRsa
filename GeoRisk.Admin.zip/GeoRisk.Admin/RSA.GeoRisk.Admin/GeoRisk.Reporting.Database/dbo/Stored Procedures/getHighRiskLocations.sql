﻿

CREATE PROCEDURE [dbo].[getHighRiskLocations] 
		-- Add the parameters for the stored procedure here
		@reportId int

	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		SELECT 
		  IntersectingCountryName,
		  producingOperation,
		  MAX(po.code) as prodOpShort,
		  Classification,
		  count(*) as [Number_of_Locations]
	  FROM [Reporting].[dbo].[High_Risk_Locations_Geographic] hr, [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] po
	  
	  where reportId=@reportId and hr.producingOperation = po.Value COLLATE Latin1_General_CI_AS
	  group by producingoperation, IntersectingCountryName, Classification
	  order by [Number_of_Locations] desc

	END

	

