﻿


	
	-- =============================================
	-- Author:		Mike Blom
	-- Create date: February 24, 2015
	-- Description:	Operation geocoding accuracy by count and RSA TSI net GBP
	-- =============================================
	CREATE PROCEDURE [dbo].[generateNetTSIGBP_ByProdOpGeocodeAccuracy] 
		-- Add the parameters for the stored procedure here
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		declare @IdentityOutput table ( ID int )

		--generating a new report, so let's insert that into the reports table
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
				((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Geocode Accuracy'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		--Net TSI By ProdOp and Geocode Accuracy
		-- Insert statements for procedure here
		insert into [dbo].[NetTSIGBP_ByProdOpGeocodeAccuracy]
		SELECT 
			@IdentityValue,
			producingOperation, 
			CASE geocodeAccuracy 
			  WHEN 'Administrative Area' THEN 'Settlement' 
			  WHEN 'City / Locality' THEN 'Settlement'  
			  WHEN 'Country' THEN 'Country'  
			  WHEN 'Point of Interest' THEN 'Street'  
			  WHEN 'Postal Code Full' THEN 'Postcode'  
			  WHEN 'Postal Code Partial' THEN 'Postcode'  
			  WHEN 'Property Interpolated' THEN 'Property'  
			  WHEN 'Property Rooftop' THEN 'Property'  
			  WHEN 'Street' THEN 'Street'  
			  ELSE '' 
			END as geocodeAccuracy,
			COUNT(*) NumberOfLocations,
			SUM(netTotalSumInsuredGBP) netTSI_GBP,
			MAX(GeocodingTable.prodOpShort)
			
		FROM 
			(SELECT	
			producingOperation,
			prodOpShort,
			geocodeAccuracy,
			netTotalSumInsuredGBP
			FROM [dbo].[locations_reporting]) GeocodingTable
		where geocodeAccuracy is not null and geocodeAccuracy <> ''
		  
		GROUP BY producingOperation, [geocodeAccuracy]
		ORDER BY producingOperation, [geocodeAccuracy]
	END




