﻿
	-- =============================================
	-- Author:		Mike Blom
	-- Create date: March 26th
	-- Description:	Details the last successful upload for a prodop
	-- =============================================
	CREATE PROCEDURE [dbo].[generateDataCurrencyReport] 
		-- Add the parameters for the stored procedure here
		
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		declare @IdentityOutput table ( ID int )

		--generating a new 'High Risk Locations Geographic' report, so let's insert that into the reports table
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
			((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Last Upload Date'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		insert into [Reporting].[dbo].[DataCurrency]
			select 
			@IdentityValue,
			b.[BatchID] batchIdShort,
			b.producingOperation prodOpShort,
			a.[ProcessingComplete],
			po.Value producingOperation,
			b.[Description] batchIdLong

			from [GLOBAL_EXPOSURE].[dbo].[Batch] b
			join
				(select bpj.[FK_Batch_BatchID], bpj.[ProcessingComplete] from [GLOBAL_EXPOSURE].[dbo].[BatchProcessJob] bpj where bpj.JobStatus = 'Live' ) a
			on a.[FK_Batch_BatchID]=b.BatchID
			join
				[GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] po
			on po.Code = b.producingOperation
			order by [ProcessingComplete]



	END


