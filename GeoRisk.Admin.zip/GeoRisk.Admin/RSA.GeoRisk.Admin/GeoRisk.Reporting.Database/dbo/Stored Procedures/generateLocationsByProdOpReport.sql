﻿


	-- =============================================
	-- Author:		Mike Blom
	-- Create date: February 24th, 2015
	-- Description: Locations By Prod Op Report Generator
	-- =============================================
	CREATE PROCEDURE [dbo].[generateLocationsByProdOpReport] 
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		declare @IdentityOutput table ( ID int )

		--generating a new 'High Risk Locations Geographic' report, so let's insert that into the reports table
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
				((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Number of Locations by Producing Operation'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		Insert into [Reporting].[dbo].[locationsByProdOp]

		
			
		SELECT @IdentityValue,
			[prodOpShort],
			max([producingOperation]) as prodOpLong,
			count([prodOpShort]) prodOpLocationCount
	  
		FROM [dbo].[locations_reporting]

		group by prodOpShort	

	END



