﻿
	-- =============================================
	-- Author:		Mike Blom
	-- Create date: Feb 19th 2015
	-- Edited: July 30, 2015
	-- Description:	generate a new High Risk Locations Geographic report
	-- =============================================
	CREATE PROCEDURE [dbo].[generateHighRiskLocationsGeographicReport]
		-- Add the parameters for the stored procedure here
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		
		--this is the table that will store details on the records inserted into reports
		declare @IdentityOutput table ( ID int )

		--generating a new 'High Risk Locations Geographic' report, so let's insert that into the reports table
		insert into [Reporting].[dbo].[Reports]
			 ([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
			 ((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Locations within High Risk Countries'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		insert into [Reporting].[dbo].[High_Risk_Locations_Geographic]
		SELECT
			@IdentityValue,
			Exposures.uniqueLocationIdentifier,
			Exposures.producingOperation,
			Exposures.batchID,
			Exposures.lineOfBusiness,
			Exposures.policyNumber,
			Exposures.nameOfInsured,
			Exposures.netEstimatedMaximumLossGBP,
			Exposures.grossEstimatedMaximumLossGBP,
			Exposures.netTotalSumInsuredGBP,
			Exposures.grossTotalSumInsuredGBP,
			Exposures.Shape,
			Exposures.bestAddress,
			Exposures.geocodeAccuracy,
			Exposures.geocodeSource,
			Exposures.country,
			HighRiskCountries.Classification,
			HighRiskCountries.CountryCodeA2,
			HighRiskCountries.RSAApproach,
			Exposures.prodOpShort,
			Exposures.country,
			Exposures.producingOffice, -- new: nvarchar(50) null
			Exposures.rsaShare, -- new: numeric (38,6) null
			Exposures.layerCurrency, -- new: nvarchar(3) not null (need to make null)
			Exposures.attachmentPoint, -- new: numeric (38,8) not null (need to make null)
			Exposures.lossLimit, -- new: numeric (38,8) null 
			Exposures.policySystem, -- new: nvarchar(50) null
			Exposures.exposureType, --new:  nvarchar(100) null
			Exposures.policyNotes, --new:  nvarchar(1024) null
			Exposures.locationNotes, --new:  nvarchar(1024) null
			Exposures.businessDescription,-- new: nvarchar(100) null
			Exposures.productSchemeName, -- new: nvarchar(50) null
			Exposures.peril, -- new: nvarchar(max) null
			Exposures.locationEffectiveDate, -- new: datetime2(7) not null (need to make null)
			Exposures.locationDeletionDate, -- new: datetime2(7) not null (need to make null)
			Exposures.localClientName, -- new: nvarchar(255) null 
			Exposures.hazardCategory -- new: nvarchar(50) null

		FROM [dbo].[locations_reporting] Exposures--, [base].[dbo].[GLOBAL_COUNTRIES_UPDATE] global_countries
		JOIN
			(SELECT *
			FROM [Reporting].[dbo].[GLOBAL_HIGH_RISK_COUNTRIES]
			WHERE Classification in ('RED','YLW')) HighRiskCountries
		
		ON 1=1
		WHERE HighRiskCountries.Shape.STContains(Exposures.Shape) = 1 and Exposures.countryA2 = HighRiskCountries.CountryCodeA2

		ORDER BY HighRiskCountries.CountryCodeA2, HighRiskCountries.Classification--,Country 



	END



