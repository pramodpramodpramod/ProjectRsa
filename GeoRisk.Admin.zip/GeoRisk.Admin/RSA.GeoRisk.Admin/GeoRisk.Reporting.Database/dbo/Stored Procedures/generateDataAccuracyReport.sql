﻿




	--========================================================================================================= user created, now generate the stored procs


	-- =============================================
	-- Author:		Mike Blom
	-- Create date: February 24th, 2015
	-- Description:	Batch import data is joined to the global exposure table and queries each batch for the:
	--		the number of records
	--		the processed date of the batch file
	--		the difference between number of locations in the upload file and in Gaia
	--		the number of records with an expiry date older than today 
	--		the number of records with no premium
	--		the latest inception date 
	--		the lastest inception date of a policy
	-- =============================================
	CREATE PROCEDURE [dbo].[generateDataAccuracyReport] 
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		declare @IdentityOutput table ( ID int )

		--generating a new 'High Risk Locations Geographic' report, so let's insert that into the reports table
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
				((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Batch Upload Accuracy'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		Insert into [Reporting].[dbo].[DataAccuracy]

		SELECT
			@IdentityValue,
			a.FK_Batch_BatchID,
			CASE
				WHEN a.FK_Batch_BatchID = 'ARG_MAIN' THEN 'Latin America'
				WHEN a.FK_Batch_BatchID = 'BAH_MAIN' THEN 'Middle East'
				WHEN a.FK_Batch_BatchID = 'BRA_MAIN' THEN 'Latin America'
				WHEN a.FK_Batch_BatchID = 'CAN_MAIN' THEN 'Canada'
				WHEN a.FK_Batch_BatchID = 'CHI_MAIN' THEN 'Latin America'
				WHEN a.FK_Batch_BatchID = 'CNA_MAIN' THEN 'Asia'
				WHEN a.FK_Batch_BatchID = 'CNS_MAIN' THEN 'Canada'
				WHEN a.FK_Batch_BatchID = 'COA_MAIN' THEN 'Canada'
				WHEN a.FK_Batch_BatchID = 'DEN_COMP' THEN 'Scandinavia'
				WHEN a.FK_Batch_BatchID = 'SWE_COMP' THEN 'Scandinavia'
				WHEN a.FK_Batch_BatchID = 'NOR_COMP' THEN 'Scandinavia'
				WHEN a.FK_Batch_BatchID = 'COL_MAIN' THEN 'Latin America'
				WHEN a.FK_Batch_BatchID = 'DEN_MAIN' THEN 'Scandinavia'
				WHEN a.FK_Batch_BatchID = 'GCA_MAIN' THEN 'Canada'
				--WHEN a.FK_Batch_BatchID = 'HON_MAIN' THEN 'Asia'
				WHEN a.FK_Batch_BatchID = 'IND_MAIN' THEN 'Asia'
				WHEN a.FK_Batch_BatchID = 'IRE_MAIN' THEN 'Western Europe'
				WHEN a.FK_Batch_BatchID = 'ITA_MAIN' THEN 'Western Europe'
				WHEN a.FK_Batch_BatchID = 'JON_MAIN' THEN 'Canada'
				WHEN a.FK_Batch_BatchID = 'MEX_MAIN' THEN 'Latin America'
				WHEN a.FK_Batch_BatchID = 'NOR_MAIN' THEN 'Scandinavia'
				WHEN a.FK_Batch_BatchID = 'OMA_MAIN' THEN 'Middle East'
				WHEN a.FK_Batch_BatchID = 'RSK_MAIN' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'RUS_MAIN' THEN 'CEE'
				WHEN a.FK_Batch_BatchID = 'SAU_MAIN' THEN 'Middle East'
				--WHEN a.FK_Batch_BatchID = 'SIN_COEN' THEN 'Asia'
				--WHEN a.FK_Batch_BatchID = 'SIN_RETA' THEN 'Asia'
				--WHEN a.FK_Batch_BatchID = 'SIN_SPEC' THEN 'Asia'
				WHEN a.FK_Batch_BatchID = 'SWE_MAIN' THEN 'Scandinavia'
				WHEN a.FK_Batch_BatchID = 'UAE_MAIN' THEN 'Middle East'
				WHEN a.FK_Batch_BatchID = 'UK_AFFIN' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_AIUA1' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'UK_BKPER' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_BROKE' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_CERTT' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'UK_ICCI1' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'UK_MARIN' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'UK_MORET' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_OAKPE' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_OIMCO' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'UK_OIMPE' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_OIMSA' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_PAYME' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_TULP1' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'URU_MAIN' THEN 'Latin America'
				WHEN a.FK_Batch_BatchID = 'UK_RTAIL' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_CARVN' THEN 'UK Personal'  
				WHEN a.FK_Batch_BatchID = 'UK_DIFCE' THEN 'UK Commercial'  
				WHEN a.FK_Batch_BatchID = 'UK_DIFCP' THEN 'UK Commercial'
				WHEN a.FK_Batch_BatchID = 'UK_HMELG' THEN 'UK Personal'
				WHEN a.FK_Batch_BatchID = 'UK_OTHNW' THEN 'UK Personal'  
				WHEN a.FK_Batch_BatchID = 'IND_HEPA' THEN 'Asia'  
				WHEN a.FK_Batch_BatchID = 'IND_HOME' THEN 'Asia'  
				WHEN a.FK_Batch_BatchID IS NULL THEN 'UK Commercial'		
			END ReportingRegion,
			a.RecordsProcessed,
			a.ProcessingComplete,
			(a.RecordsProcessed-b.TotalLocationsGaia) LocationsDroppedOff,
			b.TotalLocationsGaia,
			c.LocationsOldDeletionDate,
			d.noTSI,
			e.PremiumAtZero,
			f.LatestInceptionDate,
			g.SuppliedGeocodes,
			d.batchDescription
		FROM 

			(select FK_Batch_BatchID, RecordsProcessed, ProcessingComplete from [GLOBAL_EXPOSURE].[dbo].[BatchProcessJob]
			 where JobStatus = 'live') as a

		LEFT JOIN 

			(select batchID, count(*) as TotalLocationsGaia from [dbo].[locations_reporting] --[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
			 group by batchID) as b

		ON a.FK_Batch_BatchID = b.batchID 

		LEFT JOIN

			(select batchID, count(*) as LocationsOldDeletionDate from [dbo].[locations_reporting] --[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
			 where locationDeletionDate < GETDATE ()
			 group by batchID) as c

		ON b.batchID = c.batchID

		LEFT JOIN 

			(select batchID, max(batchDescription) as batchDescription ,count(*) as noTSI from [dbo].[locations_reporting]--[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
			 where netTotalSumInsuredGBP = 0
			 group by batchID) as d
		 
		ON a.FK_Batch_BatchID = d.batchID

		LEFT JOIN

			(select batchID, count(*) as PremiumAtZero from [dbo].[locations_reporting]--[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]--GLOBAL_EXPOSURE_PROD.dbo.GlobalExposureGeoRisk
			 where grossPremiumSum <= 0
			 group by batchID) as e

		ON a.FK_Batch_BatchID = e.batchID

		LEFT JOIN

			(select batchID, COUNT(*) SuppliedGeocodes from [dbo].[locations_reporting]-- [GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]--GLOBAL_EXPOSURE_PROD.dbo.GlobalExposureGeoRisk
			WHERE addressType = 'Supplied'
			GROUP BY batchID) as g

		ON a.FK_Batch_BatchID = g.batchID

		LEFT JOIN

			(select batchID, max(locationEffectiveDate) as LatestInceptionDate from [dbo].[locations_reporting]--[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]--GLOBAL_EXPOSURE_PROD.dbo.GlobalExposureGeoRisk
			 where locationEffectiveDate <= GETDATE ()
			 group by batchID) as f

		ON a.FK_Batch_BatchID = f.batchID

		ORDER BY a.FK_Batch_BatchID

	END





