﻿CREATE PROCEDURE getHighRiskLocationsByRegionForExport

	@reportId int,
	@regionDisplayName nvarchar(50)

	AS
	BEGIN
		
		IF(@regionDisplayName = 'Global')
			SELECT 	
				producingOperation,[producingOffice],
				IntersectingCountryName,
				policyNumber,	
				[policySystem],[policyNotes],[localClientName],	   
				nameOfInsured,
				lineOfBusiness, [locationEffectiveDate],[locationDeletionDate],
				bestAddress,[locationNotes],
				geocodeAccuracy,
				BatchID as batchId,
				netEstimatedMaximumLossGBP,
				grossEstimatedMaximumLossGBP,
				netTotalSumInsuredGBP,
				grossTotalSumInsuredGBP,[rsaShare],[layerCurrency],[attachmentPoint],[lossLimit],[exposureType],[peril],[hazardCategory],[Classification],[RSAApproach],[businessDescription],[productSchemeName],
				SHAPE.STAsText() as Shape
			FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
			where reportId=@reportId 
		ELSE 
			SELECT 	
				producingOperation,[producingOffice],
				IntersectingCountryName,
				policyNumber,	
				[policySystem],[policyNotes],[localClientName],	   
				nameOfInsured,
				lineOfBusiness, [locationEffectiveDate],[locationDeletionDate],
				bestAddress,[locationNotes],
				geocodeAccuracy,
				BatchID as batchId,
				netEstimatedMaximumLossGBP,
				grossEstimatedMaximumLossGBP,
				netTotalSumInsuredGBP,
				grossTotalSumInsuredGBP,[rsaShare],[layerCurrency],[attachmentPoint],[lossLimit],[exposureType],[peril],[hazardCategory],[Classification],[RSAApproach],[businessDescription],[productSchemeName],
				SHAPE.STAsText() as Shape
			FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
			where reportId=@reportId and producingoperation in (select [ProdOp] from [dbo].[ProducingOperations] where [RegionId] = (Select Id from Region where DisplayName=@regionDisplayName))	  
	END