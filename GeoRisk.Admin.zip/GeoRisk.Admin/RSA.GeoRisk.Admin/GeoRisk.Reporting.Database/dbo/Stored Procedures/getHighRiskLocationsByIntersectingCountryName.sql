﻿

CREATE PROCEDURE [dbo].[getHighRiskLocationsByIntersectingCountryName] 
		-- Add the parameters for the stored procedure here
		@reportId int,
		@IntersectingCountryName nvarchar(200),
		@producingoperation nvarchar(50)

	AS
	BEGIN

		SELECT 	
		  producingOperation,
		  IntersectingCountryName,
	      policyNumber,			   
		  nameOfInsured,
		  lineOfBusiness, 
		  bestAddress,
		  geocodeAccuracy,
		  BatchID as batchId,
		  netEstimatedMaximumLossGBP,
          grossEstimatedMaximumLossGBP,
          netTotalSumInsuredGBP,
          grossTotalSumInsuredGBP,
		  SHAPE.STAsText()  as Shape
	  FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
	  where reportId=@reportId and @IntersectingCountryName = IntersectingCountryName and @producingoperation=producingoperation	  
	END

	

