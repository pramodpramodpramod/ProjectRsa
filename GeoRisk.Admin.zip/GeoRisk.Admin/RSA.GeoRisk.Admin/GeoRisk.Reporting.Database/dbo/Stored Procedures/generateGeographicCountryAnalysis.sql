﻿




	
	-- =============================================
	-- Author:		Mike Blom
	-- Create date: February 20th, 2015
	-- Description:	generates the monthly report for countries accumulation
	-- =============================================
	CREATE PROCEDURE [dbo].[generateGeographicCountryAnalysis] 
		
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		
		declare @IdentityOutput table ( ID int )

		--insert a record to show that we've generated a Monthly CRESTA Join, also insert the date
		insert into [Reporting].[dbo].[Reports]
				([reportTypeId],[date])
		output inserted.reportId into @IdentityOutput
		values
				((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType='Number of Locations by Country'),GETDATE())

		--get the identity value of the single record that was inserted into the reports table
		declare @IdentityValue int
		select @IdentityValue = (select ID from @IdentityOutput)

		Insert  [Reporting].[dbo].[GeographicCountryAnalysis]

		SELECT
			@IdentityValue,
			Exposures.producingOperation, 
			Exposures.batchID,
			GLOBAL_COUNTRIES.Name Country,
			Exposures.geocodeAccuracy,
			COUNT (*) NumberOfLocations,
			SUM (netEstimatedMaximumLossGBP) NetEMLGBP,
			MAX(Exposures.prodOpShort)
		FROM 
			(Select 
			producingOperation,
			prodOpShort,
			batchID, 
			geocodeAccuracy,
			netEstimatedMaximumLossGBP,
			SHAPE
			FROM [dbo].[locations_reporting]) Exposures 


		--JOIN [base].[dbo].[GLOBAL_CRESTA_UPDATE] Cresta	
		INNER JOIN [base].[dbo].[GLOBAL_COUNTRIES] GLOBAL_COUNTRIES 
		--ON 1=1
		ON GLOBAL_COUNTRIES.Shape.STContains(Exposures.Shape) = 1

		GROUP BY Exposures.producingOperation, Exposures.batchID, GLOBAL_COUNTRIES.Name, Exposures.geocodeAccuracy
		
		END






