﻿CREATE TABLE [dbo].[locationsByLOB] (
    [Id]             INT           IDENTITY (1, 1) NOT NULL,
    [reportId]       INT           NOT NULL,
    [LineOfBusiness] NVARCHAR (50) NULL,
    [Location_Count] INT           NULL,
    [lobShort]       NVARCHAR (3)  NULL,
    [prodOpShort]    NVARCHAR (3)  NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

