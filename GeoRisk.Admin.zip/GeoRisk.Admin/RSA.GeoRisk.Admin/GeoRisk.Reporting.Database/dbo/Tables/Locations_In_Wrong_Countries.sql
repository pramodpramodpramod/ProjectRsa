﻿CREATE TABLE [dbo].[Locations_In_Wrong_Countries] (
    [Id]                         INT              IDENTITY (1, 1) NOT NULL,
    [reportId]                   INT              NOT NULL,
    [producingOperation]         NVARCHAR (50)    NULL,
    [BatchID]                    NVARCHAR (8)     NULL,
    [Country]                    NVARCHAR (75)    NULL,
    [policyNumber]               NVARCHAR (50)    NOT NULL,
    [nameOfInsured]              NVARCHAR (255)   NOT NULL,
    [lineOfBusiness]             NVARCHAR (50)    NULL,
    [Shape]                      [sys].[geometry] NULL,
    [bestAddress]                NVARCHAR (2098)  NULL,
    [netEstimatedMaximumLossGBP] NUMERIC (38, 8)  NULL,
    [Name]                       NVARCHAR (255)   NULL,
    [Country_A2CODE]             NVARCHAR (2)     NULL,
    [Expsoure_A2CODE]            NVARCHAR (2)     NULL,
    [prodOpShort]                NVARCHAR (3)     NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

