﻿CREATE TABLE [dbo].[GrossTSIGBP_ByLOB] (
    [Id]             INT             IDENTITY (1, 1) NOT NULL,
    [reportId]       INT             NOT NULL,
    [LineOfBusiness] NVARCHAR (50)   NULL,
    [Location_Count] INT             NULL,
    [GrossTSI_GBP]   NUMERIC (38, 8) NULL,
    [lobShort]       NVARCHAR (3)    NULL,
    [prodOpShort]    NVARCHAR (3)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_GrossTSIGBP_ByLOB_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

