﻿CREATE TABLE [dbo].[GrossTSIGBP_ByProdOp] (
    [Id]                 INT             IDENTITY (1, 1) NOT NULL,
    [reportId]           INT             NOT NULL,
    [ProducingOperation] NVARCHAR (50)   NULL,
    [Location_Count]     INT             NULL,
    [GrossTSI_GBP]       NUMERIC (38, 8) NULL,
    [prodOpShort]        NVARCHAR (3)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_GrossTSIGBP_ByProdOp_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

