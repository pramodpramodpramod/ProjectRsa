﻿CREATE TABLE [dbo].[Region]
(
	[Id] INT  IDENTITY (1, 1) PRIMARY KEY NOT NULL, 
	[Name] nvarchar(100),
	[DisplayName] nvarchar(50)
)