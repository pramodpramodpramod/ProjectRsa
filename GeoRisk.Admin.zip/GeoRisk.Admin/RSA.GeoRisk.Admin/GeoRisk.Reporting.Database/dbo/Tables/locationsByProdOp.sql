﻿CREATE TABLE [dbo].[locationsByProdOp] (
    [Id]                  INT           IDENTITY (1, 1) NOT NULL,
    [reportId]            INT           NOT NULL,
    [prodOpShort]         NVARCHAR (3)  NOT NULL,
    [prodOpLong]          NVARCHAR (50) NULL,
    [prodOpLocationCount] INT           NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_locationsByProdOp_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

