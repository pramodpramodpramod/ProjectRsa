﻿CREATE TABLE [dbo].[NetTSIGBP_ByProdOpGeocodeAccuracy] (
    [Id]                 INT             IDENTITY (1, 1) NOT NULL,
    [reportId]           INT             NOT NULL,
    [producingOperation] NVARCHAR (50)   NULL,
    [geocodeAccuracy]    NVARCHAR (50)   NULL,
    [NumberOfLocations]  INT             NULL,
    [netTSI_GBP]         NUMERIC (38, 8) NULL,
    [prodOpShort]        NVARCHAR (3)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_NetTSIGBP_ByProdOpGeocodeAccuracy_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

