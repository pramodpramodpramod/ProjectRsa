﻿CREATE TABLE [dbo].[locations_reporting] (
     [ObjectID]                     INT              NOT NULL,
    [batchID]                      NVARCHAR (8)     NULL,
    [batchDescription]             NVARCHAR (50)    NULL,
    [prodOpShort]                  NVARCHAR (3)     NOT NULL,
    [producingOperation]           NVARCHAR (50)    NOT NULL,
    [lineOfbusiness]               NVARCHAR (50)    NOT NULL,
    [policySystem]                 NVARCHAR (50)    NOT NULL,
    [policyNumber]                 NVARCHAR (50)    NOT NULL,
    [nameOfInsured]                NVARCHAR (255)   NOT NULL,
    [businessDescription]          NVARCHAR (100)   NULL,
    [policyNotes]                  NVARCHAR (1024)  NULL,
    [productSchemeName]            NVARCHAR (50)    NULL,
    [grossPremiumSum]              NUMERIC (38, 8)  NULL,
    [producingOffice]              NVARCHAR (50)    NULL,
    [rsaShare]                     NUMERIC (38, 6)  NULL,
    [layerCurrency]                NVARCHAR (3)     NOT NULL,
    [attachmentPoint]              NUMERIC (38, 8)  NOT NULL,
    [lossLimit]                    NUMERIC (38, 8)  NULL,
    [peril]                        NVARCHAR (MAX)   NULL,
    [locationNotes]                NVARCHAR (1024)  NULL,
    [locationEffectiveDate]        DATETIME2 (7)    NOT NULL,
    [locationDeletionDate]         DATETIME2 (7)    NOT NULL,
    [localClientName]              NVARCHAR (255)   NULL,
    [hazardCategory]               NVARCHAR (50)    NULL,
    [netTotalSumInsuredGBP]        NUMERIC (38, 8)  NULL,
    [grossTotalSumInsuredGBP]      NUMERIC (38, 8)  NULL,
    [netEstimatedMaximumLossGBP]   NUMERIC (38, 8)  NULL,
    [grossEstimatedMaximumLossGBP] NUMERIC (38, 8)  NULL,
    [currency]                     NVARCHAR (75)    NOT NULL,
    [bestAddress]                  NVARCHAR (2098)  NULL,
    [countryA2]                    NVARCHAR (2)     NOT NULL,
    [country]                      NVARCHAR (75)    NOT NULL,
    [geocodeAccuracy]              NVARCHAR (50)    NULL,
    [geocodeSource]                NVARCHAR (50)    NULL,
    [addressType]                  NVARCHAR (50)    NOT NULL,
    [exposureType]                 NVARCHAR (100)   NOT NULL,
    [uniqueLocationIdentifier]     NVARCHAR (50)    NOT NULL,
    [Shape]                        [sys].[geometry] NULL,
    CONSTRAINT [pkey_ObjectID] PRIMARY KEY CLUSTERED ([ObjectID] ASC)
);


GO
CREATE SPATIAL INDEX [location_reporting_SIDX]
    ON [dbo].[locations_reporting] ([Shape])
    USING GEOMETRY_GRID
    WITH  (
            BOUNDING_BOX = (XMAX = 190, XMIN = -190, YMAX = 90, YMIN = -90),
            GRIDS = (LEVEL_1 = HIGH, LEVEL_2 = HIGH, LEVEL_3 = HIGH, LEVEL_4 = HIGH)
          );

