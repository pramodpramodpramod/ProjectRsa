﻿CREATE TABLE [dbo].[ProducingOperations]
(
	[Id] INT  IDENTITY (1, 1) PRIMARY KEY NOT NULL, 
	[ProdOp] nvarchar(100) NOT NULL,
	[ProdOpShort] nvarchar(5) NOT NULL,
	[RegionId] int NOT NULL 
    CONSTRAINT [FK_ProducingOperations_ToTable] FOREIGN KEY ([RegionId]) REFERENCES [Region]([Id])

)