﻿CREATE TABLE [dbo].[GLOBAL_HIGH_RISK_COUNTRIES] (
    [OBJECTID]           INT              IDENTITY (1, 1) NOT NULL,
    [CountryCodeA2]      NVARCHAR (2)     NOT NULL,
    [ReasonForInclusion] NVARCHAR (100)   NOT NULL,
    [RSAApproach]        NVARCHAR (500)   NOT NULL,
    [Classification]     NVARCHAR (3)     NOT NULL,
    [CapturedBy]         NVARCHAR (50)    NOT NULL,
    [DateCreated]        DATETIME2 (7)    NOT NULL,
    [CreatedBy]          NVARCHAR (50)    NOT NULL,
    [DateModified]       DATETIME2 (7)    NOT NULL,
    [ModifiedBy]         NVARCHAR (50)    NOT NULL,
    [SHAPE]              [sys].[geometry] NULL,
    PRIMARY KEY CLUSTERED ([OBJECTID] ASC)
);

