﻿CREATE TABLE [dbo].[GeographicCountryAnalysis] (
    [Id]                 INT             IDENTITY (1, 1) NOT NULL,
    [reportId]           INT             NOT NULL,
    [producingOperation] NVARCHAR (50)   NULL,
    [BatchID]            NVARCHAR (8)    NULL,
    [Country]            NVARCHAR (255)  NULL,
    [geocodeAccuracy]    NVARCHAR (50)   NULL,
    [NumberOfLocations]  INT             NULL,
    [NetEMLGBP]          NUMERIC (38, 8) NULL,
    [prodOpShort]        NVARCHAR (3)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_GeographicCountryAnalysis_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

