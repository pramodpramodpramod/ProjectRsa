﻿CREATE TABLE [dbo].[DataAccuracy] (
    [Id]                       INT           IDENTITY (1, 1) NOT NULL,
    [reportId]                 INT           NOT NULL,
    [BatchID]                  NVARCHAR (8)  NULL,
    [ReportingRegion]          VARCHAR (14)  NULL,
    [RecordsProcessed]         INT           NULL,
    [ProcessingComplete]       DATETIME2 (7) NULL,
    [LocationsDroppedOff]      INT           NULL,
    [TotalLocationsGaia]       INT           NULL,
    [LocationsOldDeletionDate] INT           NULL,
    [noTSI]                    INT           NULL,
    [PremiumAtZero]            INT           NULL,
    [LatestInceptionDate]      DATETIME2 (7) NULL,
    [SuppliedGeocodes]         INT           NULL,
    [batchDescription]         NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_DataAccuracyQuery_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

