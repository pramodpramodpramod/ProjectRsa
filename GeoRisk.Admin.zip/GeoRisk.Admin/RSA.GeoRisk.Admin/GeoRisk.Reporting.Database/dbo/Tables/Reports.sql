﻿CREATE TABLE [dbo].[Reports] (
    [reportId]     INT  IDENTITY (1, 1) NOT NULL,
    [reportTypeId] INT  NOT NULL,
    [date]         DATE NOT NULL,
    PRIMARY KEY CLUSTERED ([reportId] ASC),
    CONSTRAINT [FK_reports_reportTypes] FOREIGN KEY ([reportTypeId]) REFERENCES [dbo].[ReportTypes] ([reportTypeId])
);

