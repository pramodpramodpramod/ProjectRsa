﻿CREATE TABLE [dbo].[ReportTypes] (
    [reportTypeId] INT            IDENTITY (1, 1) NOT NULL,
    [reportType]   NVARCHAR (50)  NULL,
    [Description]  NVARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([reportTypeId] ASC)
);

