﻿CREATE TABLE [dbo].[DataCurrency] (
    [Id]                 INT           IDENTITY (1, 1) NOT NULL,
    [reportId]           INT           NOT NULL,
    [batchIdShort]       NVARCHAR (8)  NOT NULL,
    [prodOpShort]        NVARCHAR (3)  NULL,
    [ProcessingComplete] DATETIME2 (7) NULL,
    [producingOperation] NVARCHAR (50) NOT NULL,
    [batchIdLong]        NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_DataCurrency_ToReports] FOREIGN KEY ([reportId]) REFERENCES [dbo].[Reports] ([reportId])
);

