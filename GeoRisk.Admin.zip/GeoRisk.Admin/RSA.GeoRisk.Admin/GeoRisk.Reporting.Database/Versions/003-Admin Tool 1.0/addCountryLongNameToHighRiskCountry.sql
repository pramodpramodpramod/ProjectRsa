﻿USE [Reporting]
GO

/****** Object:  Table [dbo].[GLOBAL_HIGH_RISK_COUNTRIES]    Script Date: 15/08/2017 14:32:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter TABLE [dbo].[GLOBAL_HIGH_RISK_COUNTRIES]
Add CountryLongName nvarchar(max)
	
GO


update [dbo].[GLOBAL_HIGH_RISK_COUNTRIES]
set [dbo].[GLOBAL_HIGH_RISK_COUNTRIES].CountryLongName = [GLOBAL_EXPOSURE].[dbo].[Lookup_Country].Value
from [dbo].[GLOBAL_HIGH_RISK_COUNTRIES], [GLOBAL_EXPOSURE].[dbo].[Lookup_Country]
where [dbo].[GLOBAL_HIGH_RISK_COUNTRIES].[CountryCodeA2]=[GLOBAL_EXPOSURE].[dbo].[Lookup_Country].Code

GO