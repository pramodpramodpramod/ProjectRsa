﻿
USE [Reporting]

BEGIN TRY
    BEGIN TRANSACTION;
		ALTER TABLE [dbo].[High_Risk_Locations_Geographic]
		ADD [batchDescription] nvarchar(50) NULL
		
		ALTER TABLE [dbo].[Locations_In_Wrong_Countries]
		ADD [batchDescription] nvarchar(50) NULL
		
		ALTER TABLE [dbo].[GrossTSIGBP_ByLOB]
		ADD BatchID nvarchar(8) null;
		
		ALTER TABLE [dbo].[GrossTSIGBP_ByProdOp]
		ADD BatchID nvarchar(8) null;
		
		ALTER TABLE [dbo].[GrossTSIGBP_ByProdOp]
		ADD businessArea nvarchar(250) null;
		
		ALTER TABLE [dbo].[locationsByLOB]
		ADD BatchID nvarchar(8) null;
		
		ALTER TABLE [dbo].[locationsByProdOp]
		ADD BatchID nvarchar(8) null;
		
		ALTER TABLE [dbo].[locationsByProdOp]
		ADD businessArea nvarchar(250) null;
		
		ALTER TABLE [dbo].[locationsByProdOp]
		ADD lineOfbusiness nvarchar(50) null;
		
		ALTER TABLE [dbo].[NetTSIGBP_ByProdOpGeocodeAccuracy]
		ADD BatchID nvarchar(8) null;
	
		ALTER TABLE [dbo].[DataAccuracy] 
		ALTER COLUMN [ReportingRegion] VARCHAR (250) NULL;

		ALTER TABLE [dbo].[GLOBAL_HIGH_RISK_COUNTRIES]
		ALTER COLUMN [RSAApproach] NVARCHAR(MAX)

	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() as ErrorNumber,
        ERROR_MESSAGE() as ErrorMessage;

    -- Test XACT_STATE for 1 or -1.
    -- XACT_STATE = 0 means there is no transaction and
    -- a commit or rollback operation would generate an error.

    -- Test whether the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state. ' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION;
    END;

    -- Test whether the transaction is active and valid.
    IF (XACT_STATE()) = 1
    BEGIN
        PRINT
            N'The transaction is committable. ' +
            'Committing transaction.'
        COMMIT TRANSACTION;   
    END;
END CATCH;
GO