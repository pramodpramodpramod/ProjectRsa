﻿USE [Reporting]

BEGIN TRY
    BEGIN TRANSACTION;

		CREATE TABLE [dbo].[BusinessArea](
			[Id] [int] IDENTITY(1,1) NOT NULL,
			[Name] [nvarchar](100) NULL,
			[DisplayName] [nvarchar](50) NULL,
		PRIMARY KEY CLUSTERED 
		(
			[Id] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY]

		
		SET IDENTITY_INSERT [dbo].[BusinessArea] ON

		INSERT INTO [dbo].[BusinessArea]
				   ([Id],[Name]
				   ,[DisplayName])
			 VALUES
					(1,'UK Commercial','UK Commercial'),
					(2,'UK Personal','UK Personal'),
					(3,'Risk Managed Europe','Risk Managed Europe'),
					(4,'WIP','WIP'),
					(5,'Ireland Commercial','Ireland Commercial'),
					(6,'Ireland Personal','Ireland Personal'),
					(7,'Canada Commercial','Canada Commercial'),
					(8,'Canada Personal','Canada Personal'),
					(9,'Denmark Commercial','Denmark Commercial'),
					(10,'Denmark Personal','Denmark Personal'),
					(11,'Norway Commercial','Norway Commercial'), 
					(12,'Norway Personal','Norway Personal') ,
					(13,'Sweden Commercial','Sweden Commercial'),
					(14,'Sweden Personal','Sweden Personal'),
					(15,'Bahrain','Bahrain'),
					(16,'Oman','Oman'),
					(17,'Saudi Arabia','Saudi Arabia'),
					(18,'UAE','UAE')

		SET IDENTITY_INSERT [dbo].[BusinessArea] OFF
	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() as ErrorNumber,
        ERROR_MESSAGE() as ErrorMessage;

    -- Test XACT_STATE for 1 or -1.
    -- XACT_STATE = 0 means there is no transaction and
    -- a commit or rollback operation would generate an error.

    -- Test whether the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state. ' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION;
    END;

    -- Test whether the transaction is active and valid.
    IF (XACT_STATE()) = 1
    BEGIN
        PRINT
            N'The transaction is committable. ' +
            'Committing transaction.'
        COMMIT TRANSACTION;   
    END;
END CATCH;
GO