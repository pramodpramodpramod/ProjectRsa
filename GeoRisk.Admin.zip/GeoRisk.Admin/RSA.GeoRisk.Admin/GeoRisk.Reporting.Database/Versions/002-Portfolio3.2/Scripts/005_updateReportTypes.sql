﻿USE [Reporting]

BEGIN TRY
    BEGIN TRANSACTION;

		UPDATE [dbo].[ReportTypes]
				SET [reportType] = 'Number of Locations by Business Area'
					,[Description] = 'The total count of locations for each Business Area.'
				WHERE [reportType] = 'Number of Locations by Producing Operation'

		UPDATE [dbo].[ReportTypes]
				SET [reportType] = 'Gross TSI (GBP) by Business Area'
					,[Description] = 'The Gross Total Sums Insured in GBP for each Business Area.'
				WHERE [reportType] = 'Gross TSI (GBP) by Producing Operation'

	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() as ErrorNumber,
        ERROR_MESSAGE() as ErrorMessage;

    -- Test XACT_STATE for 1 or -1.
    -- XACT_STATE = 0 means there is no transaction and
    -- a commit or rollback operation would generate an error.

    -- Test whether the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state. ' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION;
    END;

    -- Test whether the transaction is active and valid.
    IF (XACT_STATE()) = 1
    BEGIN
        PRINT
            N'The transaction is committable. ' +
            'Committing transaction.'
        COMMIT TRANSACTION;   
    END;
END CATCH;
GO