﻿USE [Reporting]

BEGIN TRY
    BEGIN TRANSACTION;

		EXEC('ALTER PROCEDURE [dbo].[generateHighRiskLocationsGeographicReport]
		-- Add the parameters for the stored procedure here
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;

			-- Insert statements for procedure here
		
			--this is the table that will store details on the records inserted into reports
			declare @IdentityOutput table ( ID int )

			--generating a new High Risk Locations Geographic report, so lets insert that into the reports table
			insert into [Reporting].[dbo].[Reports]
				 ([reportTypeId],[date])
			output inserted.reportId into @IdentityOutput
			values
				 ((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Locations within High Risk Countries''),GETDATE())

			--get the identity value of the single record that was inserted into the reports table
			declare @IdentityValue int
			select @IdentityValue = (select ID from @IdentityOutput)

			insert into [Reporting].[dbo].[High_Risk_Locations_Geographic]
			SELECT
				@IdentityValue,
				Exposures.uniqueLocationIdentifier,
				Exposures.producingOperation,
				Exposures.batchID,
				Exposures.lineOfBusiness,
				Exposures.policyNumber,
				Exposures.nameOfInsured,
				Exposures.netEstimatedMaximumLossGBP,
				Exposures.grossEstimatedMaximumLossGBP,
				Exposures.netTotalSumInsuredGBP,
				Exposures.grossTotalSumInsuredGBP,
				Exposures.Shape,
				Exposures.bestAddress,
				Exposures.geocodeAccuracy,
				Exposures.geocodeSource,
				Exposures.country,
				HighRiskCountries.Classification,
				HighRiskCountries.CountryCodeA2,
				HighRiskCountries.RSAApproach,
				Exposures.prodOpShort,
				Exposures.country,
				Exposures.producingOffice, -- new: nvarchar(50) null
				Exposures.rsaShare, -- new: numeric (38,6) null
				Exposures.layerCurrency, -- new: nvarchar(3) not null (need to make null)
				Exposures.attachmentPoint, -- new: numeric (38,8) not null (need to make null)
				Exposures.lossLimit, -- new: numeric (38,8) null 
				Exposures.policySystem, -- new: nvarchar(50) null
				Exposures.exposureType, --new:  nvarchar(100) null
				Exposures.policyNotes, --new:  nvarchar(1024) null
				Exposures.locationNotes, --new:  nvarchar(1024) null
				Exposures.businessDescription,-- new: nvarchar(100) null
				Exposures.productSchemeName, -- new: nvarchar(50) null
				Exposures.peril, -- new: nvarchar(max) null
				Exposures.locationEffectiveDate, -- new: datetime2(7) not null (need to make null)
				Exposures.locationDeletionDate, -- new: datetime2(7) not null (need to make null)
				Exposures.localClientName, -- new: nvarchar(255) null 
				Exposures.hazardCategory, -- new: nvarchar(50) null
				Exposures.batchDescription

			FROM [dbo].[locations_reporting] Exposures--, [base].[dbo].[GLOBAL_COUNTRIES_UPDATE] global_countries
			JOIN
				(SELECT *
				FROM [Reporting].[dbo].[GLOBAL_HIGH_RISK_COUNTRIES]
				WHERE Classification in (''RED'',''YLW'')) HighRiskCountries
		
			ON 1=1
			WHERE HighRiskCountries.Shape.STContains(Exposures.Shape) = 1 and Exposures.countryA2 = HighRiskCountries.CountryCodeA2

			ORDER BY HighRiskCountries.CountryCodeA2, HighRiskCountries.Classification--,Country 
		END
		')

		EXEC('ALTER PROCEDURE [dbo].[generateGrossTSIGBP_ByLOB] 
			AS
			BEGIN
				SET NOCOUNT ON;
				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Gross TSI (GBP) by Line of Business''),GETDATE())

				--get the identity value of the single record that was inserted into the reports table
				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[GrossTSIGBP_ByLOB]
				SELECT  
					@IdentityValue,
					--b.Value ProducingOperation, 
					c.Value LineOfBusiness, 
					COUNT (*) Location_Count, 
					SUM([grossTotalSumInsuredGBP]) GrossTSI_GBP,
					MAX(c.Code) LOBShort,
					MAX(b.Code) ProdOpShort,
					a.batchID

				FROM [dbo].[locations_reporting] as a
				LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
				ON a.producingOperation = b.Value
				LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_LineOfBusiness] as c
				ON a.lineOfBusiness = c.Value
				GROUP BY c.Value, b.Value, a.batchID
				ORDER BY c.Value, b.Value, a.batchID
			END')

		EXEC('ALTER PROCEDURE [dbo].[generateGrossTSIGBP_ByProdOp] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Gross TSI (GBP) by Business Area''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[GrossTSIGBP_ByProdOp]
				SELECT  
					@IdentityValue,
					b.Value ProducingOperation, 
					COUNT (*) Location_Count, 
					SUM([grossTotalSumInsuredGBP]) GrossTSI_GBP,
					MAX(b.Code) ProdOpShort,
					a.batchID,
					h.DisplayName as businessArea

				FROM [dbo].[locations_reporting] as a
				LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
				ON a.producingOperation = b.Value
				LEFT JOIN
				(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
					LEFT JOIN
						(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
					ON rb.BusinessAreaId = i.Id
				) as h

				on a.batchID = h.BatchId
				GROUP BY b.Value,a.batchID, h.DisplayName
				ORDER BY b.Value,a.batchID

			END')

		EXEC('ALTER PROCEDURE [dbo].[generateLocationsByLOB] 
				AS
				BEGIN
					SET NOCOUNT ON;

					declare @IdentityOutput table ( ID int )

					insert into [Reporting].[dbo].[Reports]
							([reportTypeId],[date])
					output inserted.reportId into @IdentityOutput
					values
							((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Number of Locations by Line of Business''),GETDATE())

					declare @IdentityValue int
					select @IdentityValue = (select ID from @IdentityOutput)

					Insert into [Reporting].[dbo].[locationsByLOB]
					SELECT  
						@IdentityValue,
						c.Value LineOfBusiness, 
						COUNT (*) Location_Count, 
						MAX(c.Code) LOBShort,
						MAX(b.Code) ProdOpShort,
						a.batchID

					FROM [dbo].[locations_reporting] as a
					LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as b
					ON a.producingOperation = b.Value
					LEFT JOIN [GLOBAL_EXPOSURE].[dbo].[Lookup_LineOfBusiness] as c
					ON a.lineOfBusiness = c.Value
					GROUP BY c.Value, b.Value,a.batchID
					ORDER BY c.Value, b.Value,a.batchID
				END')

		EXEC('ALTER PROCEDURE [dbo].[generateLocationsByProdOpReport] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Number of Locations by Business Area''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[locationsByProdOp]
			
				SELECT @IdentityValue,
					[prodOpShort],
					max([producingOperation]) as prodOpLong,
					count([prodOpShort]) locationCount,
					lr.batchID as batchId,
					h.DisplayName as businessArea,
					lr.lineOfbusiness
	  
				FROM [dbo].[locations_reporting] lr

				LEFT JOIN
						(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
							LEFT JOIN
								(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
							ON rb.BusinessAreaId = i.Id
						) as h
				on lr.batchID=h.BatchId

				group by lr.prodOpShort, lr.batchID, h.DisplayName, lr.lineOfbusiness

			END')

		EXEC('ALTER PROCEDURE [dbo].[generateNetTSIGBP_ByProdOpGeocodeAccuracy] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

		
				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Geocode Accuracy''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				insert into [dbo].[NetTSIGBP_ByProdOpGeocodeAccuracy]
				SELECT 
					@IdentityValue,
					producingOperation, 
					CASE geocodeAccuracy 
					  WHEN ''Administrative Area'' THEN ''Settlement'' 
					  WHEN ''City / Locality'' THEN ''Settlement''  
					  WHEN ''Country'' THEN ''Country''  
					  WHEN ''Point of Interest'' THEN ''Street''
					  WHEN ''Postal Code Full'' THEN ''Postcode''  
					  WHEN ''Postal Code Partial'' THEN ''Postcode''  
					  WHEN ''Property Interpolated'' THEN ''Property''  
					  WHEN ''Property Rooftop'' THEN ''Property''  
					  WHEN ''Street'' THEN ''Street''  
					  ELSE '''' 
					END as geocodeAccuracy,
					COUNT(*) NumberOfLocations,
					SUM(netTotalSumInsuredGBP) netTSI_GBP,
					MAX(GeocodingTable.prodOpShort),
					batchID
			
				FROM 
					(SELECT	
					producingOperation,
					prodOpShort,
					geocodeAccuracy,
					netTotalSumInsuredGBP,
					batchID
					FROM [dbo].[locations_reporting]) GeocodingTable
				where geocodeAccuracy is not null and geocodeAccuracy <> ''''
		  
				GROUP BY producingOperation, geocodeAccuracy, batchID
				ORDER BY producingOperation, geocodeAccuracy, batchID
			END')

		EXEC('alter PROCEDURE [dbo].[generateDataAccuracyReport] 
			AS
			BEGIN
				SET NOCOUNT ON;

				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Batch Upload Accuracy''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				Insert into [Reporting].[dbo].[DataAccuracy]

				SELECT
					@IdentityValue,
					a.FK_Batch_BatchID,
					h.DisplayName,
					a.RecordsProcessed,
					a.ProcessingComplete,
					(a.RecordsProcessed-b.TotalLocationsGaia) LocationsDroppedOff,
					b.TotalLocationsGaia,
					c.LocationsOldDeletionDate,
					d.noTSI,
					e.PremiumAtZero,
					f.LatestInceptionDate,
					g.SuppliedGeocodes,
					d.batchDescription
				FROM 

					(select FK_Batch_BatchID, RecordsProcessed, ProcessingComplete from [GLOBAL_EXPOSURE].[dbo].[BatchProcessJob]
					 where JobStatus = ''live'') as a

				LEFT JOIN 

					(select batchID, count(*) as TotalLocationsGaia from [dbo].[locations_reporting] 
					 group by batchID) as b

				ON a.FK_Batch_BatchID = b.batchID 

				LEFT JOIN

					(select batchID, count(*) as LocationsOldDeletionDate from [dbo].[locations_reporting] 
					 where locationDeletionDate < GETDATE ()
					 group by batchID) as c

				ON b.batchID = c.batchID

				LEFT JOIN 

					(select batchID, max(batchDescription) as batchDescription ,count(*) as noTSI from [dbo].[locations_reporting]
					 where netTotalSumInsuredGBP = 0
					 group by batchID) as d
		 
				ON a.FK_Batch_BatchID = d.batchID

				LEFT JOIN

					(select batchID, count(*) as PremiumAtZero from [dbo].[locations_reporting]--[GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
					 where grossPremiumSum <= 0
					 group by batchID) as e

				ON a.FK_Batch_BatchID = e.batchID

				LEFT JOIN

					(select batchID, COUNT(*) SuppliedGeocodes from [dbo].[locations_reporting]-- [GLOBAL_EXPOSURE].[dbo].[locations_vw_currency]
					WHERE addressType = ''Supplied''
					GROUP BY batchID) as g

				ON a.FK_Batch_BatchID = g.batchID

				LEFT JOIN

					(select batchID, max(locationEffectiveDate) as LatestInceptionDate from [dbo].[locations_reporting]
					 where locationEffectiveDate <= GETDATE ()
					 group by batchID) as f

				ON a.FK_Batch_BatchID = f.batchID

				LEFT JOIN
				(SELECT [BatchId],[Description],[BusinessAreaId], i.DisplayName FROM [dbo].[ReportingBatch] rb
					LEFT JOIN
						(SELECT [Id], [Name],[DisplayName] FROM [dbo].[BusinessArea]) as i
					ON rb.BusinessAreaId = i.Id
				) as h

				on a.FK_Batch_BatchID = h.BatchId

				ORDER BY a.FK_Batch_BatchID

			END')

		EXEC('ALTER PROCEDURE [dbo].[getHighRiskLocations] 
			@reportId int
			AS
			BEGIN
				SET NOCOUNT ON;
				SELECT 
				  IntersectingCountryName,
				  h.BatchID,
				  MAX(producingOperation) as producingOperation,
				  MAX(po.code) as prodOpShort,
				  Classification,
				  count(*) as [Number_of_Locations],
				  rb.Description as batchDescription
				FROM [Reporting].[dbo].[High_Risk_Locations_Geographic] as h
				LEFT JOIN
				[dbo].[ReportingBatch] as rb
				ON h.BatchID = rb.BatchId, 
				[GLOBAL_EXPOSURE].[dbo].[Lookup_ProducingOperation] as po
				where reportId=@reportId and h.producingOperation = po.Value COLLATE Latin1_General_CI_AS

				group by h.BatchID, IntersectingCountryName, Classification, rb.Description
				order by [Number_of_Locations] desc
				
			END')

		EXEC('ALTER PROCEDURE [dbo].[getHighRiskLocationsByIntersectingCountryName] 
			@reportId int,
			@IntersectingCountryName nvarchar(200),
			@batch nvarchar(50)

			AS
			BEGIN

				SELECT 	
				  producingOperation,
				  IntersectingCountryName,
				  policyNumber,			   
				  nameOfInsured,
				  lineOfBusiness, 
				  bestAddress,
				  geocodeAccuracy,
				  BatchID as batchId,
				  netEstimatedMaximumLossGBP,
				  grossEstimatedMaximumLossGBP,
				  netTotalSumInsuredGBP,
				  grossTotalSumInsuredGBP,
				  SHAPE.STAsText()  as Shape
			  FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
			  where reportId=@reportId and IntersectingCountryName = @IntersectingCountryName and @batch=batchId	  
			END')

		EXEC('ALTER PROCEDURE [dbo].[getHighRiskLocationsByRegionForExport]

			@reportId int,
			@regionDisplayName nvarchar(50)

			AS
			BEGIN
		
				IF(@regionDisplayName = ''Global'')
					SELECT 	
						producingOperation,
						[producingOffice],
						IntersectingCountryName,
						policyNumber,	
						[policySystem],[policyNotes],[localClientName],	   
						nameOfInsured,
						lineOfBusiness, [locationEffectiveDate],[locationDeletionDate],
						bestAddress,[locationNotes],
						geocodeAccuracy,
						BatchID as batchId,
						netEstimatedMaximumLossGBP,
						grossEstimatedMaximumLossGBP,
						netTotalSumInsuredGBP,
						grossTotalSumInsuredGBP,[rsaShare],[layerCurrency],[attachmentPoint],[lossLimit],[exposureType],[peril],[hazardCategory],[Classification],[RSAApproach],[businessDescription],[productSchemeName],
						SHAPE.STAsText() as Shape
					FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
					where reportId=@reportId 
				ELSE 
					SELECT 	
						producingOperation,
						[producingOffice],
						IntersectingCountryName,
						policyNumber,	
						[policySystem],[policyNotes],[localClientName],	   
						nameOfInsured,
						lineOfBusiness, [locationEffectiveDate],[locationDeletionDate],
						bestAddress,[locationNotes],
						geocodeAccuracy,
						BatchID as batchId,
						netEstimatedMaximumLossGBP,
						grossEstimatedMaximumLossGBP,
						netTotalSumInsuredGBP,
						grossTotalSumInsuredGBP,[rsaShare],[layerCurrency],[attachmentPoint],[lossLimit],[exposureType],[peril],[hazardCategory],[Classification],[RSAApproach],[businessDescription],[productSchemeName],
						SHAPE.STAsText() as Shape
					FROM [Reporting].[dbo].[High_Risk_Locations_Geographic]	  
					where reportId=@reportId and batchId in (select [BatchId] from [dbo].[ReportingBatch] where [BusinessAreaId] = (Select Id from [dbo].[BusinessArea] Region where DisplayName=@regionDisplayName))	  
			END')

		EXEC('ALTER PROCEDURE [dbo].[generateLocationsInWrongCountries]
		
			AS
			BEGIN
				SET NOCOUNT ON;
		
				declare @IdentityOutput table ( ID int )

				insert into [Reporting].[dbo].[Reports]
						([reportTypeId],[date])
				output inserted.reportId into @IdentityOutput
				values
						((select [reportTypeId] from [Reporting].[dbo].[ReportTypes] where reportType=''Locations In Wrong Countries''),GETDATE())

				declare @IdentityValue int
				select @IdentityValue = (select ID from @IdentityOutput)

				insert [Reporting].[dbo].[Locations_In_Wrong_Countries]
					select * from(
					SELECT
						@IdentityValue as reportId,
						Exposures.producingOperation,
						Exposures.BatchID,
						Exposures.country,
						--Exposures.countryA2,
						Exposures.policyNumber,
						Exposures.nameOfInsured,
						Exposures.lineOfBusiness,
						Exposures.Shape,
						Exposures.bestAddress,
						Exposures.netEstimatedMaximumLossGBP,
						GLOBAL_COUNTRIES.Name,
						GLOBAL_COUNTRIES.[CountryCodeA2] as Country_A2CODE,
						Exposures.countryA2 as Expsoure_A2CODE,
						Exposures.prodOpShort,
						rb.Description as batchDescription 

					FROM [Reporting].[dbo].[locations_reporting] Exposures
					LEFT JOIN
						[dbo].[ReportingBatch] as rb
					ON Exposures.BatchID = rb.BatchId
					LEFT JOIN [base].[dbo].[GLOBAL_COUNTRIES] GLOBAL_COUNTRIES
					ON GLOBAL_COUNTRIES.Shape.STContains(Exposures.Shape) = 1) wrong_country
			
					where
					wrong_country.Country_A2CODE <> wrong_country.Expsoure_A2CODE
			END')
	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() as ErrorNumber,
        ERROR_MESSAGE() as ErrorMessage;

    -- Test XACT_STATE for 1 or -1.
    -- XACT_STATE = 0 means there is no transaction and
    -- a commit or rollback operation would generate an error.

    -- Test whether the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state. ' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION;
    END;

    -- Test whether the transaction is active and valid.
    IF (XACT_STATE()) = 1
    BEGIN
        PRINT
            N'The transaction is committable. ' +
            'Committing transaction.'
        COMMIT TRANSACTION;   
    END;
END CATCH;
GO