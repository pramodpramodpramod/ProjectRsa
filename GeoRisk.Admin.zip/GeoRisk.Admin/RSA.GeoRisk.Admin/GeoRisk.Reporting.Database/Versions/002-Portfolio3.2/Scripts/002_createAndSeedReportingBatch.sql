﻿USE [Reporting]

BEGIN TRY
    BEGIN TRANSACTION;
		CREATE TABLE [dbo].[ReportingBatch]
		(
			[Id]  INT            IDENTITY (1, 1) NOT NULL, 
			[BatchId]            nvarchar(8) NOT NULL UNIQUE,
			[Description]        nvarchar(50) NULL,
			[BusinessAreaId]	 INT NULL, 
			PRIMARY KEY CLUSTERED ([Id] ASC), 
			CONSTRAINT [FK_Batch_To_BusinessArea] FOREIGN KEY ([BusinessAreaId]) REFERENCES [BusinessArea]([Id])
		)

		SET IDENTITY_INSERT [dbo].[ReportingBatch] ON
		INSERT INTO [dbo].[ReportingBatch]
				([Id],[BatchId],[Description],[BusinessAreaId])
			VALUES	
			(1,'BAH_MAIN','Bahrain Main',15),
			(2,'CAN_COMM','RSA Canada Commercial inc mid-market, GSL, UC',7),
			(3,'CAN_ENGI','RSA Canada Equipment Breakdown',7),
			(4,'CAN_GSLC','RSA Canada GSL and GCAN GSL',7),
			(5,'CAN_PERS','RSA Canada Personal Lines including UC',8),
			(6,'CNS_COMM','CNS Commercial Lines',7),
			(7,'CNS_PERS','CNS Personal Lines',8),
			(8,'COA_MAIN','Coast Main File',7),
			(9,'DEN_COMM','Denmark Commercial Lines Multi-Layered',9),
			(10,'DEN_PERS','Denmark Personal Lines Multi-Layered',10),
			(11,'IRE_BENC','Ireland Commercial Lines ISMIS',5),
			(12,'IRE_BENP','Ireland Personal Lines ISMIS',6),
			(13,'IRE_FACR','Ireland Non-Proportional FAC',null),
			(14,'IRE_GENC','Ireland Commercial lines Genius',5),
			(15,'IRE_GENP','Ireland Personal Lines Genius',6),
			(16,'IRE_KENN','Ireland KennCo Scheme',6),
			(17,'IRE_NIRE','Northern Ireland Transactions',5),
			(18,'JON_PERS','Johnson Personal Lines',8),
			(19,'NOR_COMP','Norway Complex File',11),
			(20,'OMA_MAIN','Oman Main',16),
			(21,'RSK_BELG','Risk Managed Belgium with Limits',3),
			(22,'RSK_FRAN','Risk Managed France with Limits',3),
			(23,'RSK_NETH','Risk Managed Netherlands with Limits',3),
			(24,'RSK_REAL','Risk Managed Real Estate with Limits',3),
			(25,'RSK_SPAI','Risk Managed Spain with Limits',3),
			(26,'RSK_UKUK','Risk Managed UK with Limits',3),
			(27,'RSK_MEES','RSK Mees and Zoonen',3),
			(28,'SAU_MAIN','Saudi Arabia Main',17),
			(29,'SWE_COMM','Sweden Commercial Lines Multi-Layered',13),
			(30,'SWE_PERS','Sweden Personal Lines Multi-Layered',14),
			(31,'UAE_MAIN','United Arab Emirates Main',18),
			(32,'UK_ACTUR','UK Acturis Locations',1),
			(33,'UK_AFBK3','UK PL 03 Affinity/Broker',2),
			(34,'UK_AFOT5','UK PL 05 Affinity Other',2),
			(35,'UK_AISPR','UK AIS Commercial Property',1),
			(36,'UK_AIUA1','UK AIUA',1),
			(37,'UK_CANDE','UK Construction and Engineering',1),
			(38,'UK_CARVN','UK PL 14 Caravanguard',2),
			(39,'UK_CIPOP','UK CI POPA Locations',1),
			(40,'UK_CLR06','UK PL 06 Clearchoice',2),
			(41,'UK_CQEPO','UK CQE Property Owners',1),
			(42,'UK_CYB02','UK PL 02 NAG',2),
			(43,'UK_DIFCE','UK DIFC Engineering',1),
			(44,'UK_DIFCP','UK DIFC Property',1),
			(45,'UK_HNW09','UK PL 09 HNW/MNW inc Oak',2),
			(46,'UK_ICCI1','UK ICCI Commercial',1),
			(47,'UK_JLWIS','UK PL 16 JL',2),
			(48,'UK_MARCQ','UK Marine CQE',1),
			(49,'UK_MARLN','UK Marine London',1),
			(50,'UK_MARNT','UK Marine North',1),
			(51,'UK_MARSH','UK Marine Ship Construction',1),
			(52,'UK_MARST','UK Marine South',1),
			(53,'UK_MCREA','UK Multi Client Real Estate',1),
			(54,'UK_MCREG','UK Multi Client Regions',1),
			(55,'UK_MCSME','UK Multi Client SME',1),
			(56,'UK_MRTHN','UK PL MT MoreThan',2),
			(57,'UK_MTLEG','UK PL MT MoreThan_Legacy',2),
			(58,'UK_NATBK','UK PL 07 & 08 National Broker',2),
			(59,'UK_OTBRK','UK PL 10 Other Broker',2),
			(60,'UK_OTHCM','UK PL 15 Other Commercial Schemes',2),
			(61,'UK_PEN12','UK PL 12 PEN/OIM',2),
			(62,'UK_PYSHD','UK PL 13 Paymentshield',2),
			(63,'UK_REGIO','UK Regions Commercial',1),
			(64,'UK_TESCO','UK PL 17 Tesco',2),
			(65,'UK_TOWER','UK Tower Commercial',1),
			(66,'UK_TWG11','UK PL 11 Towergate',2),
			(67,'UK_UKDOM','UK UKRIS Domestic',1),
			(68,'UK_UKRIS','UK UKRIS',1),
			(69,'UK_YBS01','UK PL 01 YBS',2),
			(70,'WIP_MAIN','Wholesale International Property Book',4),
			(71,'ARGEXIST','',null),
			(72,'BATCHTTS','',null),
			(73,'BRA_MAIN','',15),
			(74,'CHI_MAIN','',null),
			(75,'CNAEXIST','',null),
			(76,'CNS_MAIN','',7),
			(77,'CNSEXIST','',7),
			(78,'COL_MAIN','',null),
			(79,'DEN_COMP','',9),
			(80,'DEN_MAIN','',9),
			(81,'EGAIADEN','',null),
			(82,'EGAIAIR2','',null),
			(83,'EGAIAIR3','',null),
			(84,'ELC_MAIN','',null),
			(85,'ENDAVA02','',null),
			(86,'ENDAVA05','',null),
			(87,'ENDAVADI','',null),
			(88,'ENDAVRSK','',null),
			(89,'ENSF161M','',null),
			(90,'ENSF163N','',null),
			(91,'ENUKTEST','',null),
			(92,'GCA_MAIN','',7),
			(93,'IND_MAIN','',null),
			(94,'IRE_MAIN','',5),
			(95,'ITA_MAIN','',null),
			(96,'JMETER02','',null),
			(97,'JON_MAIN','',8),
			(98,'JONEXIST','',8),
			(99,'MEXEXIST','',null),
			(100,'NOR_MAIN','',11),
			(101,'RSK_CPLX','',3),
			(102,'RSK_LGCY','',3),
			(103,'RSK_MAIN','',3),
			(104,'RSK_REGI','',3),
			(105,'RSK_REOS','',3),
			(106,'RSK_TEST','',null),
			(107,'RSK_TOWE','',3),
			(108,'RSKEXIST','',3),
			(109,'RSK-TEST','',null),
			(110,'RSKUKEXI','',3),
			(111,'RUS_MAIN','',null),
			(112,'SWE_MAIN','',13),
			(113,'UK_AFFIN','',2),
			(114,'UK_BROKE','',2),
			(115,'UK_HMELG','',2),
			(116,'UK_MAREU','',1),
			(117,'UK_MARIN','',1),
			(118,'UK_MORET','',2),
			(119,'UK_OAKPE','',2),
			(120,'UK_OIMPE','',2),
			(121,'UK_OTHNW','',2),
			(122,'UK_PAYME','',2),
			(123,'UK_RTAIL','',2),
			(124,'UK_TULP1','',2),
			(125,'UK_WIPDB','',4),
			(126,'URU_MAIN','',null),
			(127,'WIP_DBUK','',4),
			(128,'WIP_UKDB','',4),
			(129,'IRE_GPCE','Ireland Commercial Property C&E Genius',5)


					
		SET IDENTITY_INSERT [dbo].[ReportingBatch] OFF
	COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() as ErrorNumber,
        ERROR_MESSAGE() as ErrorMessage;

    -- Test XACT_STATE for 1 or -1.
    -- XACT_STATE = 0 means there is no transaction and
    -- a commit or rollback operation would generate an error.

    -- Test whether the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state. ' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION;
    END;

    -- Test whether the transaction is active and valid.
    IF (XACT_STATE()) = 1
    BEGIN
        PRINT
            N'The transaction is committable. ' +
            'Committing transaction.'
        COMMIT TRANSACTION;   
    END;
END CATCH;
GO