﻿import { Injectable} from '@angular/core'
import { Http, RequestOptions, Headers } from '@angular/http'
import 'rxjs/add/operator/toPromise';
import { Role } from "../objects/admin/role";

@Injectable()
export class AdminService {

    constructor(private http: Http) { }

    results: any;
    private adminServiceUrl= 'http://localhost:37147/api';

    //by leaving roleNames = null, we get users for all roles
    getUsers(applicationName: string): Promise<any>{

        return this.http.get(this.adminServiceUrl + '/users/' + applicationName + '?rolenames=')
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError);
        
    }

    getUsersDetailsForExport(applicationName: string){
        return this.http.get(this.adminServiceUrl + '/users/export/' + applicationName)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError);
    }

    deleteUser(userName: string, applicationName: string) {
        return this.http.get(this.adminServiceUrl + '/user/' + applicationName + '/delete?username=' + userName)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError)
    }

    createUser(userName: string, applicationName: string) {
        return this.http.get(this.adminServiceUrl + '/user/' + applicationName + '/create?username=' + userName)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError)
    }

    createUserExtended(userDetails: any, applicationName: string) {
        let headers      = new Headers({ 'Content-Type': 'application/json' }); 
        let options       = new RequestOptions({headers:headers});
        //let userDetailsArray =[]
        //userDetailsArray.push(userDetails)
        return this.http.post(this.adminServiceUrl + '/user/' + applicationName + '/create/extended', JSON.stringify(userDetails), options)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError)
    }

    alterUserRoles(userName: string, applicationName: string, roles: Role[], operation: string ){
        return this.http.get(this.adminServiceUrl + '/user/' + applicationName + '/roles/'+operation+'?username=' + userName+ '&rolenames='+roles.map(w => w.RoleName).join(','))
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError)
    }


    getAllRoles(appName: string): Promise<any> {

        return this.http.get(this.adminServiceUrl + '/roles/' + appName)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError);
    }

    getRolesForUser(appName: string, userName: string): Promise<any> {
        return this.http.get(this.adminServiceUrl + '/roles/user/' + appName + '?username=' + userName)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError);
    }

    findUserInActiveDirectory(userName: string) :Promise<any>{
        return this.http.get(this.adminServiceUrl + '/user/ad?username=' + userName)
            .toPromise()
            .then(response =>
                response.json()
            )
            .catch(this.handleError);
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
}