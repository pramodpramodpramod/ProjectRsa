﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
//import { HttpParams } from '@angular/common';
//import { HttpParams, HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';

import { App } from '../objects/georiskapps/app';
import { Service } from '../objects/georiskapps/service';
import { Observable } from "rxjs/Rx";
//import { APPS } from '../mocks/mock-apps'


@Injectable()

export class GeoriskAppsService {

    constructor(private http: Http) { }

    private georiskappsUrl = 'http://localhost:53866/api';//;api/applications';  // URL to web api

    doesExist(){
        return true;
    }

    // A best practice: keeping all the stream manipulation logic inside our service and return the Observable
    
    // getApps2(): Observable<any> {
    //     return this.http.get(this.georiskappsUrl+'/apps')
    //     .map((res: any) => res.json() as App[]);
    // }
    //
    
    getApps(): Promise<App[]> {
        //return Promise.resolve(APPS);

        return this.http.get(this.georiskappsUrl+'/apps')
            //.map(response => response.json().data as App[]);
            .toPromise()
            //The response JSON has a single data property, which holds the array of APPS that the caller wants. So you grab that array and return it as the resolved Promise value.
            .then((response) =>
                 response.json()
             )
            .catch(this.handleError);
    }

    getAppServices(appName): Promise<Service[]> {
        return this.http.get(this.georiskappsUrl+ '/services/' + appName)
            .toPromise()
            //The response JSON has a single data property, which holds the array of APPS that the caller wants. So you grab that array and return it as the resolved Promise value.
            .then((response:any) => 
                response.json() as Service[]
            )
            .catch(this.handleError);
    }

    getBusinessTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/businesstypes')
            .toPromise()
            .then((response:any) => response.json())
            .catch(this.handleError);
    }
    
    getBusinessTypes2(): Observable<any> {
        return this.http.get(this.georiskappsUrl + '/businesstypes').map((res: any) => res.json());
    }

    getBaseMapStyles(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/basemapstyles')
            .toPromise()
            .then((response:any) => response.json())
            .catch(this.handleError);
    }

    getBaseMapStyles2(): Observable<any> {
        return this.http.get(this.georiskappsUrl + '/basemapstyles').map((res: any) => res.json());
            // .toPromise()
            // .then(response => response.json())
            // .catch(this.handleError);
    }

    getLeafletTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/leaflettypes')
            .toPromise()
            .then((response:any) => response.json())
            .catch(this.handleError);
    }

    getLeafletTypes2(): Observable<any> {
        return this.http.get(this.georiskappsUrl + '/leaflettypes').map((res: any) => res.json());
            // .toPromise()
            // .then(response => response.json())
            // .catch(this.handleError);
    }

    getMapServiceTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/mapservicetypes')
            .toPromise()
            .then((response:any) => response.json())
            .catch(this.handleError);
    }

    getMapServiceTypes2(): Observable<any> {
        return this.http.get(this.georiskappsUrl + '/mapservicetypes').map((res: any) => res.json());
            // .toPromise()
            // .then(response => response.json())
            // .catch(this.handleError);
    }

    getServiceTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/servicetypes')
            .toPromise()
            .then((response:any) => response.json())
            .catch(this.handleError);
    }

    getServiceTypes2(): Observable<any> {
        return this.http.get(this.georiskappsUrl + '/servicetypes').map((res: any) => res.json());
            // .toPromise()
            // .then(response => response.json())
            // .catch(this.handleError);
    }

    saveServiceEdits(body:Service):Observable<any>{
        let bodyString = JSON.stringify(body); // Stringify payload
        let headers      = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        //let requestOptions = new RequestOptions();
        //requestOptions.params = params;
        let options       = new RequestOptions({headers:headers});


        return this.http.put(this.georiskappsUrl +'/service/edit/'+body.serviceId, bodyString,options)
            .map((res:any) => 
                res.json()
            ).catch(this.handleError); //...errors if any
    }

    createNewServiceEntry(body:Service, appname:string):Observable<any>{
        let bodyString = JSON.stringify(body); // Stringify payload
        let headers      = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options       = new RequestOptions({headers:headers});

        return this.http.post(this.georiskappsUrl +'/service/create/'+appname, bodyString,options
                //{params: new HttpParams().set('appname', appname)}
            ) // ...using post request
            .map((res:any) => 
                res.json()
            ).catch(this.handleError); //...errors if any
             // ...and calling .json() on the response to return data
            
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
}