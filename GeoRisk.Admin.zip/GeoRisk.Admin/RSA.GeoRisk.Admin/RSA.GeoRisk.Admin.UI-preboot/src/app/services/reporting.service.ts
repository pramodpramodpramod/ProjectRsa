﻿import {Injectable} from '@angular/core'
import { Http, RequestOptions,Headers } from '@angular/http'
import { Observable } from "rxjs/Observable";


@Injectable()

export class ReportingService{
   
    private reportingServiceUrl = 'http://localhost:37147/api';

    constructor (private http:Http){}

    getBatches():Observable<any>{
        //return this.http.get(this.reportingServiceUrl+'/batches').map(resp=>resp.json())
        return this.http.get(this.reportingServiceUrl+'/reportingbatches').map((resp)=>{
            return resp.json()
        }).catch(
            error=>this.handleError(error)
        )
    }

    addNewBatch(body:any) : Observable<any>{
        let headers      = new Headers({ 'Content-Type': 'application/json' }); 
        let options       = new RequestOptions({headers:headers});

        return this.http.post(this.reportingServiceUrl+'/reportingbatches/add', JSON.stringify(body), options).map(resp=>{
            return resp.json()
        }).catch(
            error=>this.handleError(error)
        )
    }

    getBusinessAreas() : Observable<any>{
        return this.http.get(this.reportingServiceUrl+'/businessareas').map(resp=>{
            return resp.json()}
        ).catch(
            error=>this.handleError(error)
        )
    }

    getHighRiskCountries() : Observable<any>{
        return this.http.get(this.reportingServiceUrl+'/highriskcountries').map(resp=>{
            return resp.json()}
        ).catch(
            error=>this.handleError(error)
        )
    }

    saveChangesToSanctionCountries(newbody:any, id:string) : Observable<any>{
        let headers      = new Headers({ 'Content-Type': 'application/json-patch+json' });
        let options       = new RequestOptions({headers:headers});
        
        // we do an http PATCH here (rather than a PUT) so we can do a partial update, and we don't have to deal with spatial data
        // https://github.com/myquay/JsonPatch
        return this.http.patch(this.reportingServiceUrl + '/highriskcountries/patch/'+id, JSON.stringify(newbody), options).map(resp=>{
            return resp.json()
        }).catch(
            error=>this.handleError(error)
        )
    }

    handleError(arg0: any): any {
        throw new Error("Couldn't get reporting data: " + arg0);
    }

}