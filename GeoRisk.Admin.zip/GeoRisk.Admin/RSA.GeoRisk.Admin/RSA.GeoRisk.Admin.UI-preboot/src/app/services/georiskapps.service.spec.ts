import { inject, TestBed } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';
import { Http, BaseRequestOptions } from '@angular/http';
import { GeoriskAppsService } from "./service-barrel";


//https://semaphoreci.com/community/tutorials/testing-angular-2-http-services-with-jasmine
describe('GeoriskAppsService Test', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({providers: [
      MockBackend, 
      BaseRequestOptions,
      {
        provide: Http,
        useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
          return new Http(backendInstance, defaultOptions);
        },
        deps: [MockBackend, BaseRequestOptions]
      },
      GeoriskAppsService]});
  });

  it('service exists', inject([GeoriskAppsService], (service: GeoriskAppsService) => {
    expect(service.doesExist()).toBeTruthy();
  }));
});

