import { Injectable}  from '@angular/core'
import { Http, RequestOptions,Headers } from '@angular/http'
import { Observable } from "rxjs/Observable";

@Injectable()

export class GeoriskAppsCurrenciesService{
    
    constructor(private http:Http){}

    private georiskappsUrl = 'http://localhost:53866/api'

    getCurrencies():Observable<any>{
        return this.http.get(this.georiskappsUrl+'/lookup-currency').map(res=>res.json())
    }

    getAppCurrencies(appname : string):Observable<any>{
        return this.http.get(this.georiskappsUrl+'/app-currency/'+appname).map(res=>res.json())
    }

    addCurrency(appname : string, currencyBody:any){
        let bodyString = JSON.stringify(currencyBody); // Stringify payload
        let headers      = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options       = new RequestOptions({headers:headers});

        return this.http.post(this.georiskappsUrl+'/app-currency/'+appname+'/add',bodyString, options).map(res=>
            res.json()
        )
    }

    removeCurrency(appname : string, currencycodes : string){
        return this.http.delete(this.georiskappsUrl+'/app-currency/'+appname+'/delete?appcurrencycodes='+currencycodes).map(res=>
            res.json()
        )

    }
}