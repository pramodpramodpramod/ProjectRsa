﻿//https://stackoverflow.com/questions/14142071/typescript-and-field-initializers
export class Service {

    public constructor(init?:Partial<Service>) {
        Object.assign(this, init);
    }

    public arcGisServiceLayerName:string
    public attribution:string
    public baseMapStyle_BaseMapStyleId:Number
    public businessType_BusinessTypeId:Number
    public identify:boolean
    public isActive:boolean
    public isDefault:boolean
    public layers:string
    public leafletType_LeafletTypeId:Number
    public legendImage:string
    public legendImageUrl:string
    public mandated:boolean
    public map_MapId:Number
    public mapServiceType_MapServiceTypeId: Number
    public name:string
    public opacity:Number
    public regions:string
    public serviceId:Number
    public serviceType_ServiceTypeId: Number
    public token:string
    public url:string
    public visible:boolean
}