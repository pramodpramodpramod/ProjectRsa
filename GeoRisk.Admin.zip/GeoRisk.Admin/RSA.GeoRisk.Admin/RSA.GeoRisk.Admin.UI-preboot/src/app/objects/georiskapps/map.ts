﻿import { Service } from './service';

export class Map {
    includeLegend;
    mapExtent: { mapExtentId: number, name: string, spatialReference: string, xmax: number, xmin: number, ymax: number, ymin: number};
    mapId;
    name;
    services: Service[];
}