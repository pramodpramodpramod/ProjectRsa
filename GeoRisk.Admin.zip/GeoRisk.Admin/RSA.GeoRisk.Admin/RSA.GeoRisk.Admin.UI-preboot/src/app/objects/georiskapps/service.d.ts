export declare class Service {
    arcGisServiceLayerName: any;
    attribution: any;
    baseMapStyle: any;
    businessType: {
        businessTypeId: Number;
        name: String;
    };
    identify: any;
    isActive: any;
    isDefault: any;
    layers: any;
    leafletType: {
        leafletTypeId: Number;
        name: String;
    };
    legendImage: any;
    legendImageUrl: any;
    mandated: any;
    mapId: any;
    mapServiceType: {
        mapServiceTypeId: Number;
        name: String;
    };
    name: any;
    opacity: any;
    regions: any;
    serviceId: any;
    serviceType: {
        serviceTypeId: Number;
        name: String;
    };
    token: any;
    url: any;
    visible: any;
}
