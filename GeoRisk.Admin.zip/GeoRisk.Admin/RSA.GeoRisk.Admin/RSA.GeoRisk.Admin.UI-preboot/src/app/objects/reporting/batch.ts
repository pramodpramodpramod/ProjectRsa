
export class IBatch{
    
    public constructor(init?:Partial<IBatch>) {
        Object.assign(this, init);
    }

    public id: number
    public batchId:string
    public description: string
    public businessAreaId: number
    
}