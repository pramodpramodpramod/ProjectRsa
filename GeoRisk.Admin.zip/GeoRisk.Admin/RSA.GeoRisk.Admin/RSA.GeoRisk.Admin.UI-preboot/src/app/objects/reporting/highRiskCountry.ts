﻿//import { IShape } from "../shape";

export class HighRiskCountry {
    
    public constructor(init?:Partial<HighRiskCountry>) {
        Object.assign(this, init);
    }

    public OBJECTID:number
    public CountryCodeA2:string
    public ReasonForInclusion:string
    public RSAApproach:string
    public Classification:ClassificationType
    public CapturedBy:string
    public DateCreated:Date
    public CreatedBy:Date
    public DateModified:Date
    public ModifiedBy:string
    //public SHAPE:IShape
    public CountryLongName:string
}

export enum ClassificationType {
    RED,
    YLW,
    BLU,
    GRN,
    NON,
    ORG,
    PNK
}