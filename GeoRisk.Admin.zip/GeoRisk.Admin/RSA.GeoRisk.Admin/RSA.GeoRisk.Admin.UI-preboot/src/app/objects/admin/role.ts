export class Role {
    RoleName:string
    selected:boolean
}