import { RouterModule, Routes } from '@angular/router';
import { LocalComponent } from "./components/local/local.component";
import { AdminComponent } from "./components/admin/admin.component";
import { PortfolioComponent } from "./components/portfolio/portfolio.component";
import { AppServiceAddComponent } from "./components/app-services/app-service-add.component";
import { AppServicesMainComponent, ReportingMainComponent, AppServiceDetailComponent, AppCurrenciesComponent, BatchComponent,SanctionsComponent } from "./components/component-barrel";
import { ServiceDomainDetailsResolver } from "./components/resolvers/service-domain-details.resolver";


const routes: Routes = [
            {
              path:'reporting',
              component:ReportingMainComponent,
              children:[{
                path:'batches',
                component:BatchComponent
              },{
                path:'sanctions',
                component:SanctionsComponent
              }]
            },
            {
              path: 'local',
              component: LocalComponent,
              children: [{
                  path: 'admin',
                  component: AdminComponent,
                  data:
                  {
                      appName: 'local-ii'
                  }
                  
                },

                {
                    path: 'services',
                    component: AppServicesMainComponent,
                    data: {
                        appName: 'local'
                    }
                },{
                    path: 'services/list',
                    component: AppServiceDetailComponent,
                    data: {
                      appName: 'local'
                    },
                    resolve: {domainDetails: ServiceDomainDetailsResolver}
                  }, 
                  {
                    path: 'services/add',
                    component: AppServiceAddComponent,
                    data: {
                        appName: 'local'
                    },
                    resolve: {domainDetails: ServiceDomainDetailsResolver}
                  }
                ]
            },
            {
                path: 'portfolio',
                component: PortfolioComponent,
                children: [
                  {
                    path: 'admin',
                    component: AdminComponent,
                    data: {
                        appName: 'portfolio'
                    }
                  },
                  {
                    path:'currencies',
                    component:AppCurrenciesComponent,
                    data: {
                      appName: 'portfolio'
                    }
                  },
                  {
                    path:'services',
                    component:AppServicesMainComponent
                  },
                  {
                    path: 'services/list',
                    component: AppServiceDetailComponent,
                    data: {
                      appName: 'portfolio'
                    },
                    resolve: {domainDetails: ServiceDomainDetailsResolver}
                  }, 
                  {
                    path: 'services/add',
                    component: AppServiceAddComponent,
                    data: {
                        appName: 'portfolio'
                    },
                    resolve: {domainDetails: ServiceDomainDetailsResolver}
                  }]
            },
            { path: '**', redirectTo: 'home' }
];

export const routing = RouterModule.forRoot(routes);
