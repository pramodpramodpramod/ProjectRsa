export declare class PortfolioComponent {
}
