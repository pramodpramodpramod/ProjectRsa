import { Component } from '@angular/core';

@Component({
    selector: 'portfolio',
    templateUrl: './portfolio.component.html',
    styles: [`
        .router-link-active {font-weight: bold;}
    `]
})

export class PortfolioComponent {
}
