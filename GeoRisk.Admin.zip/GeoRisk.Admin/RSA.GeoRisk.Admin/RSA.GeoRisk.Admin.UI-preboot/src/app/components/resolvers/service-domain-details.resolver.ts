
import { Resolve } from "@angular/router";
import { GeoriskAppsService } from "../../services/service-barrel";
import { Observable } from "rxjs/Rx";
import { Injectable } from "@angular/core";
//import { Observable } from "rxjs/Rx";

@Injectable()
export class ServiceDomainDetailsResolver implements Resolve<any> {
    
    constructor(private georiskAppsService: GeoriskAppsService){}
   
    //observables in parallel: http://blog.danieleghidoli.it/2016/10/22/http-rxjs-observables-angular/
    resolve() : Observable<any>{
        
        // This resolve function expects an observable to be returned
        return Observable.forkJoin([
             this.georiskAppsService.getBusinessTypes2(),
             this.georiskAppsService.getBaseMapStyles2(),
             this.georiskAppsService.getLeafletTypes2(),
             this.georiskAppsService.getMapServiceTypes2(),
             this.georiskAppsService.getServiceTypes2()
        ])
        .map((data: any[]) => {

            let serviceDomainDetails={
                businessTypes : data[0],
                baseMapStyles : data[1],
                leafletTypes : data[2],
                mapServiceTypes : data[3],
                serviceTypes : data[4]
            }
           
            return serviceDomainDetails;
        }); 
    }
}