﻿import { Component, OnInit, Input} from '@angular/core';
import { AdminService, AlertService } from "../../services/service-barrel";
import { ActivatedRoute } from "@angular/router";
import { NgForm } from '@angular/forms';

// let TOASTR_TOKEN = new InjectionToken('toastr');
// let toastr: any

@Component({
    selector: 'admin',
    templateUrl: './admin.component.html',
    styles:[`
        em {color: #E05C65; padding-left:10px}
    `]
})


export class AdminComponent implements OnInit {
    
    
    @Input() windowsLogin: string = '';

    selectedUser: any;   
    usersExport: any;

    editsMade: boolean = false;
    foundUserInAD: any;
    userAlreadyExistsInAdminDB: boolean;
    mouseoverCreate: boolean = false;
    createUserMode: boolean = false;
    
    originalUserRoles:any[]= []

    usersRoles: any;
    allRoles: any;
    users: any;
    newUsersRoles: any = [];
    newUserAllRoles: any = [];
    currentApp: string

    selectedAllRoles: any[]=[];
    selectedUsersRoles: any[]=[];
    selectedNewUserRoles:any[]=[]
    selectedNewAllRoles:any[]=[]

    //constructor(private adminService: AdminService, private activatedRoute: ActivatedRoute, private router: Router, private toastr: ToastrService) { }
    constructor(private adminService: AdminService, private activatedRoute: ActivatedRoute, private alertService: AlertService) { 
        //const toast = injector.get(TOASTR_TOKEN);
        //this.alertService.info('this is some info..................');
    }

    ngOnInit(): void {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.getUsers();
    }

    clearRolesListBoxes(){
        this.usersRoles=[];
        this.allRoles=[];
        this.newUsersRoles=[];
        this.newUserAllRoles=[];
    }

    deleteUser() {

        let user = this.createUserMode? this.foundUserInAD.domainAccountName: this.selectedUser.UserName;
        this.adminService.deleteUser(this.selectedUser.UserName, this.currentApp).then(deleteResponse => {
            if (deleteResponse.ClassName == "System.Exception") {
                this.alertService.error(deleteResponse.InnerException.InnerException.Message + " " + deleteResponse.Message, false);
            }
            else{
                this.alertService.success(user + "  deleted from " + this.currentApp);
                this.getUsers();
                this.clearRolesListBoxes();
            }
        });
    }

    saveEdits(){
        
        let roleToRemove = this.originalUserRoles.filter(obj => { 
            return this.usersRoles.findIndex(y=>y.RoleName == obj.RoleName) == -1
        });

        let rolesToAdd = this.usersRoles.filter(obj=>{
            return this.originalUserRoles.findIndex(y=>y.RoleName == obj.RoleName) == -1
        });

        if (rolesToAdd.length > 0){
            this.adminService.alterUserRoles(this.selectedUser.UserName, this.currentApp, rolesToAdd, 'add').then(addRoleResponse => {
                if (addRoleResponse.ClassName == "System.Exception") {
                    this.alertService.error(addRoleResponse.InnerException.InnerException.Message + " " + addRoleResponse.Message, false);
                }
                else{        
                    this.alertService.success(rolesToAdd.map(w=>w.RoleName).join(',') + " roles added to " + this.selectedUser.UserName , false);
                }
            })
        }

        if(roleToRemove.length > 0){
            this.adminService.alterUserRoles(this.selectedUser.UserName, this.currentApp, roleToRemove, 'remove').then(removeRoleResponse => {
                if (removeRoleResponse.ClassName == "System.Exception") {
                    this.alertService.error(removeRoleResponse.InnerException.InnerException.Message + " " + removeRoleResponse.Message, false);
                }
                else{        
                    this.alertService.success(roleToRemove.map(w=>w.RoleName).join(',') + " roles removed from " + this.selectedUser.UserName , false);
                }
            })
        }
        //reset the user's roles
        this.originalUserRoles=[];
        Object.assign(this.originalUserRoles, this.usersRoles);
        
    }

    createUser() {
        this.adminService.createUserExtended(this.foundUserInAD, this.currentApp).then(addUserResponse => {
            if (addUserResponse.ClassName == "System.Exception") {
                this.alertService.error(addUserResponse.InnerException.InnerException.Message + " " + addUserResponse.Message, false);
            }
            else{
                //add user to roles:
                this.adminService.alterUserRoles(this.foundUserInAD.domainAccountName, this.currentApp, this.newUsersRoles, 'add').then(addUserToRolesResponse =>{
                    if (addUserToRolesResponse.ClassName == "System.Exception") {
                        this.alertService.error(addUserToRolesResponse.InnerException.InnerException.Message + " " + addUserToRolesResponse.Message, false);
                    }
                    else{
                        //success!!! 
                        this.alertService.success(this.foundUserInAD.domainAccountName + " created in " + this.currentApp + " with roles " + this.newUsersRoles.map(w=>w.RoleName).join(","));
                        //re-grab the list of users
                        this.getUsers();
                        //switch away from create mode
                        this.createUserMode=false;
                    }
                })
            }
        });
    }

    exportAllUsers(){
        this.adminService.getUsersDetailsForExport(this.activatedRoute.snapshot.data['appName']).then(usersExport=>
            this.usersExport = usersExport
        )
        //todo: put the users into a csv ready format for export
    }

    getUsers(): void {

        this.adminService.getUsers(this.activatedRoute.snapshot.data['appName']).then(users =>
            this.users = users
        );
    }

    onUserSelected(selectedUser): void {

        this.getAllRolesForUser(selectedUser.UserName);
    }

    getAllRolesForUser(selectedUser: any): void {

        this.adminService.getRolesForUser(this.activatedRoute.snapshot.data['appName'], selectedUser).then(roles => {
            this.usersRoles = roles
            //put the user's original roles into an array so we can do a comparison after role edits have been made
            Object.assign(this.originalUserRoles,this.usersRoles)
            //this.originalUserRoles = this.usersRoles;
            
            //this.getAllRolesForApplication(this.usersRoles)
            this.adminService.getAllRoles(this.activatedRoute.snapshot.data['appName']).then(roles => {
                this.allRoles = roles.filter(role => {
                    return this.usersRoles.findIndex(x => x.RoleName === role.RoleName) === -1;
                })
                
            });
        });
    }
    
    searchForUser(windowsLogin): void {
        this.adminService.findUserInActiveDirectory(windowsLogin).then(user => {
            this.foundUserInAD = user;
            //this.getAllRolesForUser(this.foundUser.domainAccountName);
            this.checkIfUserExists(this.foundUserInAD.domainAccountName);
        })
    }

    checkIfUserExists(selectedUser: any): void {

        this.adminService.getRolesForUser(this.activatedRoute.snapshot.data['appName'], selectedUser).then(roles => {
            this.newUsersRoles = roles
            this.userAlreadyExistsInAdminDB = this.newUsersRoles.length > 0;
            //this.getAllRolesForApplication(this.newUsersRoles)
            this.adminService.getAllRoles(this.activatedRoute.snapshot.data['appName']).then(roles => {
                this.newUserAllRoles = roles.filter(role => {
                    return this.newUsersRoles.findIndex(x => x.RoleName === role.RoleName) === -1;
                })
            });
        });
    }
  

    selectionMoveCheck(element) {
        if (element.selected) {
            element.selected = false;
            return true;
        }
    }

    setSelected(roles, role) {
        let ind = roles.findIndex(x => x.RoleName === role);
        if (ind > -1) {
            roles[ind].selected = true;
        }
    }

    moveElements(source, target, moveCheck) {
        for (var i = 0; i < source.length; i++) {
            var element = source[i];
            if (moveCheck(element)) {
                this.editsMade = true;
                source.splice(i, 1);
                target.push(element);
                i--;
            }
        }
    }

    shiftRoles(source: any, target: any, roles: any) {

        if (roles && roles.length > 0){
            for (let role of roles) {
                this.setSelected(source, role)
                this.moveElements(source, target, this.selectionMoveCheck);
            }

            this.selectedNewUserRoles = [];
            this.selectedNewAllRoles = [];
            this.selectedUsersRoles = [];
            this.selectedAllRoles = [];
        }
        
    }
    cancelNewUserCreation() {
        this.createUserMode = false;
    }

    createNewUserMode() {
        this.clearRolesListBoxes();
        this.windowsLogin = "";
        this.foundUserInAD = {};
        this.newUsersRoles=[];
        this.createUserMode = true;
    }

    notReadyToCreate() {
        return this.newUsersRoles.length <= 0 
    }

    onSubmit(_f: NgForm){
        
    }

    
       
}