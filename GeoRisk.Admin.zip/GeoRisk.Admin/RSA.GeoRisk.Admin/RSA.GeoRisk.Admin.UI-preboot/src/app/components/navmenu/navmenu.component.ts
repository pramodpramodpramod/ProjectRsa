import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { GeoriskAppsService } from '../../services/georiskapps.service';
import { App } from '../../objects/georiskapps/app';

@Component({
    selector: 'nav-menu',
    templateUrl: './navmenu.component.html',
    styleUrls: ['./navmenu.component.css'],
    //The providers array tells Angular to create a fresh instance of the GeoriskAppsService when it creates an AppComponent. The AppComponent, as well as its child components, can use that service to get app data.
    //providers: [GeoriskAppsService]
})
    
export class NavMenuComponent implements OnInit{
    apps: App[];
    //simultaneously defines a private georiskAppsService property and identifies it as a GeoriskAppsService injection site
    constructor(private georiskAppsService: GeoriskAppsService) { }

    //Angular offers interfaces for tapping into critical moments in the component lifecycle: 
    //at creation, after each change, and at its eventual destruction
    ngOnInit(): void {
        if (!this.apps) {
            this.getApps();
            
        }
    }

    getApps(): void {
        //Pass the callback function as an argument to the Promise's then() method:
        //ES2015 arrow function in the callback is more succinct than the equivalent function expression and gracefully handles this
        this.georiskAppsService.getApps().then(apps =>
            this.apps = apps
        );
    }

}
