import { OnInit } from '@angular/core';
import { GeoriskAppsService } from '../../services/georiskapps.service';
import { App } from '../../objects/georiskapps/app';
export declare class NavMenuComponent implements OnInit {
    private georiskAppsService;
    apps: App[];
    constructor(georiskAppsService: GeoriskAppsService);
    ngOnInit(): void;
    getApps(): void;
}
