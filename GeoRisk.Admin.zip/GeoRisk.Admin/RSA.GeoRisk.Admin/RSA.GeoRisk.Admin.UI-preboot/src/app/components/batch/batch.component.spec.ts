import { TestBed, inject } from '@angular/core/testing';

import { BatchComponent } from './batch.component';

describe('a batch component', () => {
	let component: BatchComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [
				BatchComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([BatchComponent], (BatchComponent) => {
		component = BatchComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});