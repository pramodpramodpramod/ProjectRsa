import { Component, OnInit } from '@angular/core';
import { ReportingService, AlertService } from "../../services/service-barrel";
import { IBatch } from "../../objects/reporting/batch";

@Component({
	selector: 'batch',
	templateUrl: 'batch.component.html'
})

export class BatchComponent implements OnInit {
	
	businessAreas:any[]
	batches:any[]
	reports:any[]
	addNewBatchMode:boolean = false
	newBatch:IBatch
	selectedBusinessArea:any

	constructor(private reportingService:ReportingService, private alertService: AlertService){}

	ngOnInit() { 
		//business areas will  include their batches
		this.reportingService.getBusinessAreas().subscribe(resp=>{
			this.businessAreas=resp
		})

		// this.reportingService.getReports().subscribe(resp=>{
		// 	this.reports = resp;
		// })

		// this.reportingService.getBatches().subscribe(resp=>{
		// 	this.batches=resp;
		// })
	}

	addBatch(){
		this.addNewBatchMode = !this.addNewBatchMode;
		//create a new batch object and initialise it with the id of the parent business area
		this.newBatch = new IBatch({businessAreaId:this.selectedBusinessArea.id})
	}

	onSubmit(){
		this.reportingService.addNewBatch(this.newBatch).subscribe((r)=>{
			if (r.ClassName == "System.Exception") {
				this.alertService.error(this.buildErrorMessage(r) + " " + r.Message, false);
			}
			else{        
				this.alertService.success("Added new batch " + r.batchId + " to business area " + this.selectedBusinessArea.displayName, false)
			}
		})
		this.addNewBatchMode = !this.addNewBatchMode;
	}
	cancel(){
		this.addNewBatchMode = !this.addNewBatchMode;
	}

	buildErrorMessage(r:any){
        let errorMessage:string = '';
        if(r.InnerException.Message){
            errorMessage += r.InnerException.Message
            if(r.InnerException.InnerException.Message){
                if(r.InnerException.InnerException.Message != r.InnerException.Message){
                    errorMessage += ' ' + r.InnerException.InnerException.Message
                }
                if(r.InnerException.InnerException.InnerException){
                    errorMessage += ' ' + r.InnerException.InnerException.InnerException.Message
                }
            }
        }
        return errorMessage;
    }
}