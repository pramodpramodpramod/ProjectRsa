export declare class LocalComponent {
}
