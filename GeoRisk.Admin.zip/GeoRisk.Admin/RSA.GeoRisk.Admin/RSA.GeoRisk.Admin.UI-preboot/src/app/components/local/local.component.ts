import { Component } from '@angular/core';

@Component({
    selector: 'local',
    templateUrl: './local.component.html',
    styles: [`
        .router-link-active {font-weight: bold;}
    `]
})
export class LocalComponent {
}
