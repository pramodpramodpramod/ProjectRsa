import {Component} from '@angular/core'

@Component({

    templateUrl:'./reporting-main.component.html'
})

export class ReportingMainComponent{

}