import { Component, OnInit } from '@angular/core';


import { AlertService } from "../../services/service-barrel";
import { Alert, AlertType } from "../../objects/alert";


@Component({
    selector: 'alert',
    templateUrl: './alert.component.html',
    styles:[`
        .alert {position: absolute; right:135px; top:15px; width: 300px; z-Index:999}
    `]
})

export class AlertComponent implements OnInit {
    showAlert: boolean = true;
    alerts: Alert[] = [];


    constructor(private alertService: AlertService) { }

    ngOnInit() {
        this.alertService.getAlert().subscribe((alert: Alert) => {
            if (!alert) {
                // clear alerts when an empty alert is received
                this.alerts = [];
                return;
            }

            // add alert to array
            this.alerts.push(alert);
        });
    }

    removeAlert(alert: Alert) {
        this.alerts = this.alerts.filter(x => x !== alert);
    }

    shoAlert(){
        this.showAlert=true;
        setTimeout(function () {
            this.showAlert=false;
        }, 3000);
    }

    cssClass(alert: Alert) {
        if (!alert) {
            return;
        }
        
        // return css class based on alert type
        switch (alert.type) {
            case AlertType.Success:
                return 'alert alert-success';
            case AlertType.Error:
                return 'alert alert-danger';
            case AlertType.Info:
                return 'alert alert-info';
            case AlertType.Warning:
                return 'alert alert-warning';
        }
    }
}