﻿import { Component, OnInit} from "@angular/core";
import { Service } from "../../objects/georiskapps/service";
//import { GeoriskAppsService } from "../../services/georiskapps.service";
import { ActivatedRoute } from "@angular/router";
import { GeoriskAppsService, AlertService } from "../../services/service-barrel";

@Component({
    selector: 'service-details',
    templateUrl: './app-service-detail.component.html',
    //providers: [GeoriskAppsService]
})

export class AppServiceDetailComponent implements OnInit {

    selectedService: Service
    businessTypes: any;
    baseMapStyles: any;
    leafletTypes: any;
    mapServiceTypes: any;
    serviceTypes: any;
    services: Service[];
    serviceEditMode:boolean=false;

    constructor(private route: ActivatedRoute, private georiskAppsService:GeoriskAppsService,private alertService: AlertService) { }
    
    ngOnInit() {
        this.getAppServices(this.route.snapshot.data['appName']);

        this.route.data.subscribe((data) => {
            this.businessTypes = data.domainDetails.businessTypes;
            this.baseMapStyles = data.domainDetails.baseMapStyles;
            this.leafletTypes = data.domainDetails.leafletTypes;
            this.mapServiceTypes = data.domainDetails.mapServiceTypes;
            this.serviceTypes = data.domainDetails.serviceTypes;
      })
    }

    serviceSelected(selectedService: Service) {
        this.selectedService = selectedService;
    }

    serviceEditClicked(){
        this.serviceEditMode = !this.serviceEditMode;
    }

    serviceEditSaveClicked(){
        
        let nS = new Service(   
            {arcGisServiceLayerName:this.selectedService.arcGisServiceLayerName,
            attribution:this.selectedService.attribution,
            baseMapStyle_BaseMapStyleId:this.selectedService.baseMapStyle_BaseMapStyleId,
            businessType_BusinessTypeId:this.selectedService.businessType_BusinessTypeId,
            identify:this.selectedService.identify,
            isActive:this.selectedService.isActive,
            isDefault:this.selectedService.isDefault,
            layers:this.selectedService.layers,
            leafletType_LeafletTypeId:this.selectedService.leafletType_LeafletTypeId,
            legendImage:this.selectedService.legendImage,
            legendImageUrl:this.selectedService.legendImageUrl,
            mandated:this.selectedService.mandated,
            map_MapId:this.selectedService.map_MapId,
            mapServiceType_MapServiceTypeId:this.selectedService.mapServiceType_MapServiceTypeId,
            name:this.selectedService.name,
            opacity:this.selectedService.opacity,
            regions:this.selectedService.regions,
            serviceId:this.selectedService.serviceId,
            serviceType_ServiceTypeId: this.selectedService.serviceType_ServiceTypeId,
            token:this.selectedService.token,
            url:this.selectedService.url,
            visible:this.selectedService.visible})

        this.georiskAppsService.saveServiceEdits(nS).subscribe(()=>{
            this.alertService.success('successfully saved edits to service');//resp
            this.serviceEditMode = !this.serviceEditMode;
        })
        //code to put (edit)
    }
    
    getAppServices(appName): void {
        //Pass the callback function as an argument to the Promise's then() method:
        //ES2015 arrow function in the callback is more succinct than the equivalent function expression and gracefully handles this
        this.georiskAppsService.getAppServices(appName).then(services =>
            this.services = services
        );
    }

    fileChange(event){
        let fileList: FileList = event.target.files;
        if(fileList.length > 0){
            let file: File = fileList[0];
            var myReader:FileReader = new FileReader();
            myReader.onloadend = () => {
                this.selectedService.legendImage = myReader.result.split(',')[1];;
            }
            myReader.readAsDataURL(file);
            
         }
    }
}