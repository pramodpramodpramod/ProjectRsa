﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GeoriskAppsService } from '../../services/georiskapps.service';
import { Service } from '../../objects/georiskapps/service';


@Component({
    selector: 'app-services',
    templateUrl: './app-services.component.html',
    //providers: [GeoriskAppsService]
})

export class AppServicesComponent implements OnInit{

    services: Service[];
    selectedService: Service;
    appName: any;

    constructor(private georiskAppsService: GeoriskAppsService, private route: ActivatedRoute) { }

    ngOnInit(): void {
        this.getAppServices(this.route.snapshot.data['appName']);
    }

    getAppServices(appName): void {
        //Pass the callback function as an argument to the Promise's then() method:
        //ES2015 arrow function in the callback is more succinct than the equivalent function expression and gracefully handles this
        this.georiskAppsService.getAppServices(appName).then(services =>
            this.services = services
        );
    }

    serviceSelected(selectedService: Service) {
        this.selectedService = selectedService;
    }
}