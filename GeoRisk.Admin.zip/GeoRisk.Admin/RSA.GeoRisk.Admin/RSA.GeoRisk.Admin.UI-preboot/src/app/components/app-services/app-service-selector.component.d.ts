import { EventEmitter } from '@angular/core';
import { Service } from "../../objects/georiskapps/service";
export declare class AppServiceSelectorComponent {
    serviceSelected: EventEmitter<Service>;
    services: Service[];
    onServiceSelected(service: Service): void;
}
