import { OnInit } from "@angular/core";
import { Service } from "../../objects/georiskapps/service";
import { GeoriskAppsService } from "../../services/georiskapps.service";
export declare class AppServiceDetailComponent implements OnInit {
    private georiskAppsService;
    selectedService: Service;
    businessTypes: any;
    baseMapStyles: any;
    leafletTypes: any;
    mapServiceTypes: any;
    serviceTypes: any;
    constructor(georiskAppsService: GeoriskAppsService);
    ngOnInit(): void;
    getBusinessTypes(): void;
    getBaseMapStyles(): void;
    getLeafletTypes(): void;
    getMapServiceTypes(): void;
    getServiceTypes(): void;
}
