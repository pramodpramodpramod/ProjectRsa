import { OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GeoriskAppsService } from '../../services/georiskapps.service';
import { Service } from '../../objects/georiskapps/service';
export declare class AppServicesComponent implements OnInit {
    private georiskAppsService;
    private route;
    services: Service[];
    selectedService: Service;
    appName: any;
    constructor(georiskAppsService: GeoriskAppsService, route: ActivatedRoute);
    ngOnInit(): void;
    getAppServices(appName: any): void;
    serviceSelected(selectedService: Service): void;
}
