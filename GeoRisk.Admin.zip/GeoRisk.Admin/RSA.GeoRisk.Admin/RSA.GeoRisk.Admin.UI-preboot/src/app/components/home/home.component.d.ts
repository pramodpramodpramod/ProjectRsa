export declare class HomeComponent {
}
