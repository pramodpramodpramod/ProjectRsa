import { Component, OnInit } from '@angular/core';

import { ReportingService, AlertService } from "../../services/service-barrel";
import { HighRiskCountry } from "../../objects/reporting/highRiskCountry";

@Component({
	selector: 'sanctions',
	templateUrl: 'sanctions.component.html'
})

export class SanctionsComponent implements OnInit {
	selectedCountry: HighRiskCountry
	editedHighRiskCountry: HighRiskCountry
	highRiskCountries: HighRiskCountry[] = []
	editMode:boolean=false;

	constructor(private reportingService: ReportingService, private alertService:AlertService) { }

	ngOnInit() {
		this.reportingService.getHighRiskCountries().subscribe((res) => {
			this.highRiskCountries = res;
		});
	}

	edit(){
		this.editMode = !this.editMode;
	}

	onSubmit(){
		
		//these are the properties of sanction countries that are editable
		let newbody=[
			{ "op": "replace", "path": "/ReasonForInclusion", "value": this.selectedCountry.ReasonForInclusion },
			{ "op": "replace", "path": "/RSAApproach", "value": this.selectedCountry.RSAApproach },
			{ "op": "replace", "path": "/Classification", "value": this.selectedCountry.Classification },
			{ "op": "replace", "path": "/DateModified", "value": this.selectedCountry.DateModified },
			{ "op": "replace", "path": "/ModifiedBy", "value": this.selectedCountry.ModifiedBy }
		]
		this.reportingService.saveChangesToSanctionCountries(newbody, this.selectedCountry.OBJECTID.toString()).subscribe((res)=>{
			if(res.ClassName == "System.Exception"){
				this.alertService.error("Failed to save changes to sanction country.", false)
			}
			else(
				this.alertService.success("Saved changes to sanction country " + this.selectedCountry.CountryLongName, false)
			)
			this.editMode = !this.editMode;
		})
	}

	cancel(){
		this.editMode = !this.editMode;
	}
}