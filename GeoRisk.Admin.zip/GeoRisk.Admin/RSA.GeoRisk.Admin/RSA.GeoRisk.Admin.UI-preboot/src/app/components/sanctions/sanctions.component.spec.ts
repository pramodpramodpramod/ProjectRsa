import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

import { SanctionsComponent } from './sanctions.component';
//import { HighRiskCountry } from '../../objects/reporting/highRiskCountry';
import { ReportingService } from "../../services/service-barrel";

describe('a sanctions component', () => {
	let component: SanctionsComponent;

	// register all needed dependencies
	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [HttpModule],
			providers: [
				{ provide: ReportingService, useClass: MockSanctionsService },
				SanctionsComponent
			]
		});
	});

	// instantiation through framework injection
	beforeEach(inject([SanctionsComponent], (SanctionsComponent) => {
		component = SanctionsComponent;
	}));

	it('should have an instance', () => {
		expect(component).toBeDefined();
	});
});

// Mock of the original sanctions/high-risk-countries service
class MockSanctionsService extends ReportingService {
	//getHighRiskCountries(): Observable<HighRiskCountry> {
	getHighRiskCountries(): Observable<any> {
		return Observable.from([ { } ]);
	}
}
