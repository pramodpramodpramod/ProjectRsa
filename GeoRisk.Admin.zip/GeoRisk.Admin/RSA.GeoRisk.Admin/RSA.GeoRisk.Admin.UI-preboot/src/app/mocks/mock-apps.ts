﻿
import { App } from '../objects/georiskapps/app';

export const APPS: App[] = [
    {
        appId: 1,
        name: 'portfolio',
        currencies: 'GBP, EUR, USD, CAD',
        map:[]
    },
    {
        appId: 2,
        name: 'local',
        currencies: 'GBP, EUR, USD, CAD',
        map:[]
    }
]