﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeoRisk.Reporting.Database.Model
{
    //note! these properties of label,y,children are very important to maintian
    //so that the data structure properly in the abn_tree
    public class HighRiskDetails
    {
        public string label { get; set; }
        public int y { get; set; }
        public List<CountryDetails> children { get; set; }

    }

    public class CountryDetails
    {
        public string label { get; set; }
        public string category { get; set; }
        public int y { get; set; }
    }
}
