﻿CREATE USER [OPD\IBM AMS Server Local admin rights] FOR LOGIN [OPD\IBM AMS Server Local admin rights];

