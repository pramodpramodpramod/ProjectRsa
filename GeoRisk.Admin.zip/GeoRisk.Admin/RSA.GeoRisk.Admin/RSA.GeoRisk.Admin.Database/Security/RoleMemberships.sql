﻿EXECUTE sp_addrolemember @rolename = N'db_owner', @membername = N'OPD\F30486';


GO
EXECUTE sp_addrolemember @rolename = N'db_ddladmin', @membername = N'OPD\f29545';


GO
EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'OPD\DEV_GALAXY_ARCGIS';


GO
EXECUTE sp_addrolemember @rolename = N'db_datareader', @membername = N'OPD\f29545';


GO
EXECUTE sp_addrolemember @rolename = N'db_datawriter', @membername = N'OPD\f29545';

