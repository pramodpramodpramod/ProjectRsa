﻿CREATE USER [sqlhpusr] FOR LOGIN [sqlhpusr];

