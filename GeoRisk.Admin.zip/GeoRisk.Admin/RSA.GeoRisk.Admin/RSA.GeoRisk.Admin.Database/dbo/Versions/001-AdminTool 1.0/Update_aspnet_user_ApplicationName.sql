﻿USE admin
GO

-- they need to be run separately
update aspnet_Users 
Set aspnet_Users.ApplicationName = t.ApplicationName
From aspnet_Applications as t
where
aspnet_Users.ApplicationId = t.ApplicationId


-- they need to be run separately

update GroupLicenceUser 
Set GroupLicenceUser.GroupLicenceName = t.Name
From dbo.GroupLicence as t
where
GroupLicenceUser.GroupLicenceId = t.Id