﻿USE [admin]
GO

ALTER TABLE [dbo].[aspnet_Users] ADD FirstName nvarchar(250)
ALTER TABLE [dbo].[aspnet_Users] ADD LastName nvarchar(250)
ALTER TABLE [dbo].[aspnet_Users] ADD Email nvarchar(250)
 