﻿USE [admin]
GO

ALTER TABLE [dbo].[aspnet_Users] ADD ApplicationName nvarchar(50)