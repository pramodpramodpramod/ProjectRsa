USE [geoRiskApps]
GO

ALTER TABLE [dbo].[Service] ADD LicenceType int not null DEFAULT 1