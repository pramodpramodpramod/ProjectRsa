USE [geoRiskApps]
GO

/****** Object:  Table [dbo].[daily_exposure_faulty_data]    Script Date: 11/29/2019 09:24:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[daily_exposure_faulty_data](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[BatchId] [nchar](10) NULL,
	[ProblemCategory] [nvarchar](50) NULL,
	[ProblemInput] [nvarchar](max) NULL,
	[Username] [nvarchar](50) NOT NULL,
	[ReportedBy] [nvarchar](50) NOT NULL,
	[Longitude] [numeric](38, 8) NULL,
	[Latitude] [numeric](38, 8) NULL,
	[ProducingOperation] [nvarchar](50) NULL,
	[LineOfBusiness] [nvarchar](50) NULL,
	[PolicySystem] [nvarchar](50) NULL,
	[PolicyNumber] [nvarchar](50) NULL,
	[NameOfInsured] [nvarchar](50) NULL,
	[LocationDeletionDate] [nvarchar](50) NULL,
	[NetTotalSumInsured] [decimal](18, 0) NULL,
	[GrossTotalSumInsured] [decimal](18, 0) NULL,
	[NetEstimatedMaximumLoss] [decimal](18, 0) NULL,
	[GrossEstimatedMaximumLoss] [decimal](18, 0) NULL,
	[SuppliedAddress] [nvarchar](max) NULL,
	[SystemAddress] [nvarchar](max) NULL,
	[GeocodeAccuracy] [nvarchar](100) NULL,
	[CurrencyCode] [nvarchar](10) NULL,
	[CurrencyValue] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NOT NULL,
	[ResolvedDate] [datetime] NULL,
	[ResolvedBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_daily_exposure_faulty_data] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


