USE [geoRiskApps]
GO

/****** Object:  Table [dbo].[GroupLicenceService]    Script Date: 11/11/2019 10:15:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[GroupLicenceService](
	[GroupLicenceId] [int] NOT NULL,
	[ServiceId] [int] NOT NULL,
 CONSTRAINT [PK_GroupLicenceService] PRIMARY KEY CLUSTERED 
(
	[GroupLicenceId] ASC,
	[ServiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[GroupLicenceService]  WITH CHECK ADD  CONSTRAINT [FK_GroupLicenceService_Service] FOREIGN KEY([ServiceId])
REFERENCES [dbo].[Service] ([ServiceId])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[GroupLicenceService] CHECK CONSTRAINT [FK_GroupLicenceService_Service]
GO


