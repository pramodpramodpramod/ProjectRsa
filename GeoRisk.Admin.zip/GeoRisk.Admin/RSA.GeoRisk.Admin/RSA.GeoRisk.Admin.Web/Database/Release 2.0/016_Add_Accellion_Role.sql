USE [admin]
GO

DECLARE @AdminAppId uniqueidentifier;
SELECT @AdminAppId = ApplicationId FROM dbo.aspnet_Applications WHERE ApplicationName = 'Admin'
BEGIN
	BEGIN TRANSACTION
		Insert into dbo.aspnet_Roles (ApplicationId,RoleId,RoleName,LoweredRoleName,Description)
		values(@AdminAppId, NEWID(), 'External Accellion', 'external accellion', NULL)
	COMMIT TRANSACTION
END
GO