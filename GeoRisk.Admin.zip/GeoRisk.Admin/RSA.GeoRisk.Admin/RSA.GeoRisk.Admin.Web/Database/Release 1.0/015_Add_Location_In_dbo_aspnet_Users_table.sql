USE [admin]
GO

ALTER TABLE [dbo].[aspnet_Users] ADD Location nvarchar(200)
GO