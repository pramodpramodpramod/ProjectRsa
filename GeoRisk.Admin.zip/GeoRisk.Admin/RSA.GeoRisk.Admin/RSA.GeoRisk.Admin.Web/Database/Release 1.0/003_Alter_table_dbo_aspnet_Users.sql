USE [admin]
GO

ALTER TABLE [dbo].[aspnet_Users]
ADD RegistrationDate DATETIME 
GO