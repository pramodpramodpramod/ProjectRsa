USE [admin]
GO

DELETE ur
FROM [dbo].[aspnet_UsersInRoles] ur
INNER JOIN [dbo].[aspnet_Roles] r ON r.RoleId = ur.RoleId
WHERE RoleName IN ('adminEdit', 'adminView')
GO

DELETE FROM [dbo].[aspnet_Roles]
WHERE RoleName IN ('adminEdit', 'adminView') AND ApplicationId ='C0C4A30E-EC3B-4E5C-A81C-D968A1D57FA3'
GO