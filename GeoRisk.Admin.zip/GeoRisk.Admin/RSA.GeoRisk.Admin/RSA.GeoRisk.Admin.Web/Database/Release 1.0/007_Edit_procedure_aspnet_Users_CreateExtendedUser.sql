USE [admin]
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[aspnet_Users_CreateExtendedUser]'))
DROP PROCEDURE [dbo].[aspnet_Users_CreateExtendedUser]
GO

CREATE PROCEDURE [dbo].[aspnet_Users_CreateExtendedUser]
    @ApplicationId    uniqueidentifier,
    @UserName         nvarchar(256),
    @IsUserAnonymous  bit,
    @LastActivityDate DATETIME,
	@FirstName         nvarchar(250),
	@LastName         nvarchar(250),
	@Email         nvarchar(250),
	@RegistrationDate DATETIME,
    @UserId           uniqueidentifier OUTPUT
AS
BEGIN
    IF( @UserId IS NULL )
        SELECT @UserId = NEWID()
    ELSE
    BEGIN
        IF( EXISTS( SELECT UserId FROM dbo.aspnet_Users
                    WHERE @UserId = UserId ) )
            RETURN -1
    END

    INSERT dbo.aspnet_Users (ApplicationId, UserId, UserName, LoweredUserName, IsAnonymous, LastActivityDate, FirstName, LastName, Email, RegistrationDate)
    VALUES (@ApplicationId, @UserId, @UserName, LOWER(@UserName), @IsUserAnonymous, @LastActivityDate, @FirstName, @LastName, @Email, @RegistrationDate)

    RETURN 0
END


GO


