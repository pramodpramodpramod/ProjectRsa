USE [admin]
GO

DECLARE @AdminAppId UNIQUEIDENTIFIER = NEWID()
DECLARE @Now DATETIME =  GETDATE()
IF NOT EXISTS (SELECT ApplicationId FROM dbo.aspnet_Applications WHERE ApplicationName = 'Admin')
BEGIN
	BEGIN TRANSACTION
		INSERT INTO dbo.aspnet_Applications VALUES ('Admin', 'admin', @AdminAppId, NULL)

		EXEC dbo.aspnet_Roles_CreateRole 'Admin', 'Administrator'
		EXEC dbo.aspnet_Roles_CreateRole 'Admin', 'Manager Local'
		EXEC dbo.aspnet_Roles_CreateRole 'Admin', 'Manager Portfolio'
		EXEC dbo.aspnet_Roles_CreateRole 'Admin', 'External Local'
		EXEC dbo.aspnet_Roles_CreateRole 'Admin', 'External Portfolio'
	COMMIT TRANSACTION
END
GO