USE [admin]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AccellionUsers]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[AccellionUsers] (
		UserId				NVARCHAR(100) NOT NULL,
		FirstName			NVARCHAR(100),
		LastName			NVARCHAR(100),
		Email				NVARCHAR(150),
		ApproverEmail		NVARCHAR(150) NOT NULL,
		UserProfile			NVARCHAR(200),
		UserType			NVARCHAR(100),
		RegistrationDate	DATETIME,
		CONSTRAINT [PK_UserId] PRIMARY KEY (UserId)
	)
END
GO