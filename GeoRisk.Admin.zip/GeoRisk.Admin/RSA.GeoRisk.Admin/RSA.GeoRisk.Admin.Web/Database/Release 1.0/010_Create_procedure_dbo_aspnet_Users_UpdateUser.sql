USE [admin]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[aspnet_Users_UpdateUser]'))
DROP PROCEDURE [dbo].[aspnet_Users_UpdateUser]
GO

CREATE PROCEDURE [dbo].[aspnet_Users_UpdateUser]
    @ApplicationId    uniqueidentifier,
    @UserName         nvarchar(250),
    @IsUserAnonymous  bit,
    @ApproverEmail	  nvarchar(250)
AS
BEGIN
   IF(NOT EXISTS(SELECT UserId FROM dbo.aspnet_Users WHERE UserName = @UserName AND ApplicationId = @ApplicationId))
   BEGIN
		RETURN -1
	END
   ELSE
   BEGIN
		UPDATE dbo.aspnet_Users
		SET ApproverEmail = @ApproverEmail
		WHERE UserName = @UserName AND ApplicationId = @ApplicationId

		RETURN 0
	END
END


GO


