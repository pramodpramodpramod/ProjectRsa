USE [admin]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AuditUsers]') AND type in (N'U'))
BEGIN
	CREATE TABLE [dbo].[AuditUsers] (
		Id					INT IDENTITY (1, 1) NOT NULL,
		UserName			NVARCHAR(256) NOT NULL,
		FirstName			NVARCHAR(100),
		LastName			NVARCHAR(100),
		Email				NVARCHAR(150),
		Location			NVARCHAR(200),
		DeletedDate			DATETIME,
		Application			NVARCHAR(256) NOT NULL,
		CONSTRAINT [PK_AuditUser_Id] PRIMARY KEY (Id)
	)
END
GO