USE [admin]
GO

ALTER TABLE [dbo].[aspnet_Users]
ADD IsActive BIT NOT NULL DEFAULT 1
GO