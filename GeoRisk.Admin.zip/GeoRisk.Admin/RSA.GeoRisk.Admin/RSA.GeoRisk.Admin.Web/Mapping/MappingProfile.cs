﻿using System;
using System.Linq;
using System.Web.Mvc;
using AutoMapper;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Mapping.Enums;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<aspnet_Users, UserDTO>()
                .ForMember(dest => dest.LastActivityDate, opts => opts.MapFrom(src => src.LastActivityDate.HasValue ? src.LastActivityDate.Value.ToLocalTime() : (DateTime?)null));
            CreateMap<UserDTO, aspnet_Users>()
                .ForMember(dest => dest.LoweredUserName, opts => opts.MapFrom(src => src.UserName.ToLower()));

            CreateMap<aspnet_Roles, UserRoleDTO>();
            CreateMap<App, ApplicationDTO>();
            CreateMap<AccellionUser, AccellionUserDTO>();
            CreateMap<AccellionUserDTO, AccellionUser>();
            CreateMap<ExternalApplicationUser, ExternalApplicationUserDTO>().ReverseMap();
            CreateMap<Service, ServiceDropdownDTO>()
                .ForMember(dest => dest.ServiceId, opt => opt.MapFrom(src => src.ServiceId))
                .ForMember(dest => dest.Application, opt => opt.MapFrom(src => src.Map.Name.Replace("Map", "")))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name)).ReverseMap();

            CreateMap<EmailSetting, EmailSettingsDTO>().ReverseMap();
            CreateMap<daily_exposure_faulty_data, DailyExposureFaultyDataDTO>().ReverseMap();
            CreateMap<GroupLicence, GroupLicenceDTO>()
                .ForMember(dest => dest.UserGuids, opts => opts.MapFrom(src => src.GroupLicenceUsers.Select(x => x.UserId)))
                .ForMember(dest => dest.UsersCount, opts => opts.MapFrom(src => src.GroupLicenceUsers.Count))
                .ReverseMap();
            CreateMap<LicenceTypeEnum, EnumDTO>()
              .ForMember(d => d.Name, op => op.MapFrom(src => src.ToString()))
              .ForMember(d => d.Value, op => op.MapFrom(src => src.ToString()));

            CreateMap<Service, ServiceResponse>()
               .ForMember(dest => dest.usersCount, opts => opts.MapFrom(src => src.IndividualUserServices.Count))
               .ForMember(dest => dest.application, opts => opts.MapFrom(src => src.Map.Name))
               .ReverseMap();

            CreateMap<Service, ServiceDetail>()
                .ForMember(dest => dest.ServiceType, opts => opts.MapFrom(src => src.ServiceType.Name))
                .ForMember(dest => dest.ServiceType, opts => opts.MapFrom(src => src.ServiceType.Name))
                .ForMember(dest => dest.BusinessType, opts => opts.MapFrom(src => src.BusinessType.Name))

                .ForMember(dest => dest.LegendImage, opts => opts.MapFrom(src => src.LegendImage != null ? Convert.ToBase64String(src.LegendImage) : string.Empty)).ReverseMap();
        }
    }
}