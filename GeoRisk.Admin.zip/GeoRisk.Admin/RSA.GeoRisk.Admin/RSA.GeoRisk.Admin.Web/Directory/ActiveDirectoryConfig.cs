﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace RSA.GeoRisk.Admin.Web.Directory
{
    public static class ActiveDirectoryConfig
    {
        private static LDAPObj LdapObj { get; set; }

        public static LDAPSettings LoadLDAPConfig(SearchType searchType, string domain)
        {
            string activeDirectoryConfig = AppDomain.CurrentDomain.GetData("DataDirectory").ToString() + "\\" + "activeDirectoryConfig.json";

            using (StreamReader r = new StreamReader(activeDirectoryConfig))
            {
                string json = r.ReadToEnd();
                LdapObj = JsonConvert.DeserializeObject<LDAPObj>(json);
            }

            if (searchType == SearchType.Email)
            {
                return LdapObj.Email.FirstOrDefault(x => x.domain == domain);
            }
            else if (searchType == SearchType.UserId)
            {
                return LdapObj.UserId.FirstOrDefault(x => x.domain == domain.ToUpper());
            }
            else
            {
                return LdapObj.Default;
            }
        }
    }

    public class LDAPObj
    {
        public LDAPSettings[] Email { get; set; }
        public LDAPSettings[] UserId { get; set; }
        public LDAPSettings Default { get; set; }
    }

    public class LDAPSettings
    {
        public string domain { get; set; }
        public string server { get; set; }
        public List<string> OU { get; set; }
    }

    public enum SearchType
    {
        Email,
        UserId
    }
}