﻿using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;

namespace RSA.GeoRisk.Admin.Web.Directory
{
    public class DomainMap
    {
        public static string GetLdapConnection(LDAPSettings ldapSettings)
        {
            string ous = "";
            foreach (var ou in ldapSettings.OU)
            {
                if (ou != string.Empty || ou != "")
                {
                    ous += string.Format("OU={0}", ou);
                    if (ldapSettings.OU.IndexOf(ou) != ldapSettings.OU.Count - 1)
                    {
                        ous += ",";
                    }
                }
            }

            var dcParts = ldapSettings.server.Split('.').ToList();
            dcParts.RemoveAt(0);

            string dcs = "";
            foreach (var domainController in dcParts)
            {
                dcs += string.Format("DC={0}", domainController.ToUpper());
                if (domainController != string.Empty || domainController != "")
                {
                    if (dcParts.IndexOf(domainController) != dcParts.Count - 1)
                    {
                        dcs += ",";
                    }
                }

            }

            return ous != "" || ous != string.Empty ? string.Format("LDAP://{0}/{1},{2}", ldapSettings.server, ous, dcs) : string.Format("LDAP://{0}/{1}", ldapSettings.server, dcs);
        }
    }
}