﻿using RSA.GeoRisk.Admin.Web.Code.Entities;
using RSA.GeoRisk.Admin.Web.DTOs;

namespace RSA.GeoRisk.Admin.Web.Directory
{
    public interface IActiveDirectoryScanner
    {
        ResponseWrapper<ActiveDirectoryUser> GetActiveDirectoryUser(string userName);
        ResponseWrapper<bool> CheckIfEmailExsitAgainstAD(string email);
    }
}
