﻿using System;
using System.Configuration;
using System.DirectoryServices;
using System.Linq;
using RSA.GeoRisk.Admin.Web.Code.Entities;
using RSA.GeoRisk.Admin.Web.DTOs;

namespace RSA.GeoRisk.Admin.Web.Directory
{
    public class ActiveDirectoryScanner : IActiveDirectoryScanner
    {
        public ResponseWrapper<ActiveDirectoryUser> GetActiveDirectoryUser(string searchName)
        {
            var result = new ResponseWrapper<ActiveDirectoryUser>();
            var adUser = new ActiveDirectoryUser();
            if (searchName.Contains("@"))
            {
                try
                {
                    ResponseWrapper<SearchResult> wrs = GetActiveDirectoryUserByEmailAccount(searchName);
                    if (wrs.Data != null)
                    {
                        adUser.displayName = wrs.Data.Properties["displayname"][0].ToString();
                        adUser.email = wrs.Data.Properties["mail"][0].ToString();
                        adUser.firstName = wrs.Data.Properties["givenname"][0].ToString();
                        adUser.lastName = wrs.Data.Properties["sn"][0].ToString();
                        if (wrs.Data.Properties.Contains("uid"))
                            adUser.userName = wrs.Data.Properties["uid"][0].ToString();
                        else if (wrs.Data.Properties.Contains("distinguishedname") && wrs.Data.Properties.Contains("samaccountname"))
                        {
                            var domain = wrs.Data.Properties["distinguishedname"][0].ToString()
                                .Split(',')
                                .ToList().First(x => x.Contains("DC"));
                            var samaccount = wrs.Data.Properties["samaccountname"][0];
                            adUser.userName = domain.Split('=')[1] + "\\" + samaccount;
                        }

                        result.SetData(adUser);
                        return result;
                    }
                    result.SetData(null, wrs.Message);
                    return result;
                }
                catch (Exception ex)
                {
                    result.SetData(null, ex.Message);
                    return result;
                }
            }
            else
            {
                try
                {
                    var searchResultWrapper = GetActiveDirectoryUserByName(searchName);
                    if (searchResultWrapper.Data != null)
                    {
                        adUser.displayName = searchResultWrapper.Data.Properties["displayname"][0].ToString();
                        adUser.email = searchResultWrapper.Data.Properties.Contains("mail")
                            ? searchResultWrapper.Data.Properties["mail"][0].ToString()
                            : "no email address found";
                        adUser.firstName = searchResultWrapper.Data.Properties["givenname"][0].ToString();
                        adUser.lastName = searchResultWrapper.Data.Properties["sn"][0].ToString();
                        adUser.userName = searchResultWrapper.Data.Properties["uid"][0].ToString();
                        result.SetData(adUser);
                        return result;
                    }
                    result.SetData(null, "There is no user found with this user id.");
                    return result;
                }
                catch (Exception ex)
                {
                    result.SetData(null, ex.Message);
                    return result;
                }
            }
        }

        private ResponseWrapper<SearchResult> GetActiveDirectoryUserByEmailAccount(string email)
        {
            var result = new ResponseWrapper<SearchResult>();

            var domain = email.Split('@')[1].TrimEnd().ToString();

            LDAPSettings ldapSettings = ActiveDirectoryConfig.LoadLDAPConfig(SearchType.Email, domain);

            if (ldapSettings == null)
            {
                result.SetData(null);
                result.Message = "There is no implementation for this domain: @" + domain +
                                 " Please check the configuration.";
                return result;
            }

            return SearchDirectory(ldapSettings, email, SearchType.Email);
        }


        private static ResponseWrapper<SearchResult> GetActiveDirectoryUserByName(string searchName)
        {
            var result = new ResponseWrapper<SearchResult>();

            var domain = searchName.Split('\\')[0].TrimStart().ToString();

            LDAPSettings ldapSettings = ActiveDirectoryConfig.LoadLDAPConfig(SearchType.UserId, domain);

            if (ldapSettings == null)
            {
                result.SetData(null);
                result.Message = "There is no implementation for this domain: " + domain +
                                 " Please check the configuration.";
                return result;
            }
            else if (searchName.Split('\\').Length < 2)
            {
                result.SetData(null);
                result.Message = "There is something wrong with this username  :" + searchName;
                return result;
            }

            return SearchDirectory(ldapSettings, searchName, SearchType.UserId);
        }

        public ResponseWrapper<bool> CheckIfEmailExsitAgainstAD(string email)
        {
            var result = new ResponseWrapper<bool>();

            var domain = email.Split('@')[1].TrimEnd().ToString();

            LDAPSettings ldapSettings = ActiveDirectoryConfig.LoadLDAPConfig(SearchType.Email, domain);
            if (ldapSettings == null)
            {
                result.Message = $"There is no email registered with: {domain} domain";
                result.SetData(false);
                return result;
            }

            var activeDirectoryQuery = $"(&(objectCategory=user)(objectClass=user)(mail={email}))";

            using (DirectoryEntry entry = GetDirectoryObject(ldapSettings))
            {
                using (DirectorySearcher searcher = new DirectorySearcher(entry))
                {
                    searcher.Filter = activeDirectoryQuery;
                    SearchResult results = searcher.FindOne();
                    if (results != null)
                    {
                        result.SetData(true);
                    }
                    else
                    {
                        result.SetData(false);
                    }
                }
            }
            return result;
        }

        private static ResponseWrapper<SearchResult> SearchDirectory(LDAPSettings ldapSettings, string filter, SearchType searchType)
        {
            var result = new ResponseWrapper<SearchResult>();
            var activeDirectoryQuery = searchType == SearchType.Email ?
                $"(&(objectCategory=user)(objectClass=user)(mail={filter}))" :
                $"(&(objectCategory=user)(objectClass=user)(uid={filter.Replace("\\", "\\5C")}))";

            using (DirectoryEntry entry = GetDirectoryObject(ldapSettings))
            {
                using (DirectorySearcher searcher = new DirectorySearcher(entry))
                {
                    searcher.Filter = activeDirectoryQuery;

                    try
                    {
                        SearchResultCollection results = searcher.FindAll();
                        if (results.Count != 0)
                        {
                            result.SetData(results[0]);
                        }
                        else
                        {
                            var emailOrUser = searchType == SearchType.UserId ? "user Id" : "email";
                            result.SetData(null, $"There is no user found with this {emailOrUser}.");
                        }

                        return result;
                    }
                    catch (DirectoryServicesCOMException e)
                    {
                        if (e.ExtendedError == 8333)
                        {
                            result.SetData(null, $"There is problem with one of the Orgazniation Units: {string.Join(", ", ldapSettings.OU.ToArray())}.");
                            return result;
                        }
                        throw;
                    }
                    catch (Exception e)
                    {
                        throw;
                    }


                }
            }
        }

        private static DirectoryEntry GetDirectoryObject(LDAPSettings ldapSettings)
        {
            var path = DomainMap.GetLdapConnection(ldapSettings);

            return new DirectoryEntry
            {
                Path = path,
                AuthenticationType = AuthenticationTypes.Secure,
                Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
            };
        }
    }
}