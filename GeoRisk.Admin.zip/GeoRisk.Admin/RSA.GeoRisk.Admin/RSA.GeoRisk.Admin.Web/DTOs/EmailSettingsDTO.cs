﻿using System;
namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class EmailSettingsDTO
    {
        public string ApplicationName { get; set; }
        public string ApplicationUrl { get; set; }
        public string EmailSubject { get; set; }
        public string EmailContent { get; set; }
    }
}