﻿namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class AuthenticatedUserResponse
    {
        public string Username { get; set; }
        public string[] Roles { get; set; }
    }
}