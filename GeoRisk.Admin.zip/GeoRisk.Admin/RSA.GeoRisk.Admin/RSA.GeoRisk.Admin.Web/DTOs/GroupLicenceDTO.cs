﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class GroupLicenceDTO
    {
        public GroupLicenceDTO()
        {
            Services = new List<ServiceDropdownDTO>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public DateTime RegistrationDate { get; set; }
        public DateTime? ModifyDate { get; set; }
        public string ModifyBy { get; set; }
        public List<ServiceDropdownDTO> Services { get; set; }
        public int UsersCount { get; set; }
        public List<UserDTO> Users { get; set; }
        public List<Guid> UserGuids { get; set; }
    }
}