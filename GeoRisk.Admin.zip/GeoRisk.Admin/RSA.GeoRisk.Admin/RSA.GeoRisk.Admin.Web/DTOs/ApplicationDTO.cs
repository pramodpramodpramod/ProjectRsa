﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class ApplicationDTO
    {
        public int AppId { get; set; }
        public string Name { get; set; }
        public string Currencies { get; set; }
        
    }
}