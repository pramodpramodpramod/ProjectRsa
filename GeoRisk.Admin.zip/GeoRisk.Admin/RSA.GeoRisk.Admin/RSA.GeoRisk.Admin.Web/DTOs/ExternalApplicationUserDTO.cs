﻿using System;
using System.Collections.Generic;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class ExternalApplicationUserDTO
    {
        public ExternalApplicationUserDTO()
        {
            Services = new List<ServiceDropdownDTO>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string ExternalAppUserUrl { get; set; }
        public bool IsActive { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Email { get; set; }
        public string ServiceEndpoint { get; set; }
        public List<ServiceDropdownDTO> Services { get; set; }
    }
}