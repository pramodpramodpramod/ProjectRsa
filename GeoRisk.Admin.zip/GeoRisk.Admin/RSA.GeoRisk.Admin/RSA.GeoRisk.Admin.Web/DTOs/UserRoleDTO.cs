﻿using System;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class UserRoleDTO
    {
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
    }
}