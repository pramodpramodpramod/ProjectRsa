﻿using System;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class AuditUserDto
    {
        private string _archivedBy;
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get { return string.Format("{0} {1}", FirstName, LastName); }
        }
        public string Email { get; set; }
        public string Application { get; set; }
        public DateTime? DeletedDate { get; set; }
        public string Location { get; set; }
        public string ArchivedBy
        {
            get { return String.IsNullOrEmpty(_archivedBy) ? string.Empty : _archivedBy; }
            set { _archivedBy = value; }
        }

        public static AuditUserDto FromUser(aspnet_Users user)
        {
            return new AuditUserDto
            {
                Application = user.aspnet_Applications.ApplicationName,
                DeletedDate = DateTime.Now,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Location = user.Location,
                UserName = user.UserName,
             };
        }
    }
}