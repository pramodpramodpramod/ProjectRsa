﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class GroupLincenceUserServiceDTO
    {
        public int GroupId { get; set; }
        public List<Guid> Users { get; set; }
        public List<int> Services { get; set; }
    }
}