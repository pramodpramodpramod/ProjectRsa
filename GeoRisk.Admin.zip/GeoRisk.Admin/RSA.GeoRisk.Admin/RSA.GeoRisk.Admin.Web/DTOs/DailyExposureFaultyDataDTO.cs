﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RSA.GeoRisk.Admin.Web.Mapping.Enums;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class DailyExposureFaultyDataDTO
    {
        public int Id { get; set; }
        public string BatchId { get; set; }
        public string ProblemCategory { get; set; }
        public string ProblemInput { get; set; }
        public string Username { get; set; }
        public string ReportedBy { get; set; }
        public string ProducingOperation { get; set; }
        public string LineOfBusiness { get; set; }
        public string PolicySystem { get; set; }
        public string PolicyNumber { get; set; }
        public string NameOfInsured { get; set; }
        public string LocationDeletionDate { get; set; }
        public decimal? NetTotalSumInsured { get; set; }
        public decimal? GrossTotalSumInsured { get; set; }
        public decimal? NetEstimatedMaximumLoss { get; set; }
        public decimal? GrossEstimatedMaximumLoss { get; set; }
        public string CurrencyCode { get; set; }
        public string CurrencyValue { get; set; }
        public string SuppliedAddress { get; set; }
        public string SystemAddress { get; set; }
        public string GeocodeAccuracy { get; set; }
        public string Status { get; set; }
        public DateTime ResolvedDate { get; set; }
        public string ResolvedBy { get; set; }

    }
}