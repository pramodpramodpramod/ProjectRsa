﻿using System.Collections.Generic;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class ServiceDetail
    {
        public int ServiceId { get; set; }
        public string Name { get; set; }
        public string ArcGisServiceLayerName { get; set; }

        public string ServiceType { get; set; }

        public int? ServiceType_ServiceTypeId { get; set; }

        public string BusinessType { get; set; }

        public int? BusinessType_BusinessTypeId { get; set; }

        public string Url { get; set; }

        public bool Visible { get; set; }

        public bool IsActive { get; set; }

        public bool? IsDefault { get; set; }

        public string Attribution { get; set; }

        public string Token { get; set; }

        public string Regions { get; set; }

        public double? Opacity { get; set; }

        public string Layers { get; set; }

        public int? MapServiceType_MapServiceTypeId { get; set; }

        public int? BaseMapStyle_BaseMapStyleId { get; set; }

        public bool? Identify { get; set; }

        public bool? Mandated { get; set; }

        public int? LeafletType_LeafletTypeId { get; set; }

        public string Fields { get; set; }

        public string Style { get; set; }

        public string LegendImage { get; set; }
        public List<EnumDTO> LicenceTypes { get; set; }
        public int LicenceType { get; set; }
    }
}