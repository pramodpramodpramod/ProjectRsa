﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class ServiceDropdownDTO
    {
        public int ServiceId { get; set; }
        public string Name { get; set; }
        public string Application { get; set; }
    }
}