﻿namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class ServiceResponse
    {
        public int ServiceId { get; set; }
        public string Name { get; set; }
        public string NameSearch { get; set; }
        public string ArcGisServiceLayerName { get; set; }
        public string ServiceType { get; set; }
        public string BusinessType { get; set; }
        public string LicenceType { get; set; }
        public string application { get; set; }
        public int usersCount { get; set; }
    }
}