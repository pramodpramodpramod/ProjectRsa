﻿using System;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class ResponseWrapper<T>
    {
        public T Data { get; private set; }

        public void SetData(T value)
        {
            Data = value;
        }

        public void SetData(T value, string message)
        {
            if (value == null)
            {
                SetData(value);
                Message = message;
            }
        }
        public string Message { get; set; }
    }
}