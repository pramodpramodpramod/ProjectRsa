﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class NewUserExtraInfoDTO
    {
        public List<UserRoleDTO> AllRoles { get; set; }
        public List<string> Locations { get; set; }

    }
}