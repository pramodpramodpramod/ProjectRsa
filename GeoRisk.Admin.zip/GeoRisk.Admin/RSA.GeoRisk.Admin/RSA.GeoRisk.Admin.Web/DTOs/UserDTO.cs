﻿using System;

namespace RSA.GeoRisk.Admin.Web.DTOs
{
    public class UserDTO
    {
        private string _suspendedBy;
        private string _activatedBy;

        public string UserId { get; set; }
        public string UserName { get; set; }
        public string LoweredUserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get { return string.Format("{0} {1}", FirstName, LastName); }
        }
        public string FullNameSearch { get; set; }
        public string Email { get; set; }
        public string ApproverEmail { get; set; }
        public string RoleName { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? LastActivityDate { get; set; }
        public bool IsActive { get; set; }
        public Guid ApplicationId { get; set; }
        public string[] Roles { get; set; }
        public string Location { get; set; }
        public DateTime? LastSuspendedDate { get; set; }
        public string SuspendedBy
        {
            get { return String.IsNullOrEmpty(_suspendedBy) ? string.Empty : _suspendedBy; }
            set { _suspendedBy = value; }
        }

        public string ActivatedBy
        {
            get { return String.IsNullOrEmpty(_activatedBy) ? string.Empty : _activatedBy; }
            set { _activatedBy = value; }
        }
        public Nullable<System.DateTime> ActivatedByDate { get; set; }
    }
}