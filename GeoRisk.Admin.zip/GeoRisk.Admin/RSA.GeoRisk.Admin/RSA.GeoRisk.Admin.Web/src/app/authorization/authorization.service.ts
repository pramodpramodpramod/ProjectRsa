import { Injectable } from '@angular/core';
import { AuthenticationService } from '../services/service-barrel';

@Injectable()
export class AuthorizationService {
    private readonly adminActions: any;
    private userRoles: Set<string>;
    constructor(authenticationService: AuthenticationService) {
        this.userRoles = new Set(authenticationService.getUser().roles);
        this.adminActions = require('./adminActions.json');
    }

    public isAuthorized(path: string[]): boolean {
        if (!path.length) {
            return false;
        }
        const allowedRoles = this.findAllowedRolesForAction(this.adminActions, path);
        if (!(allowedRoles && allowedRoles.length > 0 && this.userRoles.size)) {
            return false;
        }

        return allowedRoles.some(role => this.userRoles.has(role));
    }

    private findAllowedRolesForAction(currentObject: any, keys: string[], index = 0) {
        const key = keys[index];
        if (currentObject[key] && index < keys.length - 1) {
            return this.findAllowedRolesForAction(currentObject[key], keys, index + 1);
        } else if (currentObject[key] && index === keys.length - 1) {
            return currentObject[key];
        } else {
            return false;
        }
    }
}
