import { NgModule, ApplicationRef, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
//import * as helper from '../public/helper';
//import * as helper from '../../helper';
import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { NgSelectModule } from '@ng-select/ng-select';


import { removeNgStyles, createNewHosts } from '@angularclass/hmr';
import {
    GeoriskAppsService, AdminService, AlertService, GeoriskAppsCurrenciesService, ReportingService, ExportToCsvService,
    EmailService, AccellionUserService, AuthenticationService, AuthorizationService, ExternalUserService, GlobalExposureService,DataLicenceService
} from './services/service-barrel';
import { AuthenticationInterceptor } from './interceptors/interceptor-barrel';
import {
    NavMenuComponent,
    HomeComponent,
    PortfolioComponent,
    LocalComponent,
    UserMainComponent,
    UserListComponent,
    UserAddComponent,
    UserEditComponent,
    AppServicesComponent,
    AppServiceAddComponent,
    AppCurrenciesComponent,
    AppServiceSelectorComponent,
    AppServiceDetailComponent,
    AlertComponent,
    AppServicesMainComponent,
    ReportingMainComponent,
    GdprMainComponent,
    DataLicenceComponent,
    GroupLicenceListComponent,
    GroupLicenceAddComponent,
    GroupLicenceEditComponent,
    GroupLicenceMainComponent,
    IndividualLicenceMainComponent,
    IndividualLicenceListComponent,
    BatchComponent,
    BatchAddComponent,
    BatchListComponent,
    SanctionsComponent,
    SanctionAddComponent,
    SanctionEditComponent,
    SanctionListComponent,
    AccellionComponent,
    AccellionUserMainComponent,
    AccellionUserListComponent,
    AccellionUserAddComponent,
    AccellionUserEditComponent,
    AdministrationComponent,
    AdministrationUserListComponent,
    UnauthorizedComponent,
    ArchiveComponent,
    ExternalAppComponent,
    ExternalAppUserMainComponent,
    ExternalAppUserAddComponent,
    ExternalAppUserEditComponent,
    ExternalAppUserListComponent,
    EmailComponent,
    GlobalExposureComponent,
    GlobalExposureFaultyDataListComponent
} from './components/component-barrel';
import { ServiceDomainDetailsResolver } from './components/resolvers/service-domain-details.resolver';
import { AuthorizeDirective } from './directives/authorize.directive';
import { RouteGuardService } from './services/routeGuard.service';
import { CommonModule } from '@angular/common';

export function appInit(authenticationService: AuthenticationService) {
    return () => authenticationService.loadUser();
}
//const { directorynames } = helper;
@NgModule({
    imports: [
        BrowserModule,
        HttpModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        routing,
        Ng4LoadingSpinnerModule.forRoot(),
        NgMultiSelectDropDownModule.forRoot(),
        NgSelectModule

    ],
    declarations: [
        AlertComponent,
        AppComponent,
        NavMenuComponent,
        HomeComponent,
        LocalComponent,
        PortfolioComponent,
        UserMainComponent,
        UserListComponent,
        UserAddComponent,
        UserEditComponent,
        AppServicesComponent,
        AppServiceAddComponent,
        AppServicesMainComponent,
        AppServiceSelectorComponent,
        AppServiceDetailComponent,
        AppCurrenciesComponent,
        ReportingMainComponent,
        GdprMainComponent,
        DataLicenceComponent,
        GroupLicenceListComponent,
        GroupLicenceAddComponent,
        GroupLicenceMainComponent,
        GroupLicenceEditComponent,
        IndividualLicenceMainComponent,
        IndividualLicenceListComponent,
        BatchComponent,
        BatchAddComponent,
        BatchListComponent,
        SanctionsComponent,
        SanctionAddComponent,
        SanctionEditComponent,
        SanctionListComponent,
        AccellionComponent,
        AccellionUserMainComponent,
        AccellionUserListComponent,
        AccellionUserAddComponent,
        AccellionUserEditComponent,
        AdministrationComponent,
        AdministrationUserListComponent,
        UnauthorizedComponent,
        ArchiveComponent,
        AuthorizeDirective,
        ExternalAppComponent,
        ExternalAppUserMainComponent,
        ExternalAppUserAddComponent,
        ExternalAppUserEditComponent,
        ExternalAppUserListComponent,
        EmailComponent,
        GlobalExposureComponent,
        GlobalExposureFaultyDataListComponent
    ],
    providers: [
        //{ provide: 'API_URL', useFactory: () => `${window.location.protocol}//${window.location.hostname}/${directorynames}/api` },
        { provide: 'API_URL', useFactory: () => `${window.location.protocol}//${window.location.hostname}/GeoRiskAdminNew/api` },
        { provide: APP_INITIALIZER, useFactory: appInit, deps: [AuthenticationService], multi: true },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthenticationInterceptor,
            multi: true
        },
        AlertService,
        AdminService,
        AuthenticationService,
        GeoriskAppsService,
        ReportingService,
        ServiceDomainDetailsResolver,
        GeoriskAppsCurrenciesService,
        ExportToCsvService,
        EmailService,
        AccellionUserService,
        AuthorizationService,
        ExternalUserService,
        GlobalExposureService,
        RouteGuardService,
        DataLicenceService
    ],
    bootstrap: [AppComponent]
})
    // 6AprilChnages
    //export { helper };
//export helper{ };

export class AppModule {
    constructor(public appRef: ApplicationRef) { }
    hmrOnInit(store) {
        console.log('HMR store', store);
    }
    hmrOnDestroy(store) {
        let cmpLocation = this.appRef.components.map(cmp => cmp.location.nativeElement);
        // recreate elements
        store.disposeOldHosts = createNewHosts(cmpLocation);
        // remove styles
        removeNgStyles();
    }
    hmrAfterDestroy(store) {
        // display new elements
        store.disposeOldHosts();
        delete store.disposeOldHosts;
    }
}
