import { RouterModule, Routes } from '@angular/router';
import { AppServiceAddComponent } from './components/app-services/app-service-add.component';
import {
    AppServicesMainComponent,
    ReportingMainComponent,
    AppServiceDetailComponent,
    AppCurrenciesComponent,
    BatchComponent,
    SanctionsComponent,
    AppServicesComponent,
    LocalComponent,
    PortfolioComponent,
    AccellionComponent,
    HomeComponent,
    UserMainComponent,
    UserListComponent,
    UserAddComponent,
    UserEditComponent,
    AccellionUserListComponent,
    AccellionUserAddComponent,
    AccellionUserMainComponent,
    AccellionUserEditComponent,
    AdministrationComponent,
    AdministrationUserListComponent,
    ArchiveComponent,
    SanctionListComponent,
    SanctionEditComponent,
    SanctionAddComponent,
    BatchListComponent,
    BatchAddComponent,
    ExternalAppComponent,
    ExternalAppUserMainComponent,
    ExternalAppUserListComponent,
    ExternalAppUserAddComponent,
    ExternalAppUserEditComponent,
    EmailComponent,
    GdprMainComponent,
    GlobalExposureComponent,
    GlobalExposureFaultyDataListComponent,
    GroupLicenceListComponent,
    GroupLicenceMainComponent,
    GroupLicenceEditComponent,
    DataLicenceComponent,
    IndividualLicenceMainComponent,
    IndividualLicenceListComponent
} from './components/component-barrel';
import { ServiceDomainDetailsResolver } from './components/resolvers/service-domain-details.resolver';
import { RouteGuardService } from './services/routeGuard.service';
import { GroupLicenceAddComponent } from './components/group-licence/group-licence-add/group-licence-add.component';


const routes: Routes = [
    {
        path: 'reporting',
        component: ReportingMainComponent,
        children: [
            { path: '', redirectTo: '/reporting/batches/list', pathMatch: 'full' },
            {
                path: 'batches',
                component: BatchComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: BatchListComponent,
                        data: {
                            appName: 'reporting'
                        }
                    },
                    {
                        path: 'add',
                        component: BatchAddComponent,
                        data: {
                            appName: 'reporting'
                        }
                    }
                ]
            },
            {
                path: 'sanctions',
                component: SanctionsComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: SanctionListComponent
                    },
                    {
                        path: 'add',
                        component: SanctionAddComponent
                    },
                    {
                        path: 'edit/:objectid',
                        component: SanctionEditComponent
                    }
                ]
            }
        ],
        canActivate: [RouteGuardService]

    },
    {
        path: 'gdpr',
        component: GdprMainComponent,
        children: [
            { path: '', redirectTo: '/gdpr/batches/list', pathMatch: 'full' },
            {
                path: 'batches',
                component: BatchComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: BatchListComponent,
                        data: {
                            appName: 'gdpr'
                        }
                    },
                    {
                        path: 'add',
                        component: BatchAddComponent,
                        data: {
                            appName: 'gdpr'
                        }
                    }
                ]
            }
        ],
        canActivate: [RouteGuardService]

    },
    {
        path: 'data-licence',
        component: DataLicenceComponent,
        children: [
            { path: '', redirectTo: '/data-licence/group-licence/list', pathMatch: 'full' },
            {
                path: 'group-licence',
                component: GroupLicenceMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: GroupLicenceListComponent,
                        data: {
                            appName: 'group-licence'
                        }
                    },
                    {
                        path: 'add',
                        component: GroupLicenceAddComponent,
                        data: {
                            appName: 'group-licence'
                        }
                    },
                    {
                        path: 'edit/:groupLicenceId',
                        component: GroupLicenceEditComponent,
                        data: {
                            appName: 'group-licence'
                        }
                    }
                ]
            },
            {
                path: 'individual-licence',
                component: IndividualLicenceMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: IndividualLicenceListComponent,
                        data: {
                            appName: 'individual-licence'
                        }
                    }
                ]
            }
        ],
        canActivate: [RouteGuardService]

    },
    {
        path: 'local-ii',
        component: LocalComponent,
        children: [
            { path: '', redirectTo: '/local/users/list', pathMatch: 'full' }
        ],
        canActivate: [RouteGuardService]
    },
    {
        path: 'local',
        component: LocalComponent,
        children: [
            { path: '', redirectTo: '/local/users/list', pathMatch: 'full' },
            {
                path: 'users',
                component: UserMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: UserListComponent,
                        data: {
                            appName: 'local-ii',
                            appDisplayName: 'Local'
                        }
                    },
                    {
                        path: 'add',
                        component: UserAddComponent,
                        data: {
                            appName: 'local-ii',
                            appDisplayName: 'Local'
                        }
                    },
                    {
                        path: 'edit/:userName',
                        component: UserEditComponent,
                        data: {
                            appName: 'local-ii',
                            appDisplayName: 'Local'
                        }
                    }
                ],
                data:
                    {
                        appName: 'local-ii'
                    }
            },
            {
                path: 'services',
                component: AppServicesMainComponent,
                children: [
                    {
                        path: 'list',
                        component: AppServicesComponent,
                        data: {
                            appName: 'local-ii'
                        },
                    },
                    {
                        path: 'add',
                        component: AppServiceAddComponent,
                        data: {
                            appName: 'Local',
                            appDisplayName: 'Local'
                        },
                        resolve: { domainDetails: ServiceDomainDetailsResolver }
                    },
                    {
                        path: 'edit/:serviceId',
                        component: AppServiceDetailComponent,
                        data: {
                            appName: 'local-ii'
                        },
                        resolve: { domainDetails: ServiceDomainDetailsResolver }
                    }
                ]
            },
            {
                path: 'archive',
                component: ArchiveComponent,
                data: {
                    appName: 'local-ii',
                    appDisplayName: 'Local'
                }
            },
            {
                path: 'email',
                component: EmailComponent,
                data: {
                    appName: 'local',
                    appDisplayName: 'Local'
                }
            }
        ],
        data:
            {
                appName: 'local-ii'
            },
        canActivate: [RouteGuardService]
    },
    {
        path: 'portfolio',
        component: PortfolioComponent,
        children: [
            { path: '', redirectTo: '/portfolio/users/list', pathMatch: 'full' },
            {
                path: 'users',
                component: UserMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: UserListComponent,
                        data: {
                            appName: 'portfolio',
                            appDisplayName: 'Portfolio'
                        }
                    },
                    {
                        path: 'add',
                        component: UserAddComponent,
                        data: {
                            appName: 'portfolio',
                            appDisplayName: 'Portfolio'
                        }
                    },
                    {
                        path: 'edit/:userName',
                        component: UserEditComponent,
                        data: {
                            appName: 'portfolio',
                            appDisplayName: 'Portfolio'
                        }
                    }
                ],
                data: {
                    appName: 'portfolio'
                }
            },
            {
                path: 'currencies',
                component: AppCurrenciesComponent,
                data: {
                    appName: 'portfolio'
                }
            },
            {
                path: 'services',
                component: AppServicesMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: AppServicesComponent,
                        data: {
                            appName: 'portfolio'
                        }
                    },
                    {
                        path: 'add',
                        component: AppServiceAddComponent,
                        data: {
                            appName: 'portfolio',
                            appDisplayName: 'Portfolio'
                        },
                        resolve: { domainDetails: ServiceDomainDetailsResolver }
                    },
                    {
                        path: 'edit/:serviceId',
                        component: AppServiceDetailComponent,
                        data: {
                            appName: 'portfolio'
                        },
                        resolve: { domainDetails: ServiceDomainDetailsResolver }
                    }
                ]
            },
            {
                path: 'archive',
                component: ArchiveComponent,
                data: {
                    appName: 'portfolio',
                    appDisplayName: 'Portfolio'
                }
            },
            {
                path: 'email',
                component: EmailComponent,
                data: {
                    appName: 'portfolio',
                    appDisplayName: 'Portfolio'
                }
            }
        ],
        data:
            {
                appName: 'portfolio'
            },
        canActivate: [RouteGuardService]
    },
    {
        path: 'accellion',
        component: AccellionComponent,
        children: [
            { path: '', redirectTo: '/accellion/users/list', pathMatch: 'full' },
            {
                path: 'users',
                component: AccellionUserMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: AccellionUserListComponent,
                        data: {
                            appName: 'accellion',
                            appDisplayName: 'Accellion'
                        }
                    },
                    {
                        path: 'add',
                        component: AccellionUserAddComponent,
                        data: {
                            appName: 'accellion',
                            appDisplayName: 'Accellion'
                        }
                    },
                    {
                        path: 'edit/:userId',
                        component: AccellionUserEditComponent,
                        data: {
                            appName: 'accellion',
                            appDisplayName: 'Accellion'
                        }
                    }
                ],
                data: {
                    appName: 'accelion'
                }
            }
        ],
        canActivate: [RouteGuardService]
    },
    {
        path: 'externalapp',
        component: ExternalAppComponent,
        children: [
            { path: '', redirectTo: '/externalapp/users/list', pathMatch: 'full' },
            {
                path: 'users',
                component: ExternalAppUserMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: ExternalAppUserListComponent,
                        data: {
                            appName: 'externalapp',
                            appDisplayName: 'ExternalApp'
                        }
                    },
                    {
                        path: 'add',
                        component: ExternalAppUserAddComponent,
                        data: {
                            appName: 'externalapp',
                            appDisplayName: 'ExternalApp'
                        }
                    },
                    {
                        path: 'edit/:userId',
                        component: ExternalAppUserEditComponent,
                        data: {
                            appName: 'externalapp',
                            appDisplayName: 'ExternalApp'
                        }
                    }
                ],
                data: {
                    appName: 'externalapp'
                }
            }
        ],
        canActivate: [RouteGuardService]
    },
    {
        path: 'globalexposure',
        component: GlobalExposureComponent,
        children: [
            { path: '', redirectTo: '/globalexposure/faultydata/openedList', pathMatch: 'full' },
            {
                path: 'faultydata/openedList',
                component: GlobalExposureFaultyDataListComponent,
                data: {
                    appName: 'globalexposurefaultyopened',
                    appDisplayName: 'FaultyOpenedData'
                }
            },
            {
                path: 'faultydata/resolvedList',
                component: GlobalExposureFaultyDataListComponent,
                data: {
                    appName: 'globalexposurefaultyresolved',
                    appDisplayName: 'FaultyResolvedData'
                }
            }
        ],
        canActivate: [RouteGuardService]

    },
    {
        path: 'administration',
        component: AdministrationComponent,
        children: [
            { path: '', redirectTo: '/administration/users/list', pathMatch: 'full' },
            {
                path: 'users',
                component: UserMainComponent,
                children: [
                    { path: '', redirectTo: 'list', pathMatch: 'full' },
                    {
                        path: 'list',
                        component: AdministrationUserListComponent,
                        data: {
                            appName: 'admin'
                        }
                    },
                    {
                        path: 'add',
                        component: UserAddComponent,
                        data: {
                            appName: 'admin',
                            appDisplayName: 'Admin'
                        },
                        resolve: { domainDetails: ServiceDomainDetailsResolver }
                    },
                    {
                        path: 'edit/:userName',
                        component: UserEditComponent,
                        data: {
                            appName: 'admin',
                            appDisplayName: 'Admin'
                        },
                        resolve: { domainDetails: ServiceDomainDetailsResolver }
                    }
                ]
            }
        ],
        canActivate: [RouteGuardService]
    },
    { path: 'home', component: HomeComponent },
    { path: '', redirectTo: '/home', pathMatch: 'full' },
];

export const routing = RouterModule.forRoot(routes);
