import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthenticationService, EmailService, Ng4LoadingSpinnerService, AlertService } from '../../services/service-barrel';
import { EmailSettings } from '../../objects/objects-barrel';
import { IAuthenticatedUser } from '../../objects/authentication/authenticateduser';
import { NgForm } from '@angular/forms';
import * as $ from 'jquery';

@Component({
    selector: 'app-email',
    templateUrl: './email.component.html'
})
export class EmailComponent implements OnInit {

    emailSettings: EmailSettings;
    currentApp: string;
    currentAppDisplayName: string;
    editorWidgetId: string;
    userObject = '{user}';
    authenticatedUser: IAuthenticatedUser;
    @Input() emailSubject: string;
    @Input() emailContent: string;

    constructor(private authenticationService: AuthenticationService,
        private activatedRoute: ActivatedRoute,
        private emailService: EmailService,
        private spinnerService: Ng4LoadingSpinnerService,
        private alertService: AlertService) {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.currentAppDisplayName = this.activatedRoute.snapshot.data['appDisplayName'];
    }

    ngOnInit() {
        this.emailSettings = new EmailSettings();
        this.authenticatedUser = this.authenticationService.getUser();
        this.spinnerService.show();
        this.emailService.getEmailSettings(this.activatedRoute.snapshot.data['appName']).then(
            emailSettings => {
                this.emailSettings = emailSettings === null ? new EmailSettings() : emailSettings;
                $('#emailEditor').summernote('code', this.emailSettings.emailContent);
                this.spinnerService.hide();
            });
        $('#emailEditor').summernote({ height: 300 });
    }

    onSubmit(myform: NgForm) {
        if (myform.valid) {
            this.saveEmailSettings();
        }
    }

    onReset() {
        this.emailService.getEmailSettings(this.activatedRoute.snapshot.data['appName']).then(
            emailSettings => {
                this.emailSettings = emailSettings === null ? new EmailSettings() : emailSettings;
                $('#emailEditor').summernote('code', this.emailSettings.emailContent);
                this.spinnerService.hide();
            });
    }

    saveEmailSettings() {
        this.spinnerService.show();
        this.emailSettings.applicationName = this.currentApp;
        this.emailSettings.emailContent = $('.note-editable').html();
        this.emailService.saveEmailSettings(this.emailSettings)
            .then(() => {
                this.alertService.success('Email settings for ' + this.currentApp + ' are successfully saved.');
                this.spinnerService.hide();
            })
            .catch(_ => {
                this.alertService.error('Unable to save settings!');
                this.spinnerService.hide();
            });
    }
}
