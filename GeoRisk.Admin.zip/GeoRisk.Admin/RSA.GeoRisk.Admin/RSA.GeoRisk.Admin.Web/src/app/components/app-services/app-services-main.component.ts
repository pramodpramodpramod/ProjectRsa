import { Component } from '@angular/core';

@Component({
    selector: 'app-services-main',
    templateUrl: './app-services-main.component.html'
})

export class AppServicesMainComponent {

}
