﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { GeoriskAppsService, AlertService } from '../../services/service-barrel';
import { Service } from '../../objects/georiskapps/service';

@Component({
    selector: 'app-service-details',
    templateUrl: './app-service-detail.component.html',
    // providers: [GeoriskAppsService]
})

export class AppServiceDetailComponent implements OnInit {

    selectedService: Service = new Service();
    serviceId: string;
    businessTypes: any;
    baseMapStyles: any;
    leafletTypes: any;
    licenceType: any;
    licenceTypes: any;
    mapServiceTypes: any;
    serviceTypes: any;
    services: Service[];
    serviceEditMode = true;

    constructor(private route: ActivatedRoute, private georiskAppsService: GeoriskAppsService,
        private alertService: AlertService, private spinnerService: Ng4LoadingSpinnerService,
        private router: Router) { }

    ngOnInit() {
        this.route.params
            .switchMap((params: Params) => this.georiskAppsService.getServiceDetails(+params['serviceId']))
            .subscribe(service => {
                this.selectedService = service;
                this.licenceTypes = this.selectedService.licenceTypes;
            });

        this.route.data.subscribe((data) => {
            this.businessTypes = data.domainDetails.businessTypes;
            this.baseMapStyles = data.domainDetails.baseMapStyles;
            this.leafletTypes = data.domainDetails.leafletTypes;
            this.mapServiceTypes = data.domainDetails.mapServiceTypes;
            this.serviceTypes = data.domainDetails.serviceTypes;
        });
    }

    onSubmit(serviceForm: NgForm) {
        if (serviceForm.invalid) {
            return;
        }

        this.updateService();
    }

    parseBusinessType(value: string) {
        let businessType = this.businessTypes.find(function (type) {
            return type.name === value;
        });

        this.selectedService.businessType_BusinessTypeId = businessType ? businessType.businessTypeId : null;
    }
    parseLicenceType(value: string) {
        let licenceType = this.licenceTypes.find(function (type) {
            return type.name === value;
        });

        this.selectedService.licenceType = licenceType?licenceType.value:0 ;
    }
    parseBaseMapType(value: string) {
        let baseMapType = this.baseMapStyles.find(function (type) {
            return type.name === value;
        });

        this.selectedService.baseMapStyle_BaseMapStyleId = baseMapType ? baseMapType.baseMapStyleId : null;
    }

    serviceSelected(selectedService: Service) {
        this.selectedService = selectedService;
    }

    serviceEditClicked() {
        this.serviceEditMode = !this.serviceEditMode;
    }

    updateService() {
        let updatedService = new Service(
            {
                arcGisServiceLayerName: this.selectedService.arcGisServiceLayerName,
                attribution: this.selectedService.attribution,
                baseMapStyle_BaseMapStyleId: this.selectedService.baseMapStyle_BaseMapStyleId,
                businessType_BusinessTypeId: this.selectedService.businessType_BusinessTypeId,
                identify: this.selectedService.identify,
                isActive: this.selectedService.isActive,
                isDefault: this.selectedService.isDefault,
                legendImage: this.selectedService.legendImage,
                legendImageUrl: this.selectedService.legendImageUrl,
                opacity: this.selectedService.opacity,
                serviceId: this.selectedService.serviceId,
                url: this.selectedService.url,
                visible: this.selectedService.visible,
                layers: this.selectedService.layers,
                licenceType:this.selectedService.licenceType
            });

        this.spinnerService.show();
        this.georiskAppsService.updateService(updatedService).subscribe(resp => {
            if (resp.ClassName === 'System.Exception') {
                this.alertService.error(this.buildErrorMessage(resp) + ' ' + resp.Message, false);
            } else {
                this.redirectToServicesPage();
                this.alertService.success('Service ' + resp + ' was successfully updated!');
            }
            this.spinnerService.hide();
        });
    }

    redirectToServicesPage() {
        this.router.navigate(['../../list'], { relativeTo: this.route });
    }

    fileChange(event) {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            let file: File = fileList[0];
            let myReader: FileReader = new FileReader();
            myReader.onloadend = () => {
                this.selectedService.legendImage = myReader.result.split(',')[1];
            };
            myReader.readAsDataURL(file);

        }
    }

    private buildErrorMessage(r: any) {
        let errorMessage = '';
        if (r.InnerException && r.InnerException.Message) {
            errorMessage += r.InnerException.Message;
            if (r.InnerException.InnerException.Message) {
                if (r.InnerException.InnerException.Message !== r.InnerException.Message) {
                    errorMessage += ' ' + r.InnerException.InnerException.Message;
                }
                if (r.InnerException.InnerException.InnerException) {
                    errorMessage += ' ' + r.InnerException.InnerException.InnerException.Message;
                }
            }
        }
        return errorMessage;
    }
}
