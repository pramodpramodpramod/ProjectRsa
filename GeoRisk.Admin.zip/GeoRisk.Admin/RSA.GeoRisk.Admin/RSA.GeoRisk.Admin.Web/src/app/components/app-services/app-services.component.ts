﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GeoriskAppsService } from '../../services/georiskapps.service';
import { AuthorizationService, AlertService } from '../../services/service-barrel';
import { Service } from '../../objects/georiskapps/service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import * as $ from 'jquery';
import 'datatables.net';


@Component({
    selector: 'app-services',
    templateUrl: './app-services.component.html'
})

export class AppServicesComponent implements OnInit {

    services: Service[];
    selectedService: Service;
    currentApp: string;

    tableWidget: any;
    tableWidgetId = '#services';

    constructor(private georiskAppsService: GeoriskAppsService,
        private activatedRoute: ActivatedRoute, private router: Router,
        private authorizationService: AuthorizationService,
        private spinnerService: Ng4LoadingSpinnerService,
        private alertService: AlertService
    ) { }

    ngOnInit(): void {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.getServices();
    }

    getServices(): void {
        this.spinnerService.show();

        let appName = this.activatedRoute.snapshot.data['appName'] === 'local-ii' ? 'local' : this.activatedRoute.snapshot.data['appName'];

        this.georiskAppsService.getAppServices(appName).then(services => {
            this.services = services;
            this.initDatatable();
            this.spinnerService.hide();
        });
    }

    serviceSelected(selectedService: Service) {
        this.selectedService = selectedService;
    }

    editService(service: Service): void {
        this.router.navigate(['../edit', service.serviceId], { relativeTo: this.activatedRoute });
    }

    private initDatatable(): void {
        this.tableWidget = $(this.tableWidgetId).DataTable({
            select: true,
            order: [[1, 'asc']],
            destroy: true,
            data: this.services,
            columns: [
                {
                    'data': 'serviceId',
                    'visible': false
                },
                {
                    'className': 'btn-dataTable-details',
                    'data': 'name',
                    'render': function (data) {
                        return '<button type="button" class="btn btn-link" title= "Service details" >' + data + '</button>';
                    },
                },
                { 'data': 'arcGisServiceLayerName' },
                { 'data': 'serviceType' },
                { 'data': 'businessType' },
                { 'data': 'licenceType' },
                {
                    'className': 'btn-dataTable-remove',
                    'orderable': false,
                    'data': null,
                    'render': function () {
                        return '<span class="glyphicon glyphicon-trash" title= "Delete service"></span>';
                    },
                    'visible': this.authorizationService.isAuthorized([this.currentApp, 'deleteService'])
                }
            ]
        });

        this.initDataTableEvents();
    }

    deleteService() {
        const serviceName = $('#appServiceToDelete').text();
        let serviceId = $('#serviceId').val();
        this.spinnerService.show();
        this.georiskAppsService.deleteService(serviceId).then(deleteResponse => {
            if (deleteResponse !== null) {
                this.spinnerService.hide();
                if (deleteResponse.ClassName === 'System.Exception') {
                    this.alertService.error(deleteResponse.InnerException.InnerException.Message + ' ' + deleteResponse.Message, false);
                }
            } else {
                this.getServices();
                this.spinnerService.hide();
                this.alertService.success(serviceName + ' has been deleted.');
            }
        });
    }

    private initDataTableEvents(): void {
        let that = this;

        $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-details', function () {
            let tr = $(this).closest('tr');
            let rowData = that.tableWidget.row(tr).data();
            that.editService(rowData);
        });

        $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-remove', function () {
            let tr = $(this).closest('tr');
            let rowData = that.tableWidget.row(tr).data();
            $("#serviceId").val(rowData['serviceId']);
            $("#appServiceToDelete").text(rowData['name']);
            $("#deleteServiceModal").modal('show');
        });
    }
}
