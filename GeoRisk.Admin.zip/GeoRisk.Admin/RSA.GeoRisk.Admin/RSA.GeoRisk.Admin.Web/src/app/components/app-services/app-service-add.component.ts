import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Service } from '../../objects/georiskapps/service';
import { GeoriskAppsService, AlertService, Ng4LoadingSpinnerService } from '../../services/service-barrel';
//import { NgForm } from '@angular/forms';
// import { RequestOptions } from "@angular/http";

@Component({
    templateUrl: './app-service-add.component.html',
    styles: [`
        .ng-valid[required], .ng-valid.required  {  border-left: 5px solid #42A948; /* green */ }
        .ng-invalid:not(form)  {  border-left: 5px solid #a94442; /* red */}
    `]
})

export class AppServiceAddComponent implements OnInit {

    serviceTypes: any;
    mapServiceTypes: any;
    leafletTypes: any;
    baseMapStyles: any;
    businessTypes: any;
    licenceTypes: any;
    submitted = false;

    currentApp: string;

    newService = new Service(
        {
            arcGisServiceLayerName: '',
            attribution: '',
            baseMapStyle_BaseMapStyleId: null,
            businessType_BusinessTypeId: null,
            identify: null,
            isActive: null,
            isDefault: null,
            layers: '',
            leafletType_LeafletTypeId: null,
            legendImage: '',
            legendImageUrl: '',
            mandated: null,
            map_MapId: null,
            mapServiceType_MapServiceTypeId: null,
            name: '',
            opacity: null,
            regions: '',
            serviceType_ServiceTypeId: null,
            token: '',
            url: '',
            visible: null,
            licenceType: null
        });

    constructor(private activatedRoute: ActivatedRoute,
        private georiskAppsService: GeoriskAppsService,
        private spinnerService: Ng4LoadingSpinnerService,
        private alertService: AlertService,
        private router: Router,
        private route: ActivatedRoute) { }

    ngOnInit(): void {
        var that = this;
        this.currentApp = this.activatedRoute.snapshot.data['appName'];

        this.activatedRoute.data.subscribe((data) => {
            that.businessTypes = data.domainDetails.businessTypes;
            that.baseMapStyles = data.domainDetails.baseMapStyles;
            that.leafletTypes = data.domainDetails.leafletTypes;
            that.mapServiceTypes = data.domainDetails.mapServiceTypes;
            that.serviceTypes = data.domainDetails.serviceTypes;
            that.licenceTypes = data.domainDetails.licenceTypes;
        });
    }

    onSubmit() {
        this.spinnerService.hide();
        let serviceName = this.newService.name;
        this.georiskAppsService.createNewServiceEntry(this.newService, this.currentApp).subscribe(resp => {

            this.alertService.success(serviceName + ' service created in ' + this.currentApp, false);
            this.spinnerService.show();
            this.router.navigate(['../list/'], { relativeTo: this.route });
            serviceName = resp;
        });
    }

    fileChange(event) {
        this.spinnerService.hide();
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            let file: File = fileList[0];
            let myReader: FileReader = new FileReader();
            myReader.onloadend = () => {
                this.newService.legendImage = myReader.result.split(',')[1];
            };
            myReader.readAsDataURL(file);
            this.spinnerService.show();
        }
    }

    // TODO: Remove this when we're done
    get diagnostic() { return JSON.stringify(this.newService); }
}
