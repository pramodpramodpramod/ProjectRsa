﻿import { Component } from '@angular/core';

@Component({
    selector: 'app-accellion-user-main',
    templateUrl: './accellion-user-main.component.html'
})

export class AccellionUserMainComponent {

}
