﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AccellionUserService, AlertService, Ng4LoadingSpinnerService } from '../../../services/service-barrel';
import { AccellionUser, AccellionUserProfiles, AccellionUserTypes, } from '../../../objects/objects-barrel';

@Component({
    selector: 'app-accellion-user-edit',
    templateUrl: './accellion-user-edit.component.html'
})

export class AccellionUserEditComponent implements OnInit {
    currentApp: string;
    currentAppDisplayName: string;
    selectedUser: AccellionUser = new AccellionUser();
    userProfiles: string[];
    userTypes: string[];
    formattedRegistrationDate: string;
    editUser = false;

    constructor(private activatedRoute: ActivatedRoute, private accellionUserService: AccellionUserService,
        private spinnerService: Ng4LoadingSpinnerService, private alertService: AlertService, private router: Router) { }

    ngOnInit() {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.currentAppDisplayName = this.activatedRoute.snapshot.data['appDisplayName'];
        let profiles = Object.keys(AccellionUserProfiles);
        this.userProfiles = profiles.slice(profiles.length / 2);
        let types = Object.keys(AccellionUserTypes);
        this.userTypes = types.slice(types.length / 2);

        this.activatedRoute.params
            .switchMap((params: Params) => this.accellionUserService.getUserDetails(params['userId']))
            .subscribe(user => {
                this.selectedUser = user;
                this.formattedRegistrationDate = new Date(this.selectedUser.registrationDate).toLocaleString('en-GB');
            });
    }

    onSubmit(form: NgForm) {
        if (form.invalid) {
            return;
        }

        this.updateUser();
    }
    parseProfile(value: string) {
        this.selectedUser.userProfile = value;
    }

    parseType(value: string) {
        this.selectedUser.userType = value;
    }

    enableEdit() {
        this.editUser = !this.editUser;
    }

    updateUser() {
        this.spinnerService.show();
        this.accellionUserService.updateUser(this.selectedUser).then(updateUserResponse => {
            if (updateUserResponse.ClassName === 'System.Exception' /* ?! */) {
                this.alertService.error(updateUserResponse.InnerException.InnerException.Message + ' ' + updateUserResponse.Message, false);
            } else {
                this.redirectToUsersListpage();
                this.alertService.success(updateUserResponse + ' was was successfully updated.');
            }
            this.spinnerService.hide();
        });
    }

    private redirectToUsersListpage() {
        this.router.navigate(['../../list'], { relativeTo: this.activatedRoute });
    }
}
