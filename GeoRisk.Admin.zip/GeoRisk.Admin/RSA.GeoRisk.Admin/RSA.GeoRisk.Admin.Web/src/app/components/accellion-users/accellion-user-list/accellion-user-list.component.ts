﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
    AccellionUserService, Ng4LoadingSpinnerService,
    AlertService, ExportToCsvService, AuthorizationService
} from '../../../services/service-barrel';
import { AccellionUser } from '../../../objects/accellion/accellionUser';
import * as $ from 'jquery';
import 'datatables.net';

@Component({
    selector: 'app-accellion-user-list',
    styleUrls: ['accellion-user-list.component.scss'],
    templateUrl: './accellion-user-list.component.html'
})

export class AccellionUserListComponent implements OnInit {
    currentApp: string;
    currentAppDisplayName: string;
    selectedAccellionUser: AccellionUser;
    accellionUsers: AccellionUser[];
    tableWidget: any;
    tableWidgetId: string;

    constructor(
        private accellionUserService: AccellionUserService,
        private activatedRoute: ActivatedRoute,
        private spinnerService: Ng4LoadingSpinnerService,
        private authorizationService: AuthorizationService,
        private alertService: AlertService, private route: ActivatedRoute,
        private router: Router,
        private exportToCsvService: ExportToCsvService) { }

    ngOnInit() {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.currentAppDisplayName = this.activatedRoute.snapshot.data['appDisplayName'];
        this.tableWidgetId = '#accellionUsers';
        this.getUsers();
    }

    getUsers() {
        this.spinnerService.show();
        this.accellionUserService.getUsers().then(users => {
            this.accellionUsers = users;
            for (let user of this.accellionUsers) {
                this.parseUserDetails(user);
            }
            this.initDatatable();
            this.spinnerService.hide();
        });
    }

    deleteUser() {
        const userId = $('#userNameToDelete').text();
        this.accellionUserService.deleteUser(userId).then(deleteResponse => {
            if (deleteResponse.ClassName === 'System.Exception') {
                this.alertService.error(deleteResponse.InnerException.InnerException.Message + ' ' + deleteResponse.Message, false);
            } else {
                this.alertService.success(deleteResponse + ' was successfully deleted.');
                this.getUsers();
            }
        });
    }

    editUser(userId: string): void {
        this.router.navigate(['../edit', userId], { relativeTo: this.route });
    }

    exportAllUsers() {
        this.exportToCsvService.downloadCsv(this.accellionUsers, 'Users_Kiteworks', true);
    }

    private initDatatable(): void {
        this.tableWidget = $(this.tableWidgetId).DataTable({
            select: true,
            destroy: true,
            data: this.accellionUsers,
            order: [[0, 'asc']],
            columns: [
                {
                    'className': 'btn-dataTable-details',
                    'data': 'userId',
                    'render': (data) => {
                        return this.authorizationService.isAuthorized([this.currentApp, 'editUser'])
                            ? '<button type="button" class="btn btn-link" title= "User details" >' + data + '</button>'
                            : '<span class="username-label">' + data + '</span>';
                    },
                },
                { 'data': 'fullName' },
                { 'data': 'email' },
                { 'data': 'approverEmail' },
                { 'data': 'userType' },
                { 'data': 'userProfile' },
                {
                    'className': 'btn-dataTable-remove',
                    'orderable': false,
                    'data': null,
                    'render': function () {
                        return '<span class="glyphicon glyphicon-trash" title= "Delete user"></span>';
                    },
                    'visible': this.authorizationService.isAuthorized([this.currentApp, 'deleteUser'])
                }
            ]
        });

        this.initDataTableEvents();
    }

    private initDataTableEvents(): void {
        let that = this;

        $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-remove', function () {
            let tr = $(this).closest('tr');
            let rowData = that.tableWidget.row(tr).data();
            const userName = rowData['userId'];
            // that.deleteUser(rowData['userId']);
            $('#userNameToDelete').text(userName);
            $('#deleteUserModal').modal('show');
        });

        if (that.authorizationService.isAuthorized([this.currentApp, 'editUser'])) {
            $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-details', function () {
                let tr = $(this).closest('tr');
                let rowData = that.tableWidget.row(tr).data();
                that.editUser(rowData['userId']);
            });
        }
    }

    private parseUserDetails(user: AccellionUser): void {
        if (Date.parse(user.registrationDate)) {
            let registrationDate = new Date(user.registrationDate);
            user.registrationDate = registrationDate.toLocaleString('en-GB');
        }
    }
}
