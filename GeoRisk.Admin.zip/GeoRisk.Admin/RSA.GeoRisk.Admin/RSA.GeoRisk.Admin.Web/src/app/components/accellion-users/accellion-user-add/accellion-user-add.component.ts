﻿import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {
    AdminService, AccellionUserService,
    AlertService, Ng4LoadingSpinnerService
} from '../../../services/service-barrel';
import {
    ActiveDirectoryUser, AccellionUserProfiles,
    AccellionUserTypes, AccellionUser
} from '../../../objects/objects-barrel';
import { AdminConstants } from '../../../constants';

@Component({
    selector: 'app-accellion-user-add',
    templateUrl: './accellion-user-add.component.html'
})

export class AccellionUserAddComponent implements OnInit {
    @Input() windowsLogin = '';
    newUser: AccellionUser;
    foundUserInAD: ActiveDirectoryUser;
    userAlreadyExistsInAdminDB = false;
    userProfiles: string[];
    userTypes: string[];
    displayHtmlFlag = false;
    CustomUser = false;
    currentApp: string;
    currentAppDisplayName: string;

    constructor(private adminService: AdminService,
        private activatedRoute: ActivatedRoute,
        private accellionUserService: AccellionUserService,
        private spinnerService: Ng4LoadingSpinnerService,
        private alertService: AlertService, private router: Router,
        private route: ActivatedRoute, ) { }

    ngOnInit() {
        this.foundUserInAD = new ActiveDirectoryUser();
        let profiles = Object.keys(AccellionUserProfiles);
        this.userProfiles = profiles.slice(profiles.length / 2);
        let types = Object.keys(AccellionUserTypes);
        this.userTypes = types.slice(types.length / 2);
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.currentAppDisplayName = this.activatedRoute.snapshot.data['appDisplayName'];
    }

    searchForUser(windowsLogin): void {
        this.userAlreadyExistsInAdminDB = false;
        let that = this;
        this.spinnerService.show();
        this.adminService.findUserInActiveDirectory(windowsLogin).then(response => {
            if (response.data == null) {
                this.spinnerService.hide();
                this.alertService.error(response.message, false);
                return;
            } else {
                that.foundUserInAD = new ActiveDirectoryUser(response.data);
                that.foundUserInAD.isValid = that.foundUserInAD.displayName !== 'not found' && that.foundUserInAD.displayName !== '';
                if (that.foundUserInAD.isValid) {
                    that.mapActiveDirectoryUserToAccellionUser();
                    that.accellionUserService.getUsers().then(users => {
                        let allUsers = users;
                        // allUsers.forEach((user) => {
                        //    if (user.userId === that.foundUserInAD.userName) {
                        //        that.userAlreadyExistsInAdminDB = true;
                        //        return;
                        //    }
                        // });
                        if (allUsers.some((x) => x.userId === that.foundUserInAD.userName) === true) {
                            that.userAlreadyExistsInAdminDB = true;
                            this.spinnerService.hide();
                            return;
                        }
                        this.displayHtmlFlag = true;
                        this.spinnerService.hide();
                    });
                } else {
                    this.spinnerService.hide();
                }
            }
        });
    }

    searchForUserOnEnter(event): void {
        if (event.keyCode === 13) {
            this.searchForUser(this.windowsLogin);
            event.preventDefault();
        }
    }

    userCanHaveMultipleRoles = (): boolean => this.currentApp === 'admin';

    parseProfile(value: string) {
        this.newUser.userProfile = value;
    }

    parseType(value: string) {
        this.newUser.userType = value;
    }

    onSubmit(form: NgForm) {
        if (form.invalid) {
            return;
        }

        this.createUser();
    }

    addCustomUser(e): void {
        if (e.target.checked) {
            this.windowsLogin = '';
            this.userAlreadyExistsInAdminDB = false;
            this.CustomUser = true;
            this.displayHtmlFlag = false;
            let that = this;
            this.spinnerService.show();
            let emptyUser = new Object({
                displayName: '',
                email: '',
                firstName: '',
                lastName: '',
                userName: ''
            });
            that.foundUserInAD = new ActiveDirectoryUser(emptyUser);
            that.foundUserInAD.isValid = true;
            that.mapActiveDirectoryUserToAccellionUser();
            this.adminService.getUsers(this.currentApp).then(users => {
                let allUsers = users;
                // allUsers.forEach((user) => {
                //    if (user.userName === that.foundUserInAD.userName) {
                //        that.userAlreadyExistsInAdminDB = true;
                //        return;
                //    }
                // });
                if (allUsers.some((x) => x.userName === that.foundUserInAD.userName) === true) {
                    that.userAlreadyExistsInAdminDB = true;
                    this.spinnerService.hide();
                    return;
                }
                this.displayHtmlFlag = true;
                this.spinnerService.hide();
            });
        } else {
            this.displayHtmlFlag = false;
        }
    }

    isValidEmail = (email: string) => AdminConstants.EMAIL_VALIDATION_REGEX.test(email);

    createUser() {
        this.spinnerService.show();
        if (this.CustomUser) {
            let FirstLastNames = this.foundUserInAD.displayName.split(' ');
            this.newUser.firstName = FirstLastNames[0];
            this.newUser.lastName = FirstLastNames[1];
        }
        this.accellionUserService.createUser(this.newUser)
            .then(response => {
                this.redirectToUsersListpage();
                this.alertService.success('User ' + response + ' was successfully created.');
                this.spinnerService.hide();
            })
            .catch(_ => {
                this.alertService.error('Unable to save user ' + this.newUser.userId);
                this.spinnerService.hide();
            });
    }

    private mapActiveDirectoryUserToAccellionUser() {
        this.newUser = new AccellionUser({
            userId: this.foundUserInAD.userName,
            firstName: this.foundUserInAD.firstName,
            lastName: this.foundUserInAD.lastName,
            email: this.foundUserInAD.email,
            approverEmail: this.foundUserInAD.approverEmail,
            userProfile: this.userProfiles[0],
            userType: this.userTypes[0],
        });
    }

    private redirectToUsersListpage() {
        this.router.navigate(['../list'], { relativeTo: this.route });
    }
}
