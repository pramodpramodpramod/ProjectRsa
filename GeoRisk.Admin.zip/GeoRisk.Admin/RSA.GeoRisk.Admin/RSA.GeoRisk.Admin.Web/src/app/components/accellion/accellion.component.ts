﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-accellion',
    templateUrl: './accellion.component.html'
})
export class AccellionComponent implements OnInit {
    constructor(private router: Router) { }

    ngOnInit() {
        this.router.navigate(['./accellion/users/list']);
    }
}
