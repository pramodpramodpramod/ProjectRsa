import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService, AdminService, AlertService, ExportToCsvService } from '../../../services/service-barrel';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../../objects/user/user';
import * as $ from 'jquery';
import 'datatables.net';

@Component({
    selector: 'app-administration-user-list',
    styleUrls: ['administration-user-list.component.scss'],
    templateUrl: './administration-user-list.component.html'
})
export class AdministrationUserListComponent implements OnInit {
    tableWidgetId: string;
    tableWidget: any;
    currentApp: string;
    users: User[];
    constructor(
        private activatedRoute: ActivatedRoute,
        private alertService: AlertService,
        private router: Router,
        private spinnerService: Ng4LoadingSpinnerService,
        private userService: AdminService,
        private exportToCsvService: ExportToCsvService ) {
            this.currentApp = this.activatedRoute.snapshot.data['appName'];
    }

    ngOnInit() {
        this.tableWidgetId = '#administrationUsers';
        this.getUsers();
    }

    getUsers() {
        this.spinnerService.show();
        this.userService.getUsers(this.currentApp).then(users => {
            this.users = users;
            for (let user of this.users) {
                this.parseUserDetails(user);
            }
            this.initDatatable();
            this.spinnerService.hide();
        });
    }

    deleteUser() {
        const userName = $('#userNameToDelete').text();
        this.userService.deleteUser(userName, this.currentApp).then(() => {
            this.alertService.success(`${userName} deleted from ${this.currentApp}.`);
            this.getUsers();
        });
    }

    editUser(userId: string) {
        this.router.navigate(['../edit', userId], { relativeTo: this.activatedRoute });
    }

    exportAllUsers() {
        let usersforExport = this.users.map(function (item) {
            delete item['applicationId'];
            delete item['roles'];
            delete item['userId'];
            delete item['loweredUserName'];
            delete item['fullNameSearch'];
            delete item['lastSuspendedDate'];
            delete item['lastActivityDate'];
            delete item['activatedBy'];
            delete item['activatedByDate'];
            return item;
        });
        this.exportToCsvService.downloadCsv(usersforExport, 'Administraion_Users', true);
    }

    exportLogs() {
        this.userService.getLogs().then(logs => {
            let modifiedList = logs.map(function (item) {
                item.date = new Date(item.date).toLocaleString('en-GB');
                return item;
            })
            this.exportToCsvService.downloadCsv(modifiedList, 'Logs');
        });
    }

    private initDatatable(): void {
        this.tableWidget = $(this.tableWidgetId).DataTable({
            select: true,
            destroy: true,
            data: this.users,
            order: [[0, 'asc']],
            columns: [
                {
                    'className': 'btn-dataTable-details',
                    'data': 'userName',
                    'render': function (data) {
                        return '<button type="button" class="btn btn-link" title= "User details" >' + data + '</button>';
                    },
                },
                { 'data': 'fullName' },
                { 'data': 'email' },
                { 'data': 'roleName' },
                {
                    'className': 'btn-dataTable-remove',
                    'orderable': false,
                    'data': null,
                    'render': function () {
                        return '<span class="glyphicon glyphicon-trash" title= "Delete user"></span>';
                    }
                }
            ]
        });

        this.initDataTableEvents();
    }

    private initDataTableEvents(): void {
        let that = this;

        $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-remove', function () {
            const tr = $(this).closest('tr');
            const rowData = that.tableWidget.row(tr).data();
            const userName = rowData['userName'];
            $('#userNameToDelete').text(userName);
            $('#deleteUserModal').modal('show');
        });

        $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-details', function () {
            let tr = $(this).closest('tr');
            let rowData = that.tableWidget.row(tr).data();
            that.editUser(rowData['userName']);
        });
    }

    private parseUserDetails(user: User): void {
        if (Date.parse(user.registrationDate)) {
            let registrationDate = new Date(user.registrationDate);
            user.registrationDate = registrationDate.toLocaleString('en-GB');
        }

        if (Date.parse(user.lastActivityDate)) {
            let lastActivityDate = new Date(user.lastActivityDate);
            user.lastActivityDate = lastActivityDate.toLocaleString('en-GB');
        }
        else {
            user.lastActivityDate = "";
        }

        if (Date.parse(user.lastSuspendedDate)) {
            let lastSuspendedDate = new Date(user.lastSuspendedDate);
            user.lastSuspendedDate = lastSuspendedDate.toLocaleString('en-GB');
        }
        else { user.lastSuspendedDate = ""; }
    }
}
