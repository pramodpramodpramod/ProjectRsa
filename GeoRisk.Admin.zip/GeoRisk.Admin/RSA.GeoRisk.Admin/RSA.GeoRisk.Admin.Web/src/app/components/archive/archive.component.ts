import { Component, OnInit } from '@angular/core';
import { AdminService, ExportToCsvService } from '../../services/service-barrel';
import { IArchivedUser } from '../../objects/archive/IArchivedUser';
import { ActivatedRoute } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import * as $ from 'jquery';
import 'datatables.net';


@Component({
    selector: 'app-archive',
    templateUrl: 'archive.component.html',
    styleUrls: ['./archive.component.scss']
})

export class ArchiveComponent implements OnInit {
    users: IArchivedUser[];
    currentApp: string;
    currentAppDisplayName: string;
    tableWidget: any;
    tableWidgetId = '#usersArchive';

    constructor(private adminService: AdminService,
        private activatedRoute: ActivatedRoute,
        private exportToCsvService: ExportToCsvService,
        private spinnerService: Ng4LoadingSpinnerService) {
    }

    ngOnInit(): void {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.currentAppDisplayName = this.activatedRoute.snapshot.data['appDisplayName'];
        this.getArchivedUsers();
    }

    exportUsers() {
        const filteredUsers = this.tableWidget.rows({ filter: 'applied' }).data()
            .map(x => {
                return {
                    userName: x.userName,
                    firstName: x.firstName,
                    lastName: x.lastName,
                    fullName: x.fullName,
                    email: x.email,
                    location: x.location,
                    archivedBy: x.archivedBy,
                    deletedDate: new Date(x.deletedDate).toLocaleString('en-GB'),
                 
                };
            });        
        this.exportToCsvService.downloadCsv(filteredUsers, `UsersArchive_${this.currentAppDisplayName}`, true);
    }

    private getArchivedUsers(): void {
        this.spinnerService.show();
        this.adminService.getArchivedUsers(this.currentApp).then(users => {
            this.users = users;
            this.initDatatable();
            this.spinnerService.hide();
        });
    }

    private initDatatable(): void {
        this.tableWidget = $(this.tableWidgetId).DataTable({
            select: true,
            destroy: true,
            autoWidth: false,
            data: this.users,
            'order': [[5, 'desc']],
            columns: [
                {
                    'data': 'userName',
                },
                {
                    'data': 'fullName',
                },
                {
                    'data': 'email',
                },
                {
                    'data': 'location',
                },
                {
                    'data': 'archivedBy',
                },                
                {
                    'data': 'deletedDate',

                    'render': function (data, type) {
                        return type === 'sort' ? data : new Date(data).toLocaleString('en-GB');
                    }
                }
            ]
        });
    }
}
