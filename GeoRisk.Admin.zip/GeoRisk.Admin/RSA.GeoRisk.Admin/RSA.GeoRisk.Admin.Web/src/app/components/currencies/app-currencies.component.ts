import { Component, OnInit } from '@angular/core';
import { GeoriskAppsCurrenciesService, AlertService } from '../../services/service-barrel';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-currencies',
    templateUrl: './app-currencies.component.html'
})

export class AppCurrenciesComponent implements OnInit {

    currencies: any[];
    appCurrencies: any[];

    currenciesSelect: any[];
    allCurrenciesSelect: any[];

    originalAppCurrencies: any[] = [];

    currentApp: string;

    editsMade = false;

    constructor(private georiskAppsCurrenciesService: GeoriskAppsCurrenciesService, private activatedRoute: ActivatedRoute,
        private alertService: AlertService) { }

    ngOnInit(): void {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];

        this.georiskAppsCurrenciesService.getAppCurrencies(this.currentApp)
            .then((res) => {
                this.appCurrencies = res;
                Object.assign(this.originalAppCurrencies, this.appCurrencies);
            });
        this.georiskAppsCurrenciesService.getCurrencies()
            .then(res => this.currencies = res);
    }

    cancelEdits() {

    }

    saveEdits() {

        let currencyToRemove = this.originalAppCurrencies.filter(obj => {
            return this.appCurrencies.findIndex(y => y.code === obj.code) === -1;
        });

        let currencyToAdd = this.appCurrencies.filter(obj => {
            return this.originalAppCurrencies.findIndex(y => y.code === obj.code) === -1;
        });

        if (currencyToAdd.length > 0) {
            currencyToAdd.forEach(element => {
                this.georiskAppsCurrenciesService.addCurrency(this.currentApp, element)
                .then(() => this.alertService.success(element.value + ' currency added to ' + this.currentApp, false))
                .catch((error) => this.alertService.error(error.Message, false));
            });
        }

        if (currencyToRemove.length > 0) {
            this.georiskAppsCurrenciesService.removeCurrency(this.currentApp, currencyToRemove.map(o => o.code).join(','))
                .then(() => this.alertService.success(
                    currencyToRemove.map(o => o.value).join(', ') + ' removed from ' + this.currentApp, false))
                .catch((error) => this.alertService.error(error.Message, false));
        }
        // reset the user's roles
        this.originalAppCurrencies = [];
        Object.assign(this.originalAppCurrencies, this.appCurrencies);
    }

    shiftRoles(source: any, target: any, currencies: any) {

        if (currencies && currencies.length > 0) {
            for (let currency of currencies) {
                this.setSelected(source, currency);
                this.moveElements(source, target, this.selectionMoveCheck);
            }

            this.allCurrenciesSelect = [];
            this.currenciesSelect = [];
        }

    }

    selectionMoveCheck(element) {
        if (element.selected) {
            element.selected = false;
            return true;
        }
    }

    setSelected(allCurrencies, currency) {
        let ind = allCurrencies.findIndex(x => x.code === currency.code);
        if (ind > -1) {
            allCurrencies[ind].selected = true;
        }
    }

    moveElements(source, target, moveCheck) {
        for (let i = 0; i < source.length; i++) {
            let element = source[i];
            if (moveCheck(element)) {
                this.editsMade = true;
                source.splice(i, 1);
                target.push(element);
                i--;
            }
        }
    }

}
