import { Component, OnInit } from '@angular/core';
import { IBatch } from '../../../objects/reporting/IBatch';
import { AlertService, Ng4LoadingSpinnerService, AdminService, ReportingService } from '../../../services/service-barrel';
import { Router, ActivatedRoute } from '@angular/router';
import { IBusinessArea } from '../../../objects/reporting/IBusinessArea';

@Component({
    selector: 'app-batch-add',
    templateUrl: 'batch-add.component.html'
})

export class BatchAddComponent implements OnInit {
    newBatch: IBatch;
    selectedBusinessArea: any;
    businessAreas: IBusinessArea[];
    currentApp: string;
    gdpr: boolean;

    constructor(
        private adminService: AdminService,
        private reportingService: ReportingService,
        private alertService: AlertService,
        private spinnerService: Ng4LoadingSpinnerService,
        private router: Router,
        private route: ActivatedRoute) { }

    ngOnInit() {
        this.newBatch = new IBatch();
        this.currentApp = this.route.snapshot.data['appName'];

        if (this.currentApp === 'gdpr') {
            this.gdpr = true;
        } else {
            this.getBusinessAreas();
        }
    }

    getBusinessAreas() {
        this.spinnerService.show();
        this.reportingService.getBusinessAreas().toPromise()
            .then(resp => {
                this.businessAreas = resp;
                this.spinnerService.hide();
            })
            .catch(err => {
                this.spinnerService.hide();
                this.alertService.error(err.error.message);
            });
    }

    createBatch() {
        if (this.currentApp !== 'gdpr') {
            this.newBatch.businessAreaId = this.selectedBusinessArea.id;
        }
        this.adminService.addBatch(this.newBatch, this.currentApp).toPromise()
            .then(resp => {
                this.redirectToBatchList();
                if (this.currentApp !== 'gdpr') {
                    this.alertService.success(`Added new batch ${resp} to business area ${this.selectedBusinessArea.displayName}`, false);
                }
                else {
                    this.alertService.success(`Added new batch ${resp} to GDPR Compliance`, false);

                }
            })
            .catch(err => {
                this.alertService.error(err.error.message);
            });
    }

    private redirectToBatchList() {
        this.router.navigate(['../list'], { relativeTo: this.route });
    }
}
