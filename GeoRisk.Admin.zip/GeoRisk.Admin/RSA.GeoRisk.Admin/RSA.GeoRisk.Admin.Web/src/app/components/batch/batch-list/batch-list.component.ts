import { Component, OnInit } from '@angular/core';
import { AlertService, AdminService, AuthorizationService } from '../../../services/service-barrel';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import * as $ from 'jquery';
import 'datatables.net';
import { IBatch } from '../../../objects/reporting/IBatch';
import { IBatchResponse } from '../../../objects/reporting/IBatchResponse';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-batch-list',
    styleUrls: ['batch-list.component.scss'],
    templateUrl: 'batch-list.component.html'
})

export class BatchListComponent implements OnInit {
    batches: IBatch[];

    tableWidget: any;
    tableWidgetId = '#batches';
    currentApp: string;
    currentAppDisplayName: string;
    flexibleGridWidthClass: string;
    canAddBatch: boolean;

    constructor(private adminService: AdminService,
        private alertService: AlertService,
        private activatedRoute: ActivatedRoute,
        private authorizationService: AuthorizationService,
        private spinnerService: Ng4LoadingSpinnerService) { }

    ngOnInit() {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.currentAppDisplayName = this.activatedRoute.snapshot.data['appDisplayName'];
        this.canAddBatch = this.authorizationService.isAuthorized([this.currentApp, 'deleteGdpr']);
        this.flexibleGridWidthClass = this.currentApp === 'gdpr' ? '50%' : '100%';
        this.batches = [];
        this.getBatches();
    }

    getBatches() {
        this.spinnerService.show();
        this.adminService.getBatches(this.currentApp).toPromise()
            .then(resp => {
                this.batches = resp.map(this.mapBatch);
                this.initDatatable();
                this.spinnerService.hide();
            })
            .catch(err => {
                this.spinnerService.hide();
                this.alertService.error(err);
            });
    }

    private mapBatch(batch: IBatchResponse): IBatch {
        return {
            id: batch.id,
            batchId: batch.batchId,
            description: batch.description !== undefined ? batch.description : null,
            businessAreaId: batch.businessAreaId !== undefined ? batch.businessAreaId : null,
            businessAreaDescription: batch.businessArea !== null && batch.businessArea !== undefined ? batch.businessArea.name : null
        };

    };

    deleteBatch() {
        const batchToDelete = $('#batchToDelete').text();
        let batchId = $('#id').val();
        this.adminService.deleteBatch(batchId, this.currentApp).toPromise().
            then(() => {
                this.alertService.success('Batch ' + batchToDelete + ' was successfully deleted');
                this.getBatches();
            })
            .catch(err => {
                this.alertService.error(err.error.exceptionMessage);
            });
    }

    private initDatatable(): void {
        this.unbindDataTable();
        let visibleColumn = this.currentApp !== 'gdpr' ? true : false;
        this.tableWidget = $(this.tableWidgetId).DataTable({
            select: true,
            order: [[1, 'asc']],
            destroy: true,
            data: this.batches,
            columns: [
                {
                    'data': 'id',
                    'visible': false
                },
                { 'data': 'batchId' },
                { 'data': 'description', 'visible': visibleColumn },
                { 'data': 'businessAreaDescription', 'visible': visibleColumn },
                {
                    'className': 'btn-dataTable-remove',
                    'orderable': false,
                    'data': null,
                    'render': function () {
                        return '<span class="glyphicon glyphicon-trash" title= "Delete batch"></span>';
                    },
                    'visible': this.authorizationService.isAuthorized([this.currentApp, 'deletebatch'])
                }
            ]
        });

        this.initDataTableEvents();
    }

    private initDataTableEvents(): void {
        let that = this;

        $(this.tableWidgetId + ' tbody').on('click', 'td.btn-dataTable-remove', function () {
            let tr = $(this).closest('tr');
            let rowData = that.tableWidget.row(tr).data();
            $('#id').val(rowData['id']);
            $('#batchToDelete').text(rowData['batchId']);
            $('#deleteBatchModal').modal('show');
        });
    }

    private unbindDataTable(): void {
        const dataTable = $(this.tableWidgetId + ' tbody');
        dataTable.off('click', 'td.btn-dataTable-remove');
    }
}
