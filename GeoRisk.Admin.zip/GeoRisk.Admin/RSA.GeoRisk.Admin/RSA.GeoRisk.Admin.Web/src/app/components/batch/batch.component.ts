import { Component } from '@angular/core';

@Component({
    selector: 'app-batch',
    templateUrl: 'batch.component.html'
})

export class BatchComponent { }
