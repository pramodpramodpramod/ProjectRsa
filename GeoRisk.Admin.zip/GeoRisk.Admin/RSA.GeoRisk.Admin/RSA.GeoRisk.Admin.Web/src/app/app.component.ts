import { Component } from '@angular/core';
import '../style/app.scss';
import { AuthenticationService } from './services/service-barrel';

@Component({
    selector: 'app-admin',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent {
    constructor(private authenticationService: AuthenticationService) { }

    isAuthenticated(): boolean {
        const user = this.authenticationService.getUser();
        return user != null && user.username && user.roles.length > 0;
    }
}
