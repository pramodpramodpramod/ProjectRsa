﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using AutoMapper;
using RSA.GeoRisk.Admin.Web.App_Start;
using RSA.GeoRisk.Admin.Web.Mapping;
using Hangfire;

using GlobalConfiguration = System.Web.Http.GlobalConfiguration;
using System.Diagnostics;
using RSA.GeoRisk.Admin.Web.Services;
using Hangfire.SqlServer;
using System.Configuration;

namespace RSA.GeoRisk.Admin.Web
{
    public class MvcApplication : HttpApplication
    {

        private IEnumerable<IDisposable> GetHangfireServers()
        {
            Hangfire.GlobalConfiguration.Configuration
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                .UseSimpleAssemblyNameTypeSerializer()
                .UseLogProvider(new NoLoggingProvider())
                .UseRecommendedSerializerSettings().UseSqlServerStorage(ConfigurationManager.AppSettings["HangfireConnection"], new SqlServerStorageOptions
                {
                    CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                    SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                    QueuePollInterval = TimeSpan.Zero,
                    UseRecommendedIsolationLevel = true,
                    UsePageLocksOnDequeue = true,
                    DisableGlobalLocks = true
                });

            yield return new BackgroundJobServer();
        }
        protected void Application_Start()
        {
            var scheduleService = new ScheduleService();
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            Mapper.Initialize(cfg => cfg.AddProfile(new MappingProfile()));

            GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            GlobalConfiguration.Configuration.Formatters.Remove(GlobalConfiguration.Configuration.Formatters.XmlFormatter);
            StaticCache.LoadStaticCache(Application);
            HangfireAspNet.Use(GetHangfireServers);
            if (ConfigurationManager.AppSettings["AutomatedUserCleanUpCronExpression"] != null)
            {
                RecurringJob.AddOrUpdate(() => scheduleService.AutomatedUserCleanUp(), ConfigurationManager.AppSettings["AutomatedUserCleanUpCronExpression"]);
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "http://localhost:8088");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Accept");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Credentials", "true");
                HttpContext.Current.Response.AddHeader("Access-Control-Max-Age", "1728000");
                HttpContext.Current.Response.End();
            }
        }
    }
}
