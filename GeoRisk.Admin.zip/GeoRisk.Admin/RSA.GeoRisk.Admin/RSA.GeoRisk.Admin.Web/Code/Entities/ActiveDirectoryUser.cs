﻿namespace RSA.GeoRisk.Admin.Web.Code.Entities
{
    public class ActiveDirectoryUser
    {
        public string displayName { get; set; }
        public string email { get; set; }
        public string userName { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
    }
}