﻿using System;

namespace RSA.GeoRisk.Admin.Web.Code.Entities
{
    public class User
    {
        public string userName { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string approverEmail { get; set; }
        public string roleName { get; set; }
    }
}