﻿using log4net;
using RSA.GeoRisk.Admin.Web.App_Start;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Core.Objects.DataClasses;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Web;
using System.Web.DynamicData;

namespace RSA.GeoRisk.Admin.Web.Persistence
{
    public abstract class DbContextWrapper : DbContext
    {
        private readonly ILog _logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private string _connStringName;

        protected DbContextWrapper(string connStringName)
        {
            this._connStringName = connStringName;
        }

        public void LogExportToDatabase(string exportFileName)
        {
            LogicalThreadContext.Properties["User"] = HttpContext.Current.User.Identity.Name;
            _logger.Debug(string.Format("Exported - {0}", exportFileName));
        }

        public override int SaveChanges()
        {
            try
            {
                var loggingProperties = StaticCache.ReadStaticCache();
                List<string> properties = new List<string>();
                Dictionary<string, string> relationshipProperties = new Dictionary<string, string>();

                LogicalThreadContext.Properties["User"] = HttpContext.Current.User.Identity.Name;
                string loggerInfo = "";

                var modifiedEntries = ChangeTracker.Entries()
                    .Where(e => e.State == EntityState.Added || e.State == EntityState.Deleted ||
                                e.State == EntityState.Modified).ToList();

                if (modifiedEntries.Any())
                {
                    foreach (var change in modifiedEntries)
                    {
                        var entityName = change.Entity.GetType().GetTypeInfo().BaseType.Equals(typeof(Object)) ? change.Entity.GetType().GetTypeInfo().Name : change.Entity.GetType().GetTypeInfo().BaseType.Name;

                        if (loggingProperties.ContainsKey(entityName))
                        {
                            loggingProperties.TryGetValue(entityName, out properties);
                        }

                        foreach (var prop in properties)
                        {
                            if (prop.StartsWith("Relationship"))
                            {
                                var pathStrings = prop.Split(':');
                                relationshipProperties.Add(pathStrings[1], pathStrings[2]);
                            }
                        }

                        if (entityName == "AuditUser")
                        {
                            loggerInfo += "User has been deleted | ";
                        }
                        else
                        {
                            loggerInfo += string.Format("{0} | {1} |", entityName, change.State.ToString().ToUpper());
                        }

                        if (change.State == EntityState.Added || change.State == EntityState.Deleted)
                        {
                            var addVsDeleted = change.State == EntityState.Added ? change.CurrentValues : change.OriginalValues;

                            foreach (var prop in addVsDeleted.PropertyNames)
                            {
                                if (properties.Contains(prop))
                                {
                                    var value = addVsDeleted[prop] == null ? "" : addVsDeleted[prop];
                                    loggerInfo += string.Format(" {0}: {1} | ", prop, value.ToString());
                                }
                            }
                        }
                        else
                        {
                            foreach (var prop in change.OriginalValues.PropertyNames)
                            {
                                if (properties.Contains(prop))
                                {
                                    var currentValue = change.CurrentValues[prop] != null ? change.CurrentValues[prop].ToString() : "NULL";
                                    loggerInfo += string.Format(" {0}: {1} | ", prop, currentValue);
                                }
                            }
                        }
                        if (relationshipProperties.Any())
                        {
                            var oc = ((IObjectContextAdapter)this).ObjectContext;
                            ObjectStateEntry obecjtEntityState = oc.ObjectStateManager.GetObjectStateEntry(change.Entity);

                            foreach (var relationship in relationshipProperties)
                            {
                                var relatedEnd = obecjtEntityState.RelationshipManager.GetAllRelatedEnds().First(re => re.TargetRoleName == relationship.Key);
                                if (change.State != EntityState.Deleted)
                                {
                                    relatedEnd.Load();

                                    if (relatedEnd.IsLoaded)
                                    {
                                        var valueOfRelationEnd = relatedEnd.GetType().GetProperty("Value").GetValue(relatedEnd);
                                        var dynamicProperyValue = valueOfRelationEnd.GetType().GetProperty(relationship.Value).GetValue(valueOfRelationEnd);

                                        loggerInfo += string.Format(" {0}: {1} | ", relationship.Key, dynamicProperyValue);
                                    }
                                }
                            }
                        }
                        _logger.Debug(loggerInfo);
                        loggerInfo = "";
                    }
                }

                var objectContext = ((IObjectContextAdapter)this).ObjectContext;

                var relationships = objectContext
                    .ObjectStateManager.GetObjectStateEntries(EntityState.Added | EntityState.Deleted)
                    .Where(e => e.IsRelationship)
                    .ToList();

                if (relationships.Any())
                {
                    var entityName = relationships.First().EntitySet.Name;

                    foreach (var relationship in relationships)
                    {
                        if (relationship.EntitySet != null && entityName == "GroupLicenceService")
                        {
                            _logger.Debug(GroupLicenceServiceLogger(objectContext, relationship));
                        }
                        else if (relationship.EntitySet != null && entityName == "aspnet_UsersInRoles")
                        {
                            _logger.Debug(aspnet_UsersInRolesLogger(objectContext, relationship));
                        }
                        else if (relationship.EntitySet != null && entityName == "GroupLicenceUser")
                        {
                            _logger.Debug(GroupLicenceUserLogger(objectContext, relationship));
                        }
                    }
                }
                return base.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return base.SaveChanges();
            }
        }

        public override Task<int> SaveChangesAsync()
        {
            try
            {
                var loggingProperties = StaticCache.ReadStaticCache();
                List<string> properties = new List<string>();
                Dictionary<string, string> relationshipProperties = new Dictionary<string, string>();

                LogicalThreadContext.Properties["User"] = HttpContext.Current.User.Identity.Name;
                string loggerInfo = "";

                var modifiedEntries = ChangeTracker.Entries()
                    .Where(e => e.State == EntityState.Added || e.State == EntityState.Deleted ||
                                e.State == EntityState.Modified).ToList();

                if (modifiedEntries.Any())
                {
                    foreach (var change in modifiedEntries)
                    {
                        var entityName = change.Entity.GetType().GetTypeInfo().BaseType.Equals(typeof(Object)) ? change.Entity.GetType().GetTypeInfo().Name : change.Entity.GetType().GetTypeInfo().BaseType.Name;

                        if (loggingProperties.ContainsKey(entityName))
                        {
                            loggingProperties.TryGetValue(entityName, out properties);
                        }

                        foreach (var prop in properties)
                        {
                            if (prop.StartsWith("Relationship"))
                            {
                                var pathStrings = prop.Split(':');
                                relationshipProperties.Add(pathStrings[1], pathStrings[2]);
                            }
                        }

                        if (entityName == "AuditUser")
                        {
                            loggerInfo += "User has been deleted | ";
                        }
                        else
                        {
                            loggerInfo += string.Format("{0} | {1} |", entityName, change.State.ToString().ToUpper());
                        }

                        if (change.State == EntityState.Added || change.State == EntityState.Deleted)
                        {
                            var addVsDeleted = change.State == EntityState.Added ? change.CurrentValues : change.OriginalValues;

                            foreach (var prop in addVsDeleted.PropertyNames)
                            {
                                if (properties.Contains(prop))
                                {
                                    var value = addVsDeleted[prop] == null ? "" : addVsDeleted[prop];
                                    loggerInfo += string.Format(" {0}: {1} | ", prop, value.ToString());
                                }
                            }
                        }
                        else
                        {
                            foreach (var prop in change.OriginalValues.PropertyNames)
                            {
                                if (properties.Contains(prop))
                                {
                                    var currentValue = change.CurrentValues[prop] != null ? change.CurrentValues[prop].ToString() : "NULL";
                                    loggerInfo += string.Format(" {0}: {1} | ", prop, currentValue);
                                }
                            }
                        }
                        if (relationshipProperties.Any())
                        {
                            var oc = ((IObjectContextAdapter)this).ObjectContext;
                            ObjectStateEntry obecjtEntityState = oc.ObjectStateManager.GetObjectStateEntry(change.Entity);

                            foreach (var relationship in relationshipProperties)
                            {
                                var relatedEnd = obecjtEntityState.RelationshipManager.GetAllRelatedEnds().First(re => re.TargetRoleName == relationship.Key);
                                if (change.State != EntityState.Deleted)
                                {
                                    relatedEnd.Load();

                                    if (relatedEnd.IsLoaded)
                                    {
                                        var valueOfRelationEnd = relatedEnd.GetType().GetProperty("Value").GetValue(relatedEnd);
                                        var dynamicProperyValue = valueOfRelationEnd.GetType().GetProperty(relationship.Value).GetValue(valueOfRelationEnd);

                                        loggerInfo += string.Format(" {0}: {1} | ", relationship.Key, dynamicProperyValue);
                                    }
                                }
                            }
                        }
                        _logger.Debug(loggerInfo);
                        loggerInfo = "";
                    }
                }

                var objectContext = ((IObjectContextAdapter)this).ObjectContext;

                var relationships = objectContext
                    .ObjectStateManager.GetObjectStateEntries(EntityState.Added | EntityState.Deleted)
                    .Where(e => e.IsRelationship)
                    .ToList();

                if (relationships.Any())
                {
                    var entityName = relationships.First().EntitySet.Name;

                    foreach (var relationship in relationships)
                    {
                        if (relationship.EntitySet != null && entityName == "GroupLicenceService")
                        {
                            _logger.Debug(GroupLicenceServiceLogger(objectContext, relationship));
                        }
                        else if (relationship.EntitySet != null && entityName == "aspnet_UsersInRoles")
                        {
                            _logger.Debug(aspnet_UsersInRolesLogger(objectContext, relationship));
                        }
                        else if (relationship.EntitySet != null && entityName == "GroupLicenceUser")
                        {
                            _logger.Debug(GroupLicenceUserLogger(objectContext, relationship));
                        }
                    }
                }
                return base.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return base.SaveChangesAsync();
            }
        }

        private string GroupLicenceServiceLogger(ObjectContext objectContext, ObjectStateEntry relationship)
        {
            var currentEntity = objectContext.GetObjectByKey(relationship.State == EntityState.Added ? (EntityKey)relationship.CurrentValues[0] : (EntityKey)relationship.OriginalValues[0]);
            var navigation = objectContext.GetObjectByKey(relationship.State == EntityState.Added ? (EntityKey)relationship.CurrentValues[1] : (EntityKey)relationship.OriginalValues[1]);

            var relationshipState = relationship.State.ToString().ToUpper();
            var serviceName = navigation.GetType().GetProperty("Name").GetValue(navigation);
            var fromTO = relationship.State == EntityState.Added ? "to" : "from";
            var groupLicenceName = currentEntity.GetType().GetProperty("Name").GetValue(currentEntity);

            return string.Format("{0} | Service: {1} {2} Group Licence: {3}", relationshipState, serviceName, fromTO, groupLicenceName);
        }

        private string GroupLicenceUserLogger(ObjectContext objectContext, ObjectStateEntry relationship)
        {
            var currentEntity = objectContext.GetObjectByKey(relationship.State == EntityState.Added ? (EntityKey)relationship.CurrentValues[0] : (EntityKey)relationship.OriginalValues[0]);
            var navigation = objectContext.GetObjectByKey(relationship.State == EntityState.Added ? (EntityKey)relationship.CurrentValues[1] : (EntityKey)relationship.OriginalValues[1]);

            var relationshipState = relationship.State.ToString().ToUpper();
            var userName = navigation.GetType().GetProperty("UserName").GetValue(navigation);
            var fromTO = relationship.State == EntityState.Added ? "to" : "from";
            var groupLicenceName = currentEntity.GetType().GetProperty("Name").GetValue(currentEntity);

            return string.Format("{0} | User: {1} {2} Group Licence: {3}", relationshipState, userName, fromTO, groupLicenceName);
        }

        private string aspnet_UsersInRolesLogger(ObjectContext objectContext, ObjectStateEntry relationship)
        {
            var currentEntity = objectContext.GetObjectByKey(relationship.State == EntityState.Added ? (EntityKey)relationship.CurrentValues[0] : (EntityKey)relationship.OriginalValues[0]);
            var navigation = objectContext.GetObjectByKey(relationship.State == EntityState.Added ? (EntityKey)relationship.CurrentValues[1] : (EntityKey)relationship.OriginalValues[1]);

            var relationshipState = relationship.State.ToString().ToUpper();
            var roleName = currentEntity.GetType().GetProperty("RoleName").GetValue(currentEntity);
            var fromTO = relationship.State == EntityState.Added ? "to" : "from";
            var userName = navigation.GetType().GetProperty("UserName").GetValue(navigation);
            var applicationName = navigation.GetType().GetProperty("ApplicationName").GetValue(navigation);

            return string.Format("{0} | Role: {1} {2} User: {3} | Application: {4}", relationshipState, roleName, fromTO, userName, applicationName);
        }
    }
}