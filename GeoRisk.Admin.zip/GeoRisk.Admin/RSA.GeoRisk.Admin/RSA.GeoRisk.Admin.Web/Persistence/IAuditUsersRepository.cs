﻿using System.Collections.Generic;
using RSA.GeoRisk.Admin.Web.DTOs;

namespace RSA.GeoRisk.Admin.Web.Persistence
{
    public interface IAuditUsersRepository
    {
        void Add(AuditUserDto auditUser);
        IList<AuditUserDto> GetAll(string application);
    }
}
