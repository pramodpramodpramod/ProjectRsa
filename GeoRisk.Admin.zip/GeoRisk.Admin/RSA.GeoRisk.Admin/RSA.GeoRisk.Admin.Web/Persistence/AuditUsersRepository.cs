﻿using System.Collections.Generic;
using System.Linq;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Persistence
{
    public class AuditUsersRepository : IAuditUsersRepository
    {
        private readonly adminEntities _dbContext;
        public AuditUsersRepository(adminEntities dbContext)
        {
            _dbContext = dbContext;
        }

        public void Add(AuditUserDto auditUser)
        {
            var auditUserToAdd = new AuditUser
            {
                Application = auditUser.Application,
                DeletedDate = auditUser.DeletedDate,
                Email = auditUser.Email,
                FirstName = auditUser.FirstName,
                LastName = auditUser.LastName,
                Location = auditUser.Location,
                UserName = auditUser.UserName,
                ArchivedBy = auditUser.ArchivedBy
            };

            _dbContext.AuditUsers.Add(auditUserToAdd);
            _dbContext.SaveChanges();
        }

        public IList<AuditUserDto> GetAll(string application)
        {
            return _dbContext.AuditUsers
                .Where(u => u.Application == application)
                .Select(u => new AuditUserDto
                {
                    Application = u.Application,
                    DeletedDate = u.DeletedDate,
                    Email = u.Email,
                    FirstName = u.FirstName,
                    LastName = u.LastName,
                    Location = u.Location,
                    UserName = u.UserName,
                    ArchivedBy= u.ArchivedBy
                }).ToList();
        }
    }
}