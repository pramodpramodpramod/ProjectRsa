﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mime;
using System.Web;

namespace RSA.GeoRisk.Admin.Web.App_Start
{
    public static class StaticCache
    {
        private static HttpApplicationState _state;

        public static void LoadStaticCache(HttpApplicationState state)
        {
            string activeDirectoryConfig = AppDomain.CurrentDomain.GetData("DataDirectory").ToString() + "\\" + "loggingProperties.json";

            using (StreamReader r = new StreamReader(activeDirectoryConfig))
            {
                string json = r.ReadToEnd();
                Dictionary<string, List<string>> data = JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(json);

                state["loggingProperties"] = data;
                _state = state;
            }
        }


        public static Dictionary<string, List<string>> ReadStaticCache()
        {
            return _state["loggingProperties"] as Dictionary<string, List<string>>;
        }
    }
}