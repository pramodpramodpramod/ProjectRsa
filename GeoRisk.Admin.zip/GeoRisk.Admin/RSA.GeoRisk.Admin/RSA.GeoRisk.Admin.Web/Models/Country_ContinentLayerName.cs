namespace RSA.GeoRisk.Admin.Web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Country_ContinentLayerName
    {
        public int Id { get; set; }

        [Required]
        [StringLength(3)]
        public string CountryCode { get; set; }

        [Required]
        [StringLength(30)]
        public string ArcGisServiceLayerName { get; set; }
    }
}
