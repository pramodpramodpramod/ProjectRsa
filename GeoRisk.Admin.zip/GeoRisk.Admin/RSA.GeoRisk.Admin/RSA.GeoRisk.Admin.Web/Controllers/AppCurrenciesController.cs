﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class AppCurrenciesController : ApiController
    {
        private geoRiskAppsEntities db = new geoRiskAppsEntities();

        #region app currencies
        // GET: api/AppCurrencies
        [Route("api/app-currency/{appname}")]
        public IQueryable<Lookup_Currency> GetAppCurrencies(string appname)
        {
            App app = db.Apps.Where(x => x.Name == appname).FirstOrDefault();
            IQueryable<AppCurrency> appCurrencies = db.AppCurrencies.Where(y => y.AppId == app.AppId);


            IQueryable<Lookup_Currency> b = appCurrencies.Select(x => x.Lookup_Currency);

            return b;
        }

        // GET: api/AppCurrencies/5
        [ResponseType(typeof(AppCurrency))]
        public async Task<IHttpActionResult> GetAppCurrency(int id)
        {
            AppCurrency appCurrency = await db.AppCurrencies.FindAsync(id);
            if (appCurrency == null)
            {
                return NotFound();
            }

            return Ok(appCurrency);
        }

        // PUT: api/AppCurrencies/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutAppCurrency(int id, AppCurrency appCurrency)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != appCurrency.Id)
            {
                return BadRequest();
            }

            db.Entry(appCurrency).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AppCurrencyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        //POST: api/app-currency/{appname}/add
        [Route("api/app-currency/{appname}/add", Name = "NewAppCurrencyRoute")]
        [ResponseType(typeof(AppCurrency))]
        public async Task<IHttpActionResult> PostAppCurrency(string appname, Lookup_Currency lookup_currency)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                AppCurrency appCurrency = new AppCurrency();
                appCurrency.CurrencyCode = lookup_currency.Code;
                appCurrency.AppId = db.Apps.Where(x => x.Name == appname).FirstOrDefault().AppId;

                db.AppCurrencies.Add(appCurrency);
                await db.SaveChangesAsync();

                return CreatedAtRoute("NewAppCurrencyRoute", new { id = appCurrency.Id }, appCurrency);
            }
            catch (Exception e)
            {

                return Ok(new Exception("Unable to add the currency ", e));
            }

        }

        // DELETE: api/AppCurrencies/5
        [ResponseType(typeof(AppCurrency))]
        [Route("api/app-currency/{appname}/delete")]
        public async Task<IHttpActionResult> DeleteAppCurrency(string appname, string appcurrencycodes)
        {
            List<string> currs = appcurrencycodes.Split(',').ToList();

            foreach (string curr in currs)
            {
                AppCurrency appCurrency = db.AppCurrencies.Where(y => y.CurrencyCode == curr && y.App.Name == appname).FirstOrDefault();
                if (appCurrency == null)
                {
                    return NotFound();
                }
                db.AppCurrencies.Remove(appCurrency);
                await db.SaveChangesAsync();
            }

            return Ok(appcurrencycodes);
        }

        private bool AppCurrencyExists(int id)
        {
            return db.AppCurrencies.Count(e => e.Id == id) > 0;
        }
        #endregion

        #region lookup currency
        // GET: api/lookup-currency
        [Route("api/lookup-currency")]
        public IQueryable<Lookup_Currency> GetLookup_Currency()
        {
            return db.Lookup_Currency;
        }

        // GET: api/Lookup_Currency/5
        [ResponseType(typeof(Lookup_Currency))]
        public async Task<IHttpActionResult> GetLookup_Currency(string id)
        {
            Lookup_Currency lookup_Currency = await db.Lookup_Currency.FindAsync(id);
            if (lookup_Currency == null)
            {
                return NotFound();
            }

            return Ok(lookup_Currency);
        }

        // PUT: api/Lookup_Currency/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutLookup_Currency(string id, Lookup_Currency lookup_Currency)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != lookup_Currency.Code)
            {
                return BadRequest();
            }

            db.Entry(lookup_Currency).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Lookup_CurrencyExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Lookup_Currency
        [ResponseType(typeof(Lookup_Currency))]
        public async Task<IHttpActionResult> PostLookup_Currency(Lookup_Currency lookup_Currency)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Lookup_Currency.Add(lookup_Currency);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (Lookup_CurrencyExists(lookup_Currency.Code))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = lookup_Currency.Code }, lookup_Currency);
        }

        // DELETE: api/Lookup_Currency/5
        [ResponseType(typeof(Lookup_Currency))]
        public async Task<IHttpActionResult> DeleteLookup_Currency(string id)
        {
            Lookup_Currency lookup_Currency = await db.Lookup_Currency.FindAsync(id);
            if (lookup_Currency == null)
            {
                return NotFound();
            }

            db.Lookup_Currency.Remove(lookup_Currency);
            await db.SaveChangesAsync();

            return Ok(lookup_Currency);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Lookup_CurrencyExists(string id)
        {
            return db.Lookup_Currency.Count(e => e.Code == id) > 0;
        }
        #endregion
    }
}