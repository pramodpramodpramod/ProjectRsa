﻿using System.Linq;
using System.Web.Http;
using System.Web.Security;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    [RoutePrefix("api")]
    public class AuthenticationController : ApiController
    {
        private readonly adminEntities _context;
        public AuthenticationController()
        {
            _context = new adminEntities();



        }
        [Route("authenticateduser")]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetAuthenticatedUser()
        {
            var user = _context.aspnet_Users.FirstOrDefault(x => x.LoweredUserName == User.Identity.Name.ToLower() && x.aspnet_Applications.LoweredApplicationName == "admin");
            string[] roles = new string[] { };

            if (user != null && user.IsActive)
            {
                roles = Roles.GetRolesForUser();
            }
            var response = new AuthenticatedUserResponse
            {
                Username = User.Identity.Name,
                Roles = roles
            };
            return Ok(response);

        }
    }
}