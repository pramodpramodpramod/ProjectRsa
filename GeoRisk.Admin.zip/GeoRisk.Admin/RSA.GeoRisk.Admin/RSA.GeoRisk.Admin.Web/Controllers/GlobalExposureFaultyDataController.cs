﻿using AutoMapper;
using RSA.GeoRisk.Admin.Web.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Mapping.Enums;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    public class GlobalExposureController : ApiController
    {
        private readonly geoRiskAppsEntities _context;
        private readonly adminEntities _admincontext;


        public GlobalExposureController()
        {
            _context = new geoRiskAppsEntities();
            _admincontext = new adminEntities();
        }

        [Route("api/globalexposure/getfaultydata")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(List<DailyExposureFaultyDataDTO>))]
        public IHttpActionResult GetFaultyData(string status)
        {
            try
            {
                var faultyData = _context.daily_exposure_faulty_data.Where(x => x.Status == status).ToList().Select(x => Mapper.Map<DailyExposureFaultyDataDTO>(x));
                return Ok(faultyData);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to get faulty datas ", ex));
            }
        }

        [Route("api/globalexposure/updatefaultydata")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(bool))]
        public IHttpActionResult UpdateFaultyData(JObject data)
        {
            var user = _admincontext.aspnet_Users.FirstOrDefault(x => x.LoweredUserName == User.Identity.Name.ToLower() && x.aspnet_Applications.LoweredApplicationName == "admin");

            if (data.SelectToken("data").Type == JTokenType.Array)
            {
                var faultyDataIds = data["data"].ToObject<List<int>>();
                try
                {
                    foreach (var item in faultyDataIds)
                    {
                        var entity = _context.daily_exposure_faulty_data.FirstOrDefault(x => x.Id == item);
                        _context.daily_exposure_faulty_data.Attach(entity);
                        entity.Status = StatusEnum.Resolved.ToString();
                        entity.NameOfInsured = "N/A";
                        entity.ResolvedBy = user.Email;
                        entity.ResolvedDate = DateTime.Now;
                    }

                    _context.SaveChanges();
                    return Ok(true);
                }
                catch (Exception ex)
                {
                    return InternalServerError(new Exception("Unable to update faulty datas ", ex));
                }
            }
            else
            {
                var faultyDataId = data["data"].ToObject<int>();

                try
                {
                    var entity = _context.daily_exposure_faulty_data.FirstOrDefault(x => x.Id == faultyDataId);
                    _context.daily_exposure_faulty_data.Attach(entity);
                    entity.Status = StatusEnum.Resolved.ToString();
                    entity.NameOfInsured = "N/A";
                    entity.ResolvedBy = user.Email;
                    entity.ResolvedDate = DateTime.Now;
                    _context.SaveChanges();
                    return Ok(true);
                }
                catch (Exception ex)
                {
                    return InternalServerError(new Exception("Unable to update faulty datas ", ex));
                }
            }
        }
    }
}
