﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using JsonPatch;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class HighRiskCountriesController : ApiController
    {
        private ReportingEntities reportingDb;
        private GeoRiskOneEntities geoRiskOneDb;
        private string PnPServiceBaseAddress;

        public HighRiskCountriesController()
        {
            var formatters = GlobalConfiguration.Configuration.Formatters;
            var jsonFormatter = formatters.JsonFormatter;
            var settings = jsonFormatter.SerializerSettings;
            settings.Formatting = Formatting.Indented;

            reportingDb = new ReportingEntities();
            geoRiskOneDb = new GeoRiskOneEntities();

            PnPServiceBaseAddress = ConfigurationManager.AppSettings["PnPServiceBaseAddress"];
        }

        [HttpGet]
        [Route("api/highriskcountries")]
        public IQueryable<GLOBAL_HIGH_RISK_COUNTRIES> GetGLOBAL_HIGH_RISK_COUNTRIES()
        {
            return reportingDb.GLOBAL_HIGH_RISK_COUNTRIES;
        }

        [HttpGet]
        [Route("api/highriskcountries/{id}")]
        [ResponseType(typeof(GLOBAL_HIGH_RISK_COUNTRIES))]
        public async Task<IHttpActionResult> GetGLOBAL_HIGH_RISK_COUNTRIES(int id)
        {
            var highRiskCountry = await reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.FindAsync(id);
            if (highRiskCountry == null)
            {
                return NotFound();
            }

            return Ok(highRiskCountry);
        }
                
        [ResponseType(typeof(void))]
        [Route("api/highriskcountries/patch/{id}")]
        [HttpPatch]
        //JsonPatchDocument<SomeDto> patchData
        public IHttpActionResult PatchGLOBAL_HIGH_RISK_COUNTRIES(int id, JsonPatchDocument<GLOBAL_HIGH_RISK_COUNTRIES> highRiskCountryUpdates)
        {
            GLOBAL_HIGH_RISK_COUNTRIES gLOBAL_HIGH_RISK_COUNTRY = reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.Find(id);
            highRiskCountryUpdates.ApplyUpdatesTo(gLOBAL_HIGH_RISK_COUNTRY);

            try
            {
                reportingDb.SaveChanges();
            }
            catch (Exception ex)
            {
               return Ok(ex);
            }

            return Ok(HttpStatusCode.NoContent);
        }

        // PUT: api/HighRiskCountries/5
        [ResponseType(typeof(void))]
        [Route("api/highriskcountries/edit/{id}")]
        [HttpPut]
        public async Task<IHttpActionResult> PutGLOBAL_HIGH_RISK_COUNTRIES(int id, GLOBAL_HIGH_RISK_COUNTRIES gLOBAL_HIGH_RISK_COUNTRIES)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != gLOBAL_HIGH_RISK_COUNTRIES.OBJECTID)
            {
                return BadRequest();
            }

            reportingDb.Entry(gLOBAL_HIGH_RISK_COUNTRIES).State = EntityState.Modified;

            try
            {
                await reportingDb.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                if (!GLOBAL_HIGH_RISK_COUNTRIESExists(id))
                {
                    return Ok(ex);
                }
                else
                {
                    return Ok(ex);
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/HighRiskCountries/add
        [Route("api/highriskcountries/add")]
        [ResponseType(typeof(GLOBAL_HIGH_RISK_COUNTRIES))]
        public async Task<IHttpActionResult> CreateHighRiskCountry(GLOBAL_HIGH_RISK_COUNTRIES highRiskCountry)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.Add(highRiskCountry);
            try
            {
                await reportingDb.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return Ok(new Exception("Unable to add sanction country" + highRiskCountry.CountryLongName, ex));
            }

            return Ok(highRiskCountry);
        }

        // DELETE: api/highriskcountries/delete
        [Route("api/highriskcountries/delete")]
        [ResponseType(typeof(GLOBAL_HIGH_RISK_COUNTRIES))]
        public async Task<IHttpActionResult> DeleteHighRiskCountry(int id)
        {
            GLOBAL_HIGH_RISK_COUNTRIES highRiskCountryToDelete = await reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.FindAsync(id);
            if (highRiskCountryToDelete == null)
            {
                return NotFound();
            }

            reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.Remove(highRiskCountryToDelete);
            try
            {
                await reportingDb.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return Ok(new Exception("Unable to delete sanction country" + highRiskCountryToDelete.CountryLongName, ex));
            }

            return Ok(highRiskCountryToDelete);
        }

        [Route("api/highriskcountriesPnP")]
        [ResponseType(typeof(List<HighRiskCountry>))]
        public async Task<IHttpActionResult> GetHighRiskCountriesFromPnP(int serviceId)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    List<HighRiskCountry> countriesFromPnP = new List<HighRiskCountry>();
                    var service = "test";// db.Services.Where(s => s.ServiceId == serviceId).ToList().FirstOrDefault();
                    if (service != null)
                    {
                        client.BaseAddress = new Uri(PnPServiceBaseAddress);
                        var response = await client.GetAsync("arcgis/rest/services/EditableLayers/FeatureServer/2/query?where=1%3D1&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&relationParam=&outFields=*&returnGeometry=false&maxAllowableOffset=&geometryPrecision=&outSR=&gdbVersion=&returnDistinctValues=false&returnIdsOnly=false&returnCountOnly=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&returnZ=false&returnM=false&f=pjson");
                        response.EnsureSuccessStatusCode();
                        var stringResult = await response.Content.ReadAsStringAsync();
                        JObject jResult = JObject.Parse(stringResult);

                        var query = from o in jResult["features"].Select(i => i["attributes"])
                                    select new HighRiskCountry()
                                    {
                                        OBJECTID = (string)o["OBJECTID"],
                                        CountryCodeA2 = (string)o["CountryCodeA2"],
                                        ReasonForInclusion = (string)o["ReasonForInclusion"],
                                        RSAApproach = (string)o["RSAApproach"],
                                        Classification = (string)o["Classification"],
                                        CapturedBy = (string)o["CapturedBy"]
                                    };
                        countriesFromPnP = query.ToList<HighRiskCountry>();
                        countriesFromPnP.RemoveAll(c => reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.Any(hc => hc.CountryCodeA2 == c.CountryCodeA2));

                        List<Country> geoRiskOneCountries = geoRiskOneDb.Countries.ToList();
                        for (int i = 0; i < countriesFromPnP.Count; i++)
                        {
                            HighRiskCountry hc = countriesFromPnP[i];
                            for (int j = 0; j < geoRiskOneCountries.Count; j++)
                            {
                                Country c = geoRiskOneCountries[j];
                                if (c != null && c.CountryCodeIso2==hc.CountryCodeA2)
                                {
                                    hc.CountryLongName = c.CountryName;
                                }
                            }
                        }
                    }
                    return Ok(countriesFromPnP.OrderBy(c=>c.CountryLongName));
                }
                catch (HttpRequestException ex)
                {
                    Console.Write(ex);
                    return Ok(new Exception("Unable to get countries from PnP", ex));
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                reportingDb.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool GLOBAL_HIGH_RISK_COUNTRIESExists(int id)
        {
            return reportingDb.GLOBAL_HIGH_RISK_COUNTRIES.Count(e => e.OBJECTID == id) > 0;
        }

        public class HighRiskCountry
        {
            public string OBJECTID { get; set; }
            public string CountryCodeA2 { get; set; }
            public string ReasonForInclusion { get; set; }
            public string RSAApproach { get; set; }
            public string Classification { get; set; }
            public string CapturedBy { get; set; }
            public string CountryLongName { get; set; }
        }
    }
}