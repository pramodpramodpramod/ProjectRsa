﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Http.Description;
using RSA.GeoRisk.Admin.Web.Models;
using RSA.GeoRisk.Admin.Web.DTOs;
using AutoMapper;
using System.Web.Http;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    public class ExternalAppUserController : ApiController
    {
        private readonly geoRiskAppsEntities _context;

        public ExternalAppUserController()
        {
            _context = new geoRiskAppsEntities();
        }

        [Route("api/externalapp/users")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(List<ExternalApplicationUserDTO>))]
        public IHttpActionResult GetUsers()
        {
            try
            {
                var users = _context.ExternalApplicationUsers.ToList().Select(x => Mapper.Map<ExternalApplicationUserDTO>(x));

                return Ok(users);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to get users ", ex));
            }
        }

        [Route("api/externalapp/user/view")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(ExternalApplicationUserDTO))]
        public IHttpActionResult GetUserDetails(int externalUserId)
        {
            try
            {
                ExternalApplicationUser user =
                    _context.ExternalApplicationUsers.FirstOrDefault(u => u.Id == externalUserId);
                if (user == null)
                {
                    return NotFound();
                }

                return Ok(Mapper.Map<ExternalApplicationUserDTO>(user));
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to find details about user " + externalUserId, ex));
            }
        }

        [Route("api/externalapp/user/create")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(string))]
        public IHttpActionResult CreateUser(ExternalApplicationUserDTO ExternalApplicationUserDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = Mapper.Map<ExternalApplicationUser>(ExternalApplicationUserDTO);
            user.RegistrationDate = DateTime.Now;
            _context.ExternalApplicationUsers.Add(user);
            _context.SaveChanges();

            return Ok(user.Name);
        }


        [Route("api/externalapp/user/delete")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(string))]
        public IHttpActionResult DeleteUser(int externalUserId)
        {
            try
            {
                ExternalApplicationUser userToDelete =
                    _context.ExternalApplicationUsers.Include(x=> x.Services).FirstOrDefault(u => u.Id == externalUserId);

                if (userToDelete == null) { return NotFound(); }

                _context.ExternalApplicationUsers.Remove(userToDelete);
                _context.SaveChanges();
                return Ok(userToDelete.Name);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to delete user " + externalUserId, ex));
            }
        }

        [Route("api/externalapp/user/update")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(ExternalApplicationUserDTO))]
        public IHttpActionResult UpdateUser(ExternalApplicationUserDTO externalApplicationUserDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var user = _context.ExternalApplicationUsers.FirstOrDefault(u => u.Id == externalApplicationUserDTO.Id);
                user.Name = externalApplicationUserDTO.Name;
                user.Email = externalApplicationUserDTO.Email;
                user.ExternalAppUserUrl = externalApplicationUserDTO.ExternalAppUserUrl;
                user.ServiceEndpoint = externalApplicationUserDTO.ServiceEndpoint;
                user.IsActive = externalApplicationUserDTO.IsActive;

                UpdateServicesRelationship(externalApplicationUserDTO);
                _context.SaveChanges();
                return Ok(Mapper.Map<ExternalApplicationUserDTO>(user));
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to update user " + externalApplicationUserDTO.Id, ex));
            }
        }

        [Route("api/externalapp/services")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(List<ServiceDetail>))]
        public IHttpActionResult GetAllServices()
        {
            try
            {
                var services = _context.Services.ToList();
                return Ok(Mapper.Map<List<ServiceDetail>>(services));
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to get services ", ex));
            }
        }

        private void UpdateServicesRelationship(ExternalApplicationUserDTO user)
        {
            try
            {
                var existingExternalUser = _context.ExternalApplicationUsers.Include(x => x.Services)
                    .Where(externalUser => externalUser.Id == user.Id).FirstOrDefault();

                var existingServiceIds = user.Services.Select(z => z.ServiceId).ToList();

                var existingServices = _context.Services.Where(x => existingServiceIds.Contains(x.ServiceId)).ToList();

                var deletedCourses = existingExternalUser.Services.Except(existingServices).ToList();
                var addedServices = existingServices.Except(existingExternalUser.Services).ToList();

                deletedCourses.ForEach(c => existingExternalUser.Services.Remove(c));

                foreach (var s in addedServices)
                {
                    if (_context.Entry(s).State == EntityState.Detached)
                        _context.Services.Attach(Mapper.Map<Service>(s));
                    existingExternalUser.Services.Add(Mapper.Map<Service>(s));
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
