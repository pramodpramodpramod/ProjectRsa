﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using RSA.GeoRisk.Admin.Web.Models;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Mapping.Enums;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class ServiceController : ApiController
    {
        private readonly geoRiskAppsEntities _context;

        public ServiceController()
        {
            _context = new geoRiskAppsEntities();
        }

        [Route("api/services/{appName}")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(List<ServiceResponse>))]
        public IHttpActionResult GetServices(string appName)
        {
            if (string.IsNullOrEmpty(appName))
            {
                return BadRequest();
            }

            var services = _context.Services.Include("BusinessType").Include("ServiceType")
                .Where(s => s.Map.App.Name == appName)
                .Select(s => new ServiceResponse
                {
                    ArcGisServiceLayerName = s.ArcGisServiceLayerName,
                    BusinessType = s.BusinessType.Name,
                    Name = s.Name,
                    ServiceId = s.ServiceId,
                    ServiceType = s.ServiceType.Name,
                    LicenceType = ((LicenceTypeEnum)s.LicenceType).ToString()
                })
                .ToList();

            return Ok(services);
        }

        [Route("api/service/view/{serviceId}")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(ServiceDetail))]
        public IHttpActionResult GetServiceDetails(int serviceId)
        {
            var service = _context.Services.Include("BusinessType").Include("ServiceType")
                .FirstOrDefault(s => s.ServiceId == serviceId);

            if (service == null)
            {
                return NotFound();
            }
            var serviceDetails = Mapper.Map<ServiceDetail>(service);
            serviceDetails.LicenceTypes = Enum.GetNames(typeof(LicenceTypeEnum)).Select(x => new EnumDTO { Name = x, Value = (int)Enum.Parse(typeof(LicenceTypeEnum), x) }).ToList();
            return Ok(serviceDetails);
        }

        [Route("api/service/update")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(string))]
        public IHttpActionResult UpdateService(ServiceDetail serviceToUpdate)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var service = _context.Services.FirstOrDefault(ser => ser.ServiceId == serviceToUpdate.ServiceId);

                if (serviceToUpdate.LicenceType == (int)LicenceTypeEnum.Group && service.LicenceType == (int)LicenceTypeEnum.Individual)
                {
                    var usersToDelete = _context.IndividualUserServices.Where(x => x.ServiceId == service.ServiceId);
                    _context.IndividualUserServices.RemoveRange(usersToDelete);
                }
                else if(serviceToUpdate.LicenceType == (int)LicenceTypeEnum.Individual && service.LicenceType == (int)LicenceTypeEnum.Group)
                {
                    var groupLicencewithThisService = _context.GroupLicences.Where(x => x.Services.Any(s => s.ServiceId == serviceToUpdate.ServiceId)).ToList();
                    foreach(var item in groupLicencewithThisService)
                    {
                        var deleteservice = item.Services.Where(x => x.ServiceId == serviceToUpdate.ServiceId).FirstOrDefault();
                        item.Services.Remove(deleteservice);
                    }
                }

                service.Url = serviceToUpdate.Url;
                service.ArcGisServiceLayerName = serviceToUpdate.ArcGisServiceLayerName;
                service.Visible = serviceToUpdate.Visible;
                service.BusinessType_BusinessTypeId = serviceToUpdate.BusinessType_BusinessTypeId;
                service.Attribution = serviceToUpdate.Attribution;
                service.BaseMapStyle_BaseMapStyleId = serviceToUpdate.BaseMapStyle_BaseMapStyleId;
                service.Identify = serviceToUpdate.Identify;
                service.isActive = serviceToUpdate.IsActive;
                service.opacity = serviceToUpdate.Opacity;
                service.layers = serviceToUpdate.Layers;
                service.LegendImage = Convert.FromBase64String(serviceToUpdate.LegendImage);
                service.LicenceType = serviceToUpdate.LicenceType;
                _context.SaveChanges();
                return Ok(service.Name);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}