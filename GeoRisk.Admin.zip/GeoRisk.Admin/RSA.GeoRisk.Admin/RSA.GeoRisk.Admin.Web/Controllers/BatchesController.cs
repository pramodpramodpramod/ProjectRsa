﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class BatchesController : ApiController
    {
        private ReportingEntities reportingDb;
        private adminEntities adminDb;
        private GLOBAL_EXPOSUREEntities globalExposureEntities;

        public BatchesController()
        {
            var formatters = GlobalConfiguration.Configuration.Formatters;
            var jsonFormatter = formatters.JsonFormatter;
            var settings = jsonFormatter.SerializerSettings;
            settings.Formatting = Formatting.Indented;
            settings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            reportingDb = new ReportingEntities();
            adminDb = new adminEntities();
            globalExposureEntities = new GLOBAL_EXPOSUREEntities();
        }



        [Route("api/batches/{applicationname}")]
        [ResponseType(typeof(List<ReportingBatch>))]
        public IHttpActionResult GetGdprBatches(string applicationname)
        {
            if (applicationname == "gdpr")
                return Ok(adminDb.GdprBatches);
            else
                return Ok(reportingDb.ReportingBatches.Include("BusinessArea"));

        }
        [Route("api/businessareas")]
        [ResponseType(typeof(List<BusinessArea>))]
        public IHttpActionResult GetBusinessAreas()
        {
            var businessAreas = reportingDb.BusinessAreas;

            return Ok(businessAreas);
        }

        [Route("api/reportingbatches/{id}", Name = "GetBatchById")]
        [ResponseType(typeof(ReportingBatch))]
        public async Task<IHttpActionResult> GetReportingBatch(int id)
        {
            ReportingBatch reportingBatch = await reportingDb.ReportingBatches.FindAsync(id);
            if (reportingBatch == null)
            {
                return NotFound();
            }

            return Ok(reportingBatch);
        }

        [Route("api/batches/{applicationname}/add")]
        [ResponseType(typeof(ReportingBatch))]
        [AcceptVerbs("POST")]
        public async Task<IHttpActionResult> AddBatch(string applicationname, ReportingBatch reportingBatch)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (applicationname != "gdpr")
            {
                if (reportingDb.ReportingBatches.Any(b => b.BatchId == reportingBatch.BatchId))
                {
                    return BadRequest($"Batch {reportingBatch.BatchId} already exists.");
                }
                else
                {
                    reportingDb.ReportingBatches.Add(reportingBatch);
                    await reportingDb.SaveChangesAsync();
                }
            }
            else
            {
                if (!globalExposureEntities.Batches.Any(x => x.BatchID == reportingBatch.BatchId))
                {
                    return BadRequest($"Batch Id : {reportingBatch.BatchId} not found.");
                }

                if (adminDb.GdprBatches.Any(b => b.BatchId == reportingBatch.BatchId))
                {
                    return BadRequest($"Batch {reportingBatch.BatchId} already exists.");
                }
                else
                {
                    GdprBatch gdpr = new GdprBatch() { BatchId = reportingBatch.BatchId };
                    adminDb.GdprBatches.Add(gdpr);
                    await adminDb.SaveChangesAsync();
                }
            }

            return Ok(reportingBatch.BatchId);
        }

        [Route("api/batches/{applicationname}/{BatchId}/delete")]
        [ResponseType(typeof(ReportingBatch))]
        [AcceptVerbs("GET")]
        public async Task<IHttpActionResult> DeleteBatch(string applicationname, int BatchId)
        {
            try
            {
                string id = "";
                if (applicationname == "gdpr")
                {
                    GdprBatch Batch = await adminDb.GdprBatches.FindAsync(BatchId);
                    adminDb.GdprBatches.Remove(Batch);
                    await adminDb.SaveChangesAsync();
                    id = Batch.BatchId;
                }
                else
                {
                    if (!ModelState.IsValid)
                    {
                        return BadRequest(ModelState);
                    }

                    ReportingBatch reportingBatch = await reportingDb.ReportingBatches.FindAsync(BatchId);
                    if (reportingBatch == null)
                    {
                        return NotFound();
                    }

                    if (reportingDb.High_Risk_Locations_Geographic.Any(hrl => hrl.BatchID == reportingBatch.BatchId))
                    {
                        throw new Exception("Batch " + reportingBatch.BatchId + " can not be deleted because is associated to a country");
                    }

                    reportingDb.ReportingBatches.Remove(reportingBatch);
                    await reportingDb.SaveChangesAsync();
                    id = reportingBatch.BatchId;


                }
                return Ok(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                reportingDb.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ReportingBatchExists(int id)
        {
            return reportingDb.ReportingBatches.Count(e => e.Id == id) > 0;
        }
    }
}
