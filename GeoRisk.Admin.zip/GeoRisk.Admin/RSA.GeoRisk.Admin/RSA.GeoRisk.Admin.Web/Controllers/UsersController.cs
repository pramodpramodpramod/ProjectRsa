﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using RSA.GeoRisk.Admin.Web.Directory;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Models;
using RSA.GeoRisk.Admin.Web.Persistence;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class UsersController : ApiController
    {
        private readonly adminEntities _adminEntitiesContext;
        private readonly GeoRiskOneEntities _geoRiskOneEntitiesContext;
        private readonly IActiveDirectoryScanner _activeDirectoryScanner;
        private readonly IAuditUsersRepository _auditUsersRepository;
        private readonly geoRiskAppsEntities _geoRiskAppsEntities;

        public UsersController()
        {
            _adminEntitiesContext = new adminEntities();
            _geoRiskOneEntitiesContext = new GeoRiskOneEntities();
            _auditUsersRepository = new AuditUsersRepository(_adminEntitiesContext);
            _activeDirectoryScanner = new ActiveDirectoryScanner();
            _geoRiskAppsEntities = new geoRiskAppsEntities();
        }

        [Route("api/users/{applicationname}")]
        [ResponseType(typeof(List<aspnet_UsersInRoles_GetUsersInRoles_Result>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetUsersForRole(string applicationname, string rolenames)
        {
            try
            {
                List<aspnet_UsersInRoles_GetUsersInRoles_Result> usersFound = new List<aspnet_UsersInRoles_GetUsersInRoles_Result>();
                if (rolenames == null)
                {
                    List<aspnet_Roles_GetAllRoles_Result> roles = _adminEntitiesContext.aspnet_Roles_GetAllRoles(applicationname).ToList();
                    foreach (aspnet_Roles_GetAllRoles_Result role in roles)
                    {
                        usersFound.AddRange(_adminEntitiesContext.aspnet_UsersInRoles_GetUsersInRoles(applicationname, role.RoleName));
                    }

                }
                else
                {
                    string[] roles;
                    roles = rolenames.Split(',');
                    foreach (string role in roles)
                    {
                        usersFound.AddRange(_adminEntitiesContext.aspnet_UsersInRoles_GetUsersInRoles(applicationname, role));
                    }
                }

                usersFound = usersFound.GroupBy(s => s.UserName).Select(s => s.First()).OrderBy(s => s.UserName).ToList();

                return Ok(usersFound);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to find users in " + applicationname + " who have these roles.", e));
            }
        }

        [Route("api/users/{applicationname}")]
        [ResponseType(typeof(List<UserDTO>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetUsers(string applicationname)
        {
            try
            {

                var applicationUsers = _adminEntitiesContext.aspnet_Users
                    .Where(u => u.aspnet_Applications.ApplicationName == applicationname)
                    .Select(u => new UserDTO
                    {
                        UserName = u.UserName,
                        FirstName = u.FirstName,
                        LastName = u.LastName,
                        Email = u.Email,
                        ApproverEmail = u.ApproverEmail,
                        RoleName = u.aspnet_Roles.FirstOrDefault().RoleName,
                        Location = u.Location,
                        RegistrationDate = u.RegistrationDate,
                        LastActivityDate = u.LastActivityDate.HasValue ? u.LastActivityDate : null,
                        IsActive = u.IsActive,
                        ApplicationId = u.ApplicationId,
                        LastSuspendedDate = u.LastSuspendedDate,
                        SuspendedBy = u.SuspendedBy
                    })
                    .ToList();

                return Ok(applicationUsers);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to find users in " + applicationname, e));
            }
        }



        [Route("api/roles/{applicationname}")]
        [ResponseType(typeof(List<aspnet_Roles_GetAllRoles_Result>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetRolesForApplication(string applicationname)
        {
            try
            {
                var appRoles = _adminEntitiesContext.aspnet_Roles
                    .Where(role => role.aspnet_Applications.ApplicationName == applicationname)
                    .ToList()
                    .Select(Mapper.Map<UserRoleDTO>);
                return Ok(appRoles);
            }
            catch (Exception e)
            {

                return Ok(new Exception("Unable to find roles for " + applicationname, e));
            }
        }

        [Route("api/extrainfo/{applicationname}")]
        [ResponseType(typeof(List<NewUserExtraInfoDTO>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetNewUserExtraInfo(string applicationname)
        {
            try
            {
                var appRoles = _adminEntitiesContext.aspnet_Roles
                    .Where(role => role.aspnet_Applications.ApplicationName == applicationname)
                    .ToList()
                    .Select(Mapper.Map<UserRoleDTO>).ToList();

                var countries = _geoRiskOneEntitiesContext.Countries
                    .OrderBy(c => c.CountryName)
                    .Select(c => c.CountryName).ToList();
                NewUserExtraInfoDTO extraInfo = new NewUserExtraInfoDTO()
                {
                    AllRoles = appRoles,
                    Locations = countries
                };
                return Ok(extraInfo);
            }
            catch (Exception e)
            {

                return Ok(new Exception("Unable to find extraInfo when a new user is created for application " + applicationname, e));
            }
        }

        [Route("api/user/{applicationame}/roles/add")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(Object))]
        [AcceptVerbs("GET")]
        public IHttpActionResult AddUserToRoles(string applicationame, string username, string rolenames)
        {
            try
            {
                var result = _adminEntitiesContext.aspnet_UsersInRoles_AddUsersToRoles(applicationame, username, rolenames, DateTime.Now);
                return Ok(result);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to add " + username + " to role(s): " + rolenames, e));
            }
        }

        [Route("api/user/{applicationame}/roles/remove")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(Object))]
        [AcceptVerbs("GET")]
        public IHttpActionResult RemoveUserFromRoles(string applicationame, string username, string rolenames)
        {
            try
            {
                var result = _adminEntitiesContext.aspnet_UsersInRoles_RemoveUsersFromRoles(applicationame, username, rolenames);
                return Ok(result);
            }
            catch (Exception e)
            {

                return Ok(new Exception("Unable to remove " + rolenames + " from roles for user " + rolenames, e));
            }
        }


        [Route("api/user/{applicationname}/create")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("GET")]
        public IHttpActionResult SaveNewUser(string applicationname, string username)
        {
            ObjectParameter userIdOutput = new ObjectParameter("UserId", typeof(Int32));

            var userApplicationId = _adminEntitiesContext.aspnet_Applications
                .First(x => x.ApplicationName.ToLower() == applicationname).ApplicationId;
            _adminEntitiesContext.aspnet_Users_CreateUser(userApplicationId, username, false, DateTime.Now, DateTime.Now, userIdOutput);

            return Ok(userIdOutput.Value);
        }

        [Route("api/user/{applicationname}/create/extended")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(Object))]
        [HttpPost]
        public async Task<IHttpActionResult> CreateNewExtendedUser(string applicationname, [FromBody] UserDTO userDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var application = _adminEntitiesContext.aspnet_Applications
                    .Where(app => app.LoweredApplicationName == applicationname.ToLower()).FirstOrDefault();

                aspnet_Users newUser = Mapper.Map<aspnet_Users>(userDto);
                newUser.ApplicationId = application.ApplicationId;
                newUser.UserId = Guid.NewGuid();
                newUser.RegistrationDate = DateTime.Now;
                newUser.IsActive = true;
                newUser.ApplicationName = application.ApplicationName;
                _adminEntitiesContext.aspnet_Users.Add(newUser);
                await _adminEntitiesContext.SaveChangesAsync();
                string role;
                for (int i = 0; i < userDto.Roles.Length; i++)
                {
                    role = userDto.Roles[i];
                    _adminEntitiesContext.aspnet_UsersInRoles_AddUsersToRoles(applicationname, userDto.UserName, role, DateTime.UtcNow);
                }

                return Ok(userDto.UserName);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to save " + userDto.UserName + " to " + applicationname, e));
            }
        }

        [Route("api/user/{applicationame}/delete")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(Object))]
        [AcceptVerbs("GET")]
        public IHttpActionResult DeleteUser(string applicationame, string username)
        {
            try
            {
                var userToDelete = _adminEntitiesContext.aspnet_Users
                    .Include("aspnet_Applications")
                    .FirstOrDefault(u => u.UserName == username && u.aspnet_Applications.ApplicationName == applicationame);

                if (userToDelete == null)
                {
                    return BadRequest();
                }

                ObjectParameter numTablesDeletedFrom = new ObjectParameter("numTablesDeletedFrom", typeof(Int32));
                _adminEntitiesContext.aspnet_Users_DeleteUser(applicationame, username, 15, numTablesDeletedFrom);

                var userAudit = AuditUserDto.FromUser(userToDelete);
                userAudit.ArchivedBy = User.Identity.Name.ToLower();
                _auditUsersRepository.Add(userAudit);

                return Ok(numTablesDeletedFrom.Value);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to delete " + username + " from " + applicationame, e));
            }
        }

        [Route("api/user/update")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(Object))]
        [HttpPut]
        public IHttpActionResult UpdateUser(UserDTO userDto)
        {
            try
            {
                var existingUser = _adminEntitiesContext.aspnet_Users
                    .FirstOrDefault(u => u.UserName == userDto.UserName && u.ApplicationId == userDto.ApplicationId);
                if (existingUser == null)
                {
                    return BadRequest();
                }

                existingUser.FirstName = userDto.FirstName;
                existingUser.LastName = userDto.LastName;
                existingUser.Email = userDto.Email;
                existingUser.Location = userDto.Location;
                existingUser.ApproverEmail = userDto.ApproverEmail;
                if (userDto.IsActive == false && existingUser.IsActive)
                {
                    existingUser.LastSuspendedDate = DateTime.Now;
                    existingUser.SuspendedBy = HttpContext.Current.User.Identity.Name;
                    existingUser.ActivatedBy = null;
                    existingUser.ActivatedByDate = null;
                }
                if (userDto.IsActive && existingUser.IsActive == false)
                {
                    existingUser.LastSuspendedDate = null;
                    existingUser.SuspendedBy = null;
                    existingUser.ActivatedBy = HttpContext.Current.User.Identity.Name;
                    existingUser.ActivatedByDate = DateTime.Now;
                }

                existingUser.IsActive = userDto.IsActive;

                var currentRoles = existingUser.aspnet_Roles.Select(r => r.RoleName).ToArray();
                if (!currentRoles.SequenceEqual(userDto.Roles))
                {
                    existingUser.aspnet_Roles.Clear();
                    string role;
                    for (int i = 0; i < userDto.Roles.Length; i++)
                    {
                        role = userDto.Roles[i];
                        var newRole = _adminEntitiesContext.aspnet_Roles
                        .FirstOrDefault(r => r.RoleName == role && r.ApplicationId == userDto.ApplicationId);
                        existingUser.aspnet_Roles.Add(newRole);
                    }
                }

                _adminEntitiesContext.SaveChanges();

                return Ok(userDto.UserName);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to update user " + userDto.UserName, ex));
            }
        }

        [Route("api/users/{applicationName}/suspend")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [HttpPost]
        public IHttpActionResult SuspendUsers(List<string> users, string applicationName)
        {
            if (!users.Any())
            {
                return BadRequest();
            }

            var usersToSuspend = _adminEntitiesContext.aspnet_Users
                .Where(u => users.Contains(u.UserName) && u.aspnet_Applications.ApplicationName == applicationName);

            foreach (var user in usersToSuspend)
            {
                user.IsActive = false;
                user.LastSuspendedDate = DateTime.Now;
                user.SuspendedBy = HttpContext.Current.User.Identity.Name;
                user.IsNotified = false;
                user.ActivatedBy = null;
                user.ActivatedByDate = null;
            }

            _adminEntitiesContext.SaveChanges();

            return Ok();
        }

        [Route("api/users/{applicationName}/delete")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [HttpPost]
        public IHttpActionResult DeleteUsers(List<string> users, string applicationName)
        {
            if (!users.Any())
            {
                return BadRequest();
            }

            var usersToDelete = _adminEntitiesContext.aspnet_Users
                .Include("aspnet_Applications")
                .Where(u => users.Contains(u.UserName) && u.aspnet_Applications.ApplicationName == applicationName)
                .ToList();

            foreach (var user in usersToDelete)
            {
                ObjectParameter numTablesDeletedFrom = new ObjectParameter("numTablesDeletedFrom", typeof(Int32));

                _adminEntitiesContext.aspnet_Users_DeleteUser(applicationName, user.UserName, 15, numTablesDeletedFrom);

                var userAudit = AuditUserDto.FromUser(user);
                userAudit.ArchivedBy = User.Identity.Name.ToLower();
                _auditUsersRepository.Add(userAudit);
            }

            _adminEntitiesContext.SaveChanges();

            return Ok();
        }

        [Route("api/user/{applicationname}/view")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(UserDTO))]
        public IHttpActionResult GetUserDetails(string applicationName, string userName)
        {
            try
            {
                aspnet_Users user = _adminEntitiesContext.aspnet_Users
                    .FirstOrDefault(u => u.aspnet_Applications.ApplicationName == applicationName && u.UserName == userName);
                if (user == null)
                {
                    return NotFound();
                }

                UserDTO userDto = Mapper.Map<UserDTO>(user);
                userDto.RoleName = user.aspnet_Roles.FirstOrDefault()?.RoleName;
                userDto.Roles = user.aspnet_Roles.Select(r => r.RoleName).ToArray();
                return Ok(userDto);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to find details about user " + userName, ex));
            }
        }

        [Route("api/user/ad")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(List<object>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetUserFromActiveDirectory(string searchName)
        {
            try
            {
                var activeDirectoryUser = _activeDirectoryScanner.GetActiveDirectoryUser(searchName.TrimStart().TrimEnd());
                return Ok(activeDirectoryUser);
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, ex.Message });
            }
        }

        [Route("api/user/ad/checkmail")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [ResponseType(typeof(List<object>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult CheckEmailInActiveDirectory(string email)
        {
            try
            {
                var emailExist = _activeDirectoryScanner.CheckIfEmailExsitAgainstAD(email.TrimStart().TrimEnd());
                return Ok(emailExist);
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, ex.Message });
            }
        }


        [Route("api/auditusers")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [HttpGet]
        public IHttpActionResult GetAuditUsers(string applicationName)
        {
            if (string.IsNullOrEmpty(applicationName))
            {
                return BadRequest();
            }

            var auditUsers = _auditUsersRepository.GetAll(applicationName);

            return Ok(auditUsers);
        }
    }
}
