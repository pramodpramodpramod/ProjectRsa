﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class ReportsController : ApiController
    {
        private ReportingEntities db;

        public ReportsController()
        {
            var formatters = GlobalConfiguration.Configuration.Formatters;
            var jsonFormatter = formatters.JsonFormatter;
            var settings = jsonFormatter.SerializerSettings;
            settings.Formatting = Formatting.Indented;
            settings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            db = new ReportingEntities();
        }

        // GET: api/Reports
        public IQueryable<Report> GetReports()
        {
            return db.Reports;
        }

        [Route("api/reports/reporttypes")]
        [ResponseType(typeof(List<ReportType>))]
        public async Task<IHttpActionResult> GetReportTypes()
        {

            //ensure lazy loading is false: C:\Development\Galaxy\Reporting\GeoRisk.Reporting\GeoRisk.ReportingAPI\Models\ReportingModel.Context.cs
            try
            {
                var reportTypes = await db.ReportTypes.ToListAsync();
                return Ok(reportTypes);
            }
            catch (Exception ex)
            {
                return Ok(ex);

            }

        }

        [Route("api/reports/{reporttypeid}")]
        [ResponseType(typeof(List<Object>))]
        //this information will be used to populate the date-drop-down in the reporting modal
        public async Task<IHttpActionResult> GetReportsByReportType(int reporttypeid)
        {
            List<Report> reports = await db.Reports.Where(x => x.reportTypeId == reporttypeid).ToListAsync();//.Include(x => x.DataAccuracies).FirstAsync();
            if (reports == null)
            {
                return NotFound();
            }

            //we need to create this new anonymous-object-collection, because if we return the list of Reports, there will be a circular
            //dependancy issue when we try to json serialize (and if we try to add [JsonIgnore] attribute to properties in the model, this will
            //work, but regenerating the model (if we change a datatype, column size, etc) deletes the JsonIgnore attributes 
            var reportsByReportType = reports.Select(
                y => new {
                    reportId = y.reportId,
                    reportTypeId = y.reportTypeId,
                    date = y.date
                }).OrderByDescending(x => x.date);

            return Ok(reportsByReportType);
        }

        [Route("api/reports/datacurrency/{businessArea}/{reportId}")]
        [ResponseType(typeof(List<Object>))]
        public async Task<IHttpActionResult> GetDataCurrency(string businessArea, int reportId)
        {
            List<DataCurrency> dataCurrencyResults = null;



            if (businessArea.ToLower() == "global")
            {
                dataCurrencyResults = await db.DataCurrencies.Where(x => x.reportId == reportId).ToListAsync();
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();
                dataCurrencyResults = db.DataCurrencies.Where(o => reportingBatches.Contains(o.batchIdShort) && o.reportId == reportId).ToList();
            }

            var dataCurencies = (from dataCurrency in dataCurrencyResults
                                 select new
                                 {
                                     //reportId = dataCurrency.reportId,
                                     batchIdShort = dataCurrency.batchIdShort,
                                     batchIdLong = dataCurrency.batchIdLong,
                                     producingOperation = dataCurrency.producingOperation,
                                     lastUpload = dataCurrency.ProcessingComplete
                                 }).OrderBy(x => x.batchIdLong);

            return Ok(dataCurencies);
        }


        [Route("api/reports/dataaccuracy/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public IHttpActionResult GetDataAccuracyReport(string businessArea, int reportid)
        {
            //var report = new System.Object();

            Report report = null;
            report = db.Reports.Where(x => x.reportId == reportid).First();

            List<DataAccuracy> dataAccuracies = null;

            Object dataAccuracyReport;

            if (businessArea.ToLower() == "global")
            {
                dataAccuracies = db.Entry(report).Collection(b => b.DataAccuracies).Query().ToList();
                dataAccuracyReport = CreateDataAccuracyReport(report, dataAccuracies, true);
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();
                dataAccuracies = db.Entry(report).Collection(b => b.DataAccuracies).Query().Where(o => reportingBatches.Contains(o.BatchID)).ToList();
                dataAccuracyReport = CreateDataAccuracyReport(report, dataAccuracies, false);
            }

            if (report == null)
            {
                return NotFound();
            }

            return Ok(dataAccuracyReport);
        }

        private object CreateDataAccuracyReport(Report report, List<DataAccuracy> dataAccuracies, bool global)
        {
            //we need to create this new anonymous-object-collection, because if we return the list of Reports, there will be a circular
            //dependancy issue when we try to json serialize (and if we try to add [JsonIgnore] attribute to properties in the model, this will
            //work, but the model delete the JsonIgnore attributes everytime we update the model
            object dataAccuracyReport;

            //for global, we group by reporting businessArea ...
            if (global)
            {
                dataAccuracyReport = new
                {
                    report = new
                    {
                        reportId = report.reportId,
                        //ReportType = report.ReportType, 
                        reportTypeId = report.reportTypeId
                    },
                    reportData = dataAccuracies.GroupBy(b => b.ReportingRegion).Select(
                        dataAccuracy => new
                        {
                            //BatchID = dataAccuracy.BatchID,
                            //LatestInceptionDate = dataAccuracy.LatestInceptionDate,
                            LocationsDroppedOff = dataAccuracy.Sum(c => c.LocationsDroppedOff),// dataAccuracy.LocationsDroppedOff,
                            LocationsDroppedOff_Title = "Number of Locations Dropped Off",
                            LocationOldDeletionDate = dataAccuracy.Sum(c => c.LocationsOldDeletionDate),
                            LocationOldDeletionDate_Title = "Number of Locations Expired",
                            //LocationsOldDeletionDate = dataAccuracy.LocationsOldDeletionDate,
                            noTSI = dataAccuracy.Sum(c => c.noTSI),
                            noTSI_Title = "Number of Locations with No TSI",
                            PremiumAtZero = dataAccuracy.Sum(c => c.PremiumAtZero),
                            PremiumAtZero_Title = "Number of Locations with Premium equal to 0",
                            //ProcessingComplete = dataAccuracy.ProcessingComplete,
                            RecordsProcessed = dataAccuracy.Sum(c => c.RecordsProcessed),
                            RecordsProcessed_Title = "Number of Locations uploaded to Gaia",
                            ReportingRegion = dataAccuracy.FirstOrDefault().ReportingRegion,
                            SuppliedGeocodes = dataAccuracy.Sum(c => c.SuppliedGeocodes),
                            SuppliedGeocodes_Title = "Number of Locations with Supplied Geocodes",
                            TotalLocationsGaia = dataAccuracy.Sum(c => c.TotalLocationsGaia),
                            TotalLocationsGaia_Title = "Number of Locations currently in Gaia"
                        }).OrderBy(x => x.ReportingRegion)
                };
            }
            //for regional, we group by batch id...                 
            else
            {
                dataAccuracyReport = new
                {
                    report = new
                    {
                        reportId = report.reportId,
                        //ReportType = report.ReportType, 
                        reportTypeId = report.reportTypeId
                    },
                    reportData = dataAccuracies.Select(
                        dataAccuracy => new
                        {
                            BatchID = dataAccuracy.BatchID,
                            BatchName = dataAccuracy.batchDescription,
                            //LatestInceptionDate = dataAccuracy.LatestInceptionDate,
                            LocationsDroppedOff = dataAccuracy.LocationsDroppedOff,
                            LocationsDroppedOff_Title = "Number of Locations Dropped Off",
                            LocationOldDeletionDate = dataAccuracy.LocationsOldDeletionDate,
                            LocationOldDeletionDate_Title = "Number of Locations Expired",
                            //LocationsOldDeletionDate = dataAccuracy.LocationsOldDeletionDate,
                            noTSI = dataAccuracy.noTSI,
                            noTSI_Title = "Number of Locations with No TSI",
                            PremiumAtZero = dataAccuracy.PremiumAtZero,
                            PremiumAtZero_Title = "Number of Locations with Premium equal to 0",
                            //ProcessingComplete = dataAccuracy.ProcessingComplete,
                            RecordsProcessed = dataAccuracy.RecordsProcessed,
                            RecordsProcessed_Title = "Number of Locations uploaded to Gaia",
                            //ReportingRegion = dataAccuracy.ReportingRegion,
                            SuppliedGeocodes = dataAccuracy.SuppliedGeocodes,
                            SuppliedGeocodes_Title = "Number of Locations with Supplied Geocodes",
                            TotalLocationsGaia = dataAccuracy.TotalLocationsGaia,
                            TotalLocationsGaia_Title = "Number of Locations currently in Gaia"

                        }).OrderBy(x => x.BatchName)
                };
            }

            return dataAccuracyReport;
        }

        [Route("api/reports/highrisk/{businessArea}/{reportid}")]
        [ResponseType(typeof(List<Object>))]
        public IHttpActionResult GetHighRiskReport(string businessArea, int reportid)
        {
            List<getHighRiskLocations_Result> highRiskLocsResults = null;
            var theParam = new SqlParameter { ParameterName = "reportId", Value = reportid };
            try
            {
                if (businessArea.ToLower() == "global")
                {
                    highRiskLocsResults = db.Database.SqlQuery<getHighRiskLocations_Result>("getHighRiskLocations @reportId", theParam).ToList();
                }
                else
                {
                    var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();
                    highRiskLocsResults = db.Database.SqlQuery<getHighRiskLocations_Result>("getHighRiskLocations @reportId", theParam).Where(o => reportingBatches.Contains(o.BatchID)).ToList();
                }

            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }

            List<HighRiskDetails> allHighRisks = new List<HighRiskDetails>();

            //we are putting our results data into a new structure that makes it readable into a 
            //stacked bar chart: http://bl.ocks.org/mbostock/3886208
            //stackoverflow help here: http://stackoverflow.com/questions/16503773/get-dictionary-key-value-pairs-without-knowing-its-type
            foreach (var highRisk in highRiskLocsResults)
            {
                //have we defined this batch yet?
                var batch = allHighRisks.Where(x => x.label == JoinBatchIdAndDescription(highRisk)).FirstOrDefault();

                #region group by BatchID

                //if we have NOT defined this batch yet, create the batch, and add the country details
                if (batch == null)
                {
                    List<CountryDetails> CountryDetails = new List<CountryDetails>() {
                        new CountryDetails()
                            {
                                label = highRisk.IntersectingCountryName,
                                category = highRisk.Classification,
                                y = highRisk.Number_of_Locations.GetValueOrDefault()
                            }
                    };

                    HighRiskDetails HighRiskDetails = new HighRiskDetails()
                    {
                        //producingOp = highRisk.producingOperation,
                        label = JoinBatchIdAndDescription(highRisk),
                        children = CountryDetails
                    };

                    allHighRisks.Add(HighRiskDetails);
                }
                //if we have defined this batch yet, and add the country details to that existing batch
                else
                {
                    batch.children.Add(new CountryDetails()
                    {
                        label = highRisk.IntersectingCountryName,
                        category = highRisk.Classification,
                        y = highRisk.Number_of_Locations.GetValueOrDefault()
                    });
                }
                # endregion
            }

            //create a value that respresents the sum of all the locations in high risk countries for each prod op
            allHighRisks.ForEach(Summarise);

            var orderedAllHighRisks = allHighRisks.OrderByDescending(b => b.y);

            return Ok(orderedAllHighRisks);
        }

        private string JoinBatchIdAndDescription(getHighRiskLocations_Result highRisk)
        {
            string batchDescription = String.IsNullOrEmpty(highRisk.batchDescription) ? "" : " (" + highRisk.batchDescription + ")";
            return highRisk.BatchID + batchDescription;
        }


        [Route("api/reports/highrisklocation/{reportId}/{intersectingCountry}/{batch}")]
        [ResponseType(typeof(List<Object>))]
        public async Task<IHttpActionResult> GetHighRiskLocation(string reportId, string intersectingCountry, string batch)
        {
            List<getHighRiskLocationsByIntersectingCountryName_Result> locations = null;
            if (reportId != string.Empty && intersectingCountry != string.Empty && batch != string.Empty)
            {
                SqlParameter[] parameters = new SqlParameter[3] { new SqlParameter { ParameterName = "@reportId", Value = reportId },
                                                                           new SqlParameter { ParameterName = "@IntersectingCountryName", Value = intersectingCountry },
                                                                           new SqlParameter { ParameterName = "@batch", Value = batch } };
                locations = await db.Database.SqlQuery<getHighRiskLocationsByIntersectingCountryName_Result>("getHighRiskLocationsByIntersectingCountryName @reportId,@IntersectingCountryName,@batch", parameters).ToListAsync();

            }

            return Ok(locations);
        }

        //we need to pass regiondisplayname as a query param because it might have funny characters in it.
        [Route("api/reports/highrisklocation/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetHighRiskLocationsForExport(string reportid, string businessarea)
        {

            List<getHighRiskLocationsByRegionForExport_Result> locations = null;

            SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter("@reportId",(object)reportid ?? DBNull.Value),
                new SqlParameter("@regionDisplayName",(object)businessarea ?? DBNull.Value),
            };

            locations = await db.Database.SqlQuery<getHighRiskLocationsByRegionForExport_Result>("getHighRiskLocationsByRegionForExport @reportId,@regionDisplayName", parameters).ToListAsync();

            return Ok(locations);
        }

        private static void Summarise(HighRiskDetails highRiskDetails)
        {
            highRiskDetails.y = highRiskDetails.children.Sum(b => b.y);
        }


        [Route("api/reports/geocoding/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetGeocodeAccuracy(string businessArea, int reportid)
        {
            Object geocodeReport = null;

            if (businessArea.ToLower() == "global")
            {
                geocodeReport = await db.NetTSIGBP_ByProdOpGeocodeAccuracy.Where(x => x.reportId == reportid).GroupBy(x => x.geocodeAccuracy).Select(
                        b => new
                        {
                            geocodingLevel = b.FirstOrDefault().geocodeAccuracy,
                            sumLocations = b.Sum(c => c.NumberOfLocations),
                            sumTSI = b.Sum(c => c.netTSI_GBP)
                        }
                    ).ToListAsync();
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();

                geocodeReport = await db.NetTSIGBP_ByProdOpGeocodeAccuracy.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.geocodeAccuracy).Select(
                        b => new
                        {
                            geocodingLevel = b.FirstOrDefault().geocodeAccuracy,
                            sumLocations = b.Sum(c => c.NumberOfLocations),
                            sumTSI = b.Sum(c => c.netTSI_GBP)
                        }
                    ).ToListAsync();
            }



            if (geocodeReport == null)
            {
                return NotFound();
            }

            return Ok(geocodeReport);
        }

        //report id 5 works
        [Route("api/reports/lineofbusiness/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetLineOfBusinessInfo(string businessArea, int reportid)
        {

            Object lobReport = null;

            if (businessArea.ToLower() == "global")
            {
                lobReport = await db.GrossTSIGBP_ByLOB.Where(x => x.reportId == reportid).GroupBy(x => x.LineOfBusiness).Select(
                        b => new
                        {
                            LineOfBusiness = b.FirstOrDefault().LineOfBusiness,
                            GrossTSI_GBP = b.Sum(c => c.GrossTSI_GBP),
                            Location_Count = b.Sum(c => c.Location_Count)
                        }
                    ).OrderByDescending(x => x.GrossTSI_GBP).ToListAsync();
            }
            else
            {

                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();

                lobReport = await db.GrossTSIGBP_ByLOB.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.LineOfBusiness).Select(
                        b => new
                        {
                            LineOfBusiness = b.FirstOrDefault().LineOfBusiness,
                            GrossTSI_GBP = b.Sum(c => c.GrossTSI_GBP),
                            Location_Count = b.Sum(c => c.Location_Count)
                        }
                    ).OrderByDescending(x => x.GrossTSI_GBP).ToListAsync();
            }

            return Ok(lobReport);
        }

        [Route("api/reports/prodop/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetProdOps(string businessArea, int reportid)
        {
            Object prodOpReport = null;

            if (businessArea.ToLower() == "global")
            {
                prodOpReport = await db.GrossTSIGBP_ByProdOp.Where(x => x.reportId == reportid).GroupBy(x => x.businessArea).Select(
                        b => new {
                            grossTSI_GBP = b.Sum(c => c.GrossTSI_GBP),
                            businessArea = b.FirstOrDefault().businessArea,
                        }
                    ).OrderByDescending(b => b.grossTSI_GBP).ToListAsync();
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();

                prodOpReport = await db.GrossTSIGBP_ByProdOp.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.BatchID).Select(
                        b => new {
                            grossTSI_GBP = b.Sum(c => c.GrossTSI_GBP),
                            batchId = b.FirstOrDefault().BatchID
                        }
                    ).OrderByDescending(b => b.grossTSI_GBP).ToListAsync();
            }

            return Ok(prodOpReport);
        }

        [Route("api/reports/country/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetCountryDetail(string businessArea, int reportid)
        {

            Object countryDetailReport = null;

            if (businessArea.ToLower() == "global")
            {
                countryDetailReport = await db.GeographicCountryAnalysis.Where(x => x.reportId == reportid).GroupBy(x => x.Country).Select(
                        b => new
                        {
                            country = b.FirstOrDefault().Country,
                            sumLocations = b.Sum(c => c.NumberOfLocations)
                        }
                    ).OrderByDescending(b => b.sumLocations).Take(15).ToListAsync();
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();
                countryDetailReport = await db.GeographicCountryAnalysis.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.Country).Select(
                        b => new
                        {
                            country = b.FirstOrDefault().Country,
                            sumLocations = b.Sum(c => c.NumberOfLocations)
                        }
                    ).OrderByDescending(b => b.sumLocations).Take(15).ToListAsync();
            }

            return Ok(countryDetailReport);
        }

        //reportId = 38 works for this
        [Route("api/reports/loccountby/lineofbusiness/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetLocationCountByLob(string businessArea, int reportid)
        {
            Object locationCountByLob = null;

            if (businessArea.ToLower() == "global")
            {
                locationCountByLob = await db.locationsByLOBs.Where(x => x.reportId == reportid).GroupBy(x => x.LineOfBusiness).Select(
                        b => new
                        {
                            lineOfBusiness = b.FirstOrDefault().LineOfBusiness,
                            locationCount = b.Sum(c => c.Location_Count)
                        }).OrderByDescending(b => b.locationCount).ToListAsync();
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();
                locationCountByLob = await db.locationsByLOBs.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.LineOfBusiness).Select(
                        b => new
                        {
                            lineOfBusiness = b.FirstOrDefault().LineOfBusiness,
                            locationCount = b.Sum(c => c.Location_Count)
                        }).OrderByDescending(b => b.locationCount).ToListAsync();
            }

            return Ok(locationCountByLob);
        }

        //reportId = 22 works for this
        [Route("api/reports/loccountby/businessarea/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetLocationCountBy(string businessArea, int reportid)
        {
            Object locationCountByProdOp = null;
            try
            {
                if (businessArea.ToLower() == "global")
                {
                    //if (groupby == "businessarea") {
                    locationCountByProdOp = await db.locationsByProdOps.Where(x => x.reportId == reportid).GroupBy(x => x.businessArea).Select(
                        b => new
                        {
                            locationCount = b.Sum(c => c.locationCount),
                            businessArea = b.FirstOrDefault().businessArea,
                        }).OrderByDescending(b => b.locationCount).ToListAsync();
                    //}
                    //else if (groupby == "lineofbusiness") {
                    //    locationCountByProdOp = await db.locationsByProdOps.Where(x => x.reportId == reportid).GroupBy(x => x.lineOfbusiness).Select(
                    //        b => new 
                    //        {
                    //            locationCount = b.Sum(c => c.locationCount),
                    //            lineOfbusiness = b.FirstOrDefault().lineOfbusiness,
                    //        }).OrderByDescending(b => b.locationCount).ToListAsync();
                    //}

                }
                else
                {
                    var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();
                    //if (groupby == "businessarea") {
                    locationCountByProdOp = await db.locationsByProdOps.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.BatchID).Select(
                        b => new
                        {
                            locationCount = b.Sum(c => c.locationCount),
                            batchId = b.FirstOrDefault().BatchID,
                        }).OrderByDescending(b => b.locationCount).ToListAsync();
                    //}
                    //else if (groupby == "lineofbusiness") {
                    //    locationCountByProdOp = await db.locationsByProdOps.Where(x => x.reportId == reportid && reportingBatches.Contains(x.BatchID)).GroupBy(x => x.lineOfbusiness).Select(
                    //        b => new 
                    //        {
                    //            locationCount = b.Sum(c => c.locationCount),
                    //            lineOfbusiness = b.FirstOrDefault().lineOfbusiness,
                    //        }).OrderByDescending(b => b.locationCount).ToListAsync();
                    //}

                }
            }
            catch (Exception ex)
            {
                return Ok(ex);
            }

            return Ok(locationCountByProdOp);
        }


        private Expression<Func<locationsByProdOp, string>> CreateGroupExpression(string groupby)
        {
            switch (groupby)
            {
                case "lineofbusiness":
                    return (x => x.lineOfbusiness);
                case "businessarea":
                    return (x => x.businessArea);
                case "batchid":
                    return x => x.BatchID;
                default:
                    return (x => x.businessArea);
            }

        }

        //reportId = 9 works for this
        [Route("api/reports/wrongcountry/{businessArea}/{reportid}")]
        [ResponseType(typeof(Object))]
        public async Task<IHttpActionResult> GetLocationsInWrongCountry(string businessArea, int reportid)
        {
            Object locationsInWrongCountry = null;

            if (businessArea.ToLower() == "global")
            {
                locationsInWrongCountry = await db.Locations_In_Wrong_Countries.Where(x => x.reportId == reportid).GroupBy(x => x.BatchID).Select(
                       b => new
                       {
                           batchDescription = b.FirstOrDefault().batchDescription,
                           batchId = b.FirstOrDefault().BatchID,
                           sumLocations = b.Count()
                       }
                       ).OrderByDescending(b => b.sumLocations).ToListAsync();
            }
            else
            {
                var reportingBatches = db.ReportingBatches.Where(x => x.BusinessAreaId == db.BusinessAreas.FirstOrDefault(y => y.Name == businessArea).Id).Select(b => b.BatchId).ToList();

                locationsInWrongCountry = await db.Locations_In_Wrong_Countries.Where(o => reportingBatches.Contains(o.BatchID) && o.reportId == reportid).GroupBy(o => o.BatchID).Select(
                        b => new
                        {
                            batchDescription = b.FirstOrDefault().batchDescription,
                            batchId = b.FirstOrDefault().BatchID,
                            sumLocations = b.Count()
                        }
                        ).OrderByDescending(b => b.sumLocations).ToListAsync();
            }

            return Ok(locationsInWrongCountry);
        }

        // PUT: api/Reports/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutReport(int id, Report report)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != report.reportId)
            {
                return BadRequest();
            }

            db.Entry(report).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ReportExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Reports
        [ResponseType(typeof(Report))]
        public async Task<IHttpActionResult> PostReport(Report report)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Reports.Add(report);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = report.reportId }, report);
        }

        // DELETE: api/Reports/5
        [ResponseType(typeof(Report))]
        public async Task<IHttpActionResult> DeleteReport(int id)
        {
            Report report = await db.Reports.FindAsync(id);
            if (report == null)
            {
                return NotFound();
            }

            db.Reports.Remove(report);
            await db.SaveChangesAsync();

            return Ok(report);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ReportExists(int id)
        {
            return db.Reports.Count(e => e.reportId == id) > 0;
        }

    }
}