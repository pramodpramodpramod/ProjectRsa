﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    public class AccellionUserController : ApiController
    {
        private readonly adminEntities _context;

        public AccellionUserController()
        {
            _context = new adminEntities();



        }

        [Route("api/accellion/users")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(List<AccellionUserDTO>))]
        public IHttpActionResult GetUsers()
        {
            try
            {
                var users = _context.AccellionUsers.ToList().Select(Mapper.Map<AccellionUserDTO>);
                return Ok(users);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to get users ", ex));
            }
        }

        [Route("api/accellion/user/view")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(AccellionUserDTO))]
        public IHttpActionResult GetUserDetails(string userId)
        {
            try
            {
                AccellionUser user = _context.AccellionUsers.FirstOrDefault(u => u.UserId == userId);
                if (user == null)
                {
                    return NotFound();
                }

                return Ok(Mapper.Map<AccellionUserDTO>(user));
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return InternalServerError(new Exception("Unable to find details about user " + userId, ex));
            }
        }

        [Route("api/accellion/user/create")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(string))]
        public IHttpActionResult CreateUser(AccellionUserDTO userDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = Mapper.Map<AccellionUser>(userDto);
            user.RegistrationDate = DateTime.Now;
            _context.AccellionUsers.Add(user);
            _context.SaveChanges();

            return Ok(user.UserId);
        }

        [Route("api/accellion/user/delete")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(string))]
        public IHttpActionResult DeleteUser(string userId)
        {
            try
            {
                AccellionUser userToDelete = _context.AccellionUsers.FirstOrDefault(u => u.UserId == userId);
                if (userToDelete == null)
                {
                    return NotFound();
                }

                _context.AccellionUsers.Remove(userToDelete);
                _context.SaveChanges();
                return Ok(userToDelete.UserId);
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return InternalServerError(new Exception("Unable to delete user " + userId, ex));
            }
        }

        [Route("api/accellion/user/update")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(string))]
        public IHttpActionResult UpdateUser(AccellionUserDTO userDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var user = _context.AccellionUsers.FirstOrDefault(u => u.UserId == userDto.UserId);
                user.FirstName = userDto.FirstName;
                user.LastName = userDto.LastName;
                user.Email = userDto.Email;
                user.ApproverEmail = userDto.ApproverEmail;
                user.UserProfile = userDto.UserProfile;
                user.UserType = userDto.UserType;
                _context.SaveChanges();
                return Ok(user.UserId);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to update user " + userDto.UserId, ex));
            }
        }
    }
}