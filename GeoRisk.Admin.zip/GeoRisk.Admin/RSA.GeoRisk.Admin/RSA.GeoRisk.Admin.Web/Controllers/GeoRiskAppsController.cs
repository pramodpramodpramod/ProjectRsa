﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class GeoRiskAppsController : ApiController
    {
        private geoRiskAppsEntities db = new geoRiskAppsEntities();

        [ResponseType(typeof(List<Notification>))]
        [Route("api/notification")]
        public IHttpActionResult GetNotifications(string appname, string userid, string version)
        {

            List<Notification> notifications;
            try
            {
                notifications = (from notification in db.Notifications
                                 where notification.App_AppId == db.Apps.Where(x => x.Name == appname).FirstOrDefault().AppId && (notification.Release == version || notification.Release == "") && !db.NotificationHistories.Where(n => n.UserId == userid).Select(nh => nh.Notification_NotificationId).Contains(notification.NotificationId)
                                 select notification).ToList();
            }
            catch
            {
                //registerError(ex, "Query for notifications to the GeoriskApps database failed.");
                return NotFound();
            }
            return Ok(notifications);
        }

        [Route("api/notification-history/post/")]
        public IHttpActionResult PostNotificationHistory(Newtonsoft.Json.Linq.JObject data)
        {
            try
            {
                NotificationHistory notificationHistory = data.ToObject<NotificationHistory>();
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                notificationHistory.Seen = DateTime.Now;
                db.NotificationHistories.Add(notificationHistory);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return NotFound();
            }

            return Ok("Inserted");
        }

        [System.Web.Http.AcceptVerbs("GET")]
        [ResponseType(typeof(List<ApplicationDTO>))]
        [Route("api/apps")]
        public IHttpActionResult GetApps()
        {
            try
            {
                var apps = db.Apps.ToList().Select(Mapper.Map<ApplicationDTO>);
                return Ok(apps);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        // GET: api/Apps/5
        //[RSA.GeoRisk.GeoRiskApps.API.Authorize(Roles ="User")]
        [ResponseType(typeof(App))]
        [Route("api/app/{name}")]
        public IHttpActionResult GetApp(string name)
        {
            App app = db.Apps.Where(b => b.Name == name).First();
            if (app == null)
            {
                return NotFound();
            }

            return Ok(app);
        }

        // GET: api/Maps
        [ResponseType(typeof(Map))]
        [Route("api/map/{id}")]
        public IHttpActionResult GetMaps(int id)
        {
            return Ok(db.Maps.Where(item => item.MapId == id).First());
        }

        #region other map stuff
        // GET: api/Maps/5
        [ResponseType(typeof(Map))]
        public IHttpActionResult GetMap(int id)
        {
            Map map = db.Maps.Find(id);
            if (map == null)
            {
                return NotFound();
            }

            return Ok(map);
        }

        // PUT: api/Maps/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutMap(int id, Map map)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != map.MapId)
            {
                return BadRequest();
            }

            db.Entry(map).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MapExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Maps
        [ResponseType(typeof(Map))]
        public IHttpActionResult PostMap(Map map)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Maps.Add(map);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (MapExists(map.MapId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = map.MapId }, map);
        }

        // DELETE: api/Maps/5
        [ResponseType(typeof(Map))]
        public IHttpActionResult DeleteMap(int id)
        {
            Map map = db.Maps.Find(id);
            if (map == null)
            {
                return NotFound();
            }

            db.Maps.Remove(map);
            db.SaveChanges();

            return Ok(map);
        }


        private bool MapExists(int id)
        {
            return db.Maps.Count(e => e.MapId == id) > 0;
        }
        #endregion

        [Authorize(Roles = "userEdit")]
        [Route("api/services")]
        [ResponseType(typeof(List<Service>))]
        public IHttpActionResult GetServices()
        {
            try
            {
                return Ok(db.Services.ToList());
            }
            catch { return NotFound(); }
        }

        // POST: api/Services
        // this is to create
        [Route("api/service/create/{appname}", Name = "CreateService")]
        [ResponseType(typeof(Service))]
        public async Task<IHttpActionResult> PostService(string appname, Service service)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                var app = db.Apps.Where(y => y.Name == appname).FirstOrDefault();
                service.Map_MapId = db.Maps.Where(x => x.MapId == app.AppId).FirstOrDefault().MapId;

                db.Services.Add(service);
                await db.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
            return Ok();
        }

        // DELETE: api/Services/5
        [Route("api/service/delete")]
        [ResponseType(typeof(Service))]
        [AcceptVerbs("GET")]
        public async Task<IHttpActionResult> DeleteService(int serviceId)
        {
            Service service = db.Services.FindAsync(serviceId).Result;
            if (service == null) { return NotFound(); }
            try
            {
                db.IndividualUserServices.RemoveRange(db.IndividualUserServices.Where(x => x.ServiceId == serviceId));
                var groupLincences = db.GroupLicences.Include("Services").ToList();

                foreach (var group in groupLincences)
                {
                    group.Services.Remove(service);
                }
                db.Services.Remove(service);
                await db.SaveChangesAsync();
            }
            catch (Exception e)
            {
                throw e;
            }
            return Ok();
        }

        // GET: api/Maps
        [AcceptVerbs("GET")]
        [Route("api/app/logexporttodatabase")]
        public IHttpActionResult LogExportToDatabase(string exportFileName)
        {
            db.LogExportToDatabase(exportFileName);
            return Ok();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        [ResponseType(typeof(List<BusinessType>))]
        [Route("api/businesstypes")]
        public IHttpActionResult GetBusinessTypes()
        {
            var results = db.BusinessTypes.ToList();
            return Ok(results);
        }

        #region BusinessTypes Extra Stuff

        // GET: api/BusinessTypes/5
        [ResponseType(typeof(BusinessType))]
        public IHttpActionResult GetBusinessType(int id)
        {
            BusinessType businessType = db.BusinessTypes.Find(id);
            if (businessType == null)
            {
                return NotFound();
            }

            return Ok(businessType);
        }

        // PUT: api/BusinessTypes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBusinessType(int id, BusinessType businessType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != businessType.BusinessTypeId)
            {
                return BadRequest();
            }

            db.Entry(businessType).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BusinessTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/BusinessTypes
        [ResponseType(typeof(BusinessType))]
        public IHttpActionResult PostBusinessType(BusinessType businessType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.BusinessTypes.Add(businessType);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = businessType.BusinessTypeId }, businessType);
        }

        // DELETE: api/BusinessTypes/5
        [ResponseType(typeof(BusinessType))]
        public IHttpActionResult DeleteBusinessType(int id)
        {
            BusinessType businessType = db.BusinessTypes.Find(id);
            if (businessType == null)
            {
                return NotFound();
            }

            db.BusinessTypes.Remove(businessType);
            db.SaveChanges();

            return Ok(businessType);
        }



        private bool BusinessTypeExists(int id)
        {
            return db.BusinessTypes.Count(e => e.BusinessTypeId == id) > 0;
        }

        #endregion

        [ResponseType(typeof(List<LeafletType>))]
        [Route("api/leaflettypes")]
        public IHttpActionResult GetLeafletTypes()
        {
            return Ok(db.LeafletTypes.ToList());
        }

        #region LeafletTypes Extra Stuff
        // GET: api/LeafletTypes/5
        [ResponseType(typeof(LeafletType))]
        public IHttpActionResult GetLeafletType(int id)
        {
            LeafletType leafletType = db.LeafletTypes.Find(id);
            if (leafletType == null)
            {
                return NotFound();
            }

            return Ok(leafletType);
        }

        // PUT: api/LeafletTypes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutLeafletType(int id, LeafletType leafletType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != leafletType.LeafletTypeId)
            {
                return BadRequest();
            }

            db.Entry(leafletType).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LeafletTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/LeafletTypes
        [ResponseType(typeof(LeafletType))]
        public IHttpActionResult PostLeafletType(LeafletType leafletType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.LeafletTypes.Add(leafletType);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = leafletType.LeafletTypeId }, leafletType);
        }

        // DELETE: api/LeafletTypes/5
        [ResponseType(typeof(LeafletType))]
        public IHttpActionResult DeleteLeafletType(int id)
        {
            LeafletType leafletType = db.LeafletTypes.Find(id);
            if (leafletType == null)
            {
                return NotFound();
            }

            db.LeafletTypes.Remove(leafletType);
            db.SaveChanges();

            return Ok(leafletType);
        }



        private bool LeafletTypeExists(int id)
        {
            return db.LeafletTypes.Count(e => e.LeafletTypeId == id) > 0;
        }

        #endregion

        [ResponseType(typeof(List<BaseMapStyle>))]
        [Route("api/basemapstyles")]
        public IHttpActionResult GetBaseMapStyles()
        {
            return Ok(db.BaseMapStyles.ToList());
        }

        #region BaseMapStyles Extra Stuff

        // GET: api/BaseMapStyles/5
        [ResponseType(typeof(BaseMapStyle))]
        public IHttpActionResult GetBaseMapStyle(int id)
        {
            BaseMapStyle baseMapStyle = db.BaseMapStyles.Find(id);
            if (baseMapStyle == null)
            {
                return NotFound();
            }

            return Ok(baseMapStyle);
        }

        // PUT: api/BaseMapStyles/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBaseMapStyle(int id, BaseMapStyle baseMapStyle)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != baseMapStyle.BaseMapStyleId)
            {
                return BadRequest();
            }

            db.Entry(baseMapStyle).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BaseMapStyleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/BaseMapStyles
        [ResponseType(typeof(BaseMapStyle))]
        public IHttpActionResult PostBaseMapStyle(BaseMapStyle baseMapStyle)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.BaseMapStyles.Add(baseMapStyle);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = baseMapStyle.BaseMapStyleId }, baseMapStyle);
        }

        // DELETE: api/BaseMapStyles/5
        [ResponseType(typeof(BaseMapStyle))]
        public IHttpActionResult DeleteBaseMapStyle(int id)
        {
            BaseMapStyle baseMapStyle = db.BaseMapStyles.Find(id);
            if (baseMapStyle == null)
            {
                return NotFound();
            }

            db.BaseMapStyles.Remove(baseMapStyle);
            db.SaveChanges();

            return Ok(baseMapStyle);
        }

        private bool BaseMapStyleExists(int id)
        {
            return db.BaseMapStyles.Count(e => e.BaseMapStyleId == id) > 0;
        }

        #endregion

        [ResponseType(typeof(List<MapServiceType>))]
        [Route("api/mapservicetypes")]
        public IHttpActionResult GetMapServiceTypes()
        {
            return Ok(db.MapServiceTypes.ToList());
        }

        #region MapServiceTypes Extra Stuff

        // GET: api/MapServiceTypes/5
        [ResponseType(typeof(MapServiceType))]
        public IHttpActionResult GetMapServiceType(int id)
        {
            MapServiceType mapServiceType = db.MapServiceTypes.Find(id);
            if (mapServiceType == null)
            {
                return NotFound();
            }

            return Ok(mapServiceType);
        }

        // PUT: api/MapServiceTypes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutMapServiceType(int id, MapServiceType mapServiceType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != mapServiceType.MapServiceTypeId)
            {
                return BadRequest();
            }

            db.Entry(mapServiceType).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MapServiceTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/MapServiceTypes
        [ResponseType(typeof(MapServiceType))]
        public IHttpActionResult PostMapServiceType(MapServiceType mapServiceType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.MapServiceTypes.Add(mapServiceType);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = mapServiceType.MapServiceTypeId }, mapServiceType);
        }

        // DELETE: api/MapServiceTypes/5
        [ResponseType(typeof(MapServiceType))]
        public IHttpActionResult DeleteMapServiceType(int id)
        {
            MapServiceType mapServiceType = db.MapServiceTypes.Find(id);
            if (mapServiceType == null)
            {
                return NotFound();
            }

            db.MapServiceTypes.Remove(mapServiceType);
            db.SaveChanges();

            return Ok(mapServiceType);
        }

        private bool MapServiceTypeExists(int id)
        {
            return db.MapServiceTypes.Count(e => e.MapServiceTypeId == id) > 0;
        }

        #endregion


        [ResponseType(typeof(List<ServiceType>))]
        [Route("api/servicetypes")]
        public IHttpActionResult GetServiceTypes()
        {
            return Ok(db.ServiceTypes.ToList());
        }

        #region serviceTypes stuff

        // GET: api/ServiceTypes/5
        [ResponseType(typeof(ServiceType))]
        public IHttpActionResult GetServiceType(int id)
        {
            ServiceType serviceType = db.ServiceTypes.Find(id);
            if (serviceType == null)
            {
                return NotFound();
            }

            return Ok(serviceType);
        }

        // PUT: api/ServiceTypes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutServiceType(int id, ServiceType serviceType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != serviceType.ServiceTypeId)
            {
                return BadRequest();
            }

            db.Entry(serviceType).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ServiceTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ServiceTypes
        [ResponseType(typeof(ServiceType))]
        public IHttpActionResult PostServiceType(ServiceType serviceType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ServiceTypes.Add(serviceType);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = serviceType.ServiceTypeId }, serviceType);
        }

        // DELETE: api/ServiceTypes/5
        [ResponseType(typeof(ServiceType))]
        public IHttpActionResult DeleteServiceType(int id)
        {
            ServiceType serviceType = db.ServiceTypes.Find(id);
            if (serviceType == null)
            {
                return NotFound();
            }

            db.ServiceTypes.Remove(serviceType);
            db.SaveChanges();

            return Ok(serviceType);
        }



        private bool ServiceTypeExists(int id)
        {
            return db.ServiceTypes.Count(e => e.ServiceTypeId == id) > 0;
        }

        #endregion

        #region LogRecords

        [System.Web.Http.AcceptVerbs("GET")]
        [ResponseType(typeof(List<LogsDTO>))]
        [Route("api/apps/Logs")]
        public IHttpActionResult GetLogs()
        {
            try
            {
                var minDate = DateTime.Now.AddMonths(-6);
                var logs = db.Logs.Where(x => x.Date > minDate).ToList().Select(Mapper.Map<LogsDTO>);
                return Ok(logs);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        #endregion
    }
}
