﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Description;
using AutoMapper;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Mapping.Enums;
using RSA.GeoRisk.Admin.Web.Models;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class DataLicenceController : ApiController
    {
        private geoRiskAppsEntities geoRiskAppsEntities;
        private adminEntities adminDb;

        public DataLicenceController()
        {
            var formatters = GlobalConfiguration.Configuration.Formatters;
            var jsonFormatter = formatters.JsonFormatter;
            var settings = jsonFormatter.SerializerSettings;
            settings.Formatting = Formatting.Indented;
            settings.ContractResolver = new CamelCasePropertyNamesContractResolver();

            geoRiskAppsEntities = new geoRiskAppsEntities();
            adminDb = new adminEntities();
        }



        [Route("api/licence/group")]
        [ResponseType(typeof(List<GroupLicenceDTO>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetGroupLicence()
        {
            try
            {

                var groupList = geoRiskAppsEntities.GroupLicences.ToList().Select(x => Mapper.Map<GroupLicenceDTO>(x)).ToList();

                var userGuids = groupList.Select(x => x.UserGuids);
                List<UserDTO> usero = new List<UserDTO>();

                List<GroupLicenceDTO> groupLicenceDTOsList = new List<GroupLicenceDTO>();
                int count = 0;
                foreach (var data in userGuids)
                {
                    count++;
                   
                    List<UserDTO> user = new List<UserDTO>();
                    foreach (var res in data)
                    {
                        usero = Mapper.Map<List<UserDTO>>(adminDb.aspnet_Users.Where(a => a.UserId.Equals(res)));
                        user.AddRange(usero);

                    }
                    GroupLicenceDTO groupLicenceDTO = new GroupLicenceDTO
                    {
                        Id = groupList[count - 1].Id,
                        Name = groupList[count - 1].Name,
                        IsActive = groupList[count - 1].IsActive,
                        RegistrationDate = groupList[count - 1].RegistrationDate,
                        ModifyDate = groupList[count - 1].ModifyDate,
                        ModifyBy = groupList[count - 1].ModifyBy,
                        Services = groupList[count - 1].Services,
                        UserGuids = groupList[count - 1].UserGuids,
                        UsersCount = groupList[count - 1].UsersCount,
                        Users = user,
                    };
                    groupLicenceDTOsList.Add(groupLicenceDTO);
                }




                return Ok(groupLicenceDTOsList);


            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to get GroupLicence from Db", e));
            }

        }


        [Route("api/licence/service")]
        [ResponseType(typeof(List<ServiceResponse>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetLicenceServicesByServiceType(LicenceTypeEnum licenceType)
        {
            try
            {
                var licenceServices = geoRiskAppsEntities.Services
               .Where(s => s.LicenceType == (int)licenceType)
               .Select(s => new ServiceResponse
               {
                   ArcGisServiceLayerName = s.ArcGisServiceLayerName,
                   BusinessType = s.BusinessType.Name,
                   Name = s.Name,
                   NameSearch = s.Name + " (" + s.Map.Name.Replace("Map", "") + ")",
                   application = s.Map.Name.Replace("Map", ""),
                   usersCount = s.IndividualUserServices.Count,
                   ServiceId = s.ServiceId,
                   ServiceType = s.ServiceType.Name
               })
               .ToList();
                return Ok(licenceServices);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to get services from Db", e));
            }

        }

        [Route("api/licence/group/view")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(GroupLicenceDTO))]
        public IHttpActionResult GetGroupLicenceDetails(int groupLicenceId)
        {
            try
            {
                GroupLicence groupLicence =
                    geoRiskAppsEntities.GroupLicences.Include(x => x.GroupLicenceUsers).FirstOrDefault(x => x.Id == groupLicenceId);

                if (groupLicence == null) { return NotFound(); }

                var userGuids = groupLicence.GroupLicenceUsers.Select(x => x.UserId);
                var userDtos = Mapper.Map<List<UserDTO>>(adminDb.aspnet_Users.Where(x => userGuids.Contains(x.UserId)));
                var groupLicenceDto = Mapper.Map<GroupLicenceDTO>(groupLicence);
                groupLicenceDto.Users = userDtos;
                return Ok(groupLicenceDto);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to find details about Group Licence " + groupLicenceId, ex));
            }
        }

        [Route("api/licence/group/create")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("POST")]
        public IHttpActionResult CreateGroupLicence(GroupLicenceDTO groupLicence)
        {
            try
            {
                GroupLicence gl = new GroupLicence();
                gl = Mapper.Map<GroupLicence>(groupLicence);
                gl.RegistrationDate = DateTime.Now;
                var addedGroupLicence = geoRiskAppsEntities.GroupLicences.Add(gl);
                geoRiskAppsEntities.SaveChanges();
                return Ok(Mapper.Map<GroupLicenceDTO>(addedGroupLicence));
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to Create Group Licence " + groupLicence.Id, ex));
            }

        }

        [Route("api/licence/group/addusers")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("POST")]
        public IHttpActionResult AddUsersToGroup(GroupLincenceUserServiceDTO groupLincence)
        {
            var userToAdd = new List<GroupLicenceUser>();
            try
            {
                var groupLicence = geoRiskAppsEntities.GroupLicences.FirstOrDefault(x => x.Id == groupLincence.GroupId);
                var usersToAdd = adminDb.aspnet_Users.Where(x => groupLincence.Users.Contains(x.UserId));

                foreach (var usr in usersToAdd)
                {
                    userToAdd.Add(new GroupLicenceUser { GroupLicenceId = groupLincence.GroupId, GroupLicenceName = groupLicence.Name, UserId = usr.UserId, UserName = usr.UserName });
                }
                geoRiskAppsEntities.GroupLicenceUsers.AddRange(userToAdd);
                geoRiskAppsEntities.SaveChanges();

                var addedUsersGuids = userToAdd.Select(x => x.UserId);

                return Ok(addedUsersGuids);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to add user to this group", ex));
            }
        }

        [Route("api/licence/group/addservice")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("POST")]
        public IHttpActionResult AddServiceToGroup(GroupLincenceUserServiceDTO groupLincence)
        {
            try
            {
                var groupLicence = geoRiskAppsEntities.GroupLicences.Include("Services").FirstOrDefault(x => x.Id == groupLincence.GroupId);

                var servicesToAdd = geoRiskAppsEntities.Services.Where(s => groupLincence.Services.Contains(s.ServiceId)).ToList();

                foreach (var s in servicesToAdd)
                {
                    groupLicence.Services.Add(s);
                }
                geoRiskAppsEntities.SaveChanges();

                return Ok(Mapper.Map<List<ServiceDropdownDTO>>(servicesToAdd.ToList()));
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to Add Services to this group", ex));
            }
        }

        [Route("api/licence/group/savesettings")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("POST")]
        public IHttpActionResult saveGroupLicenceSettings(GroupLicenceDTO groupLicencedto)
        {
            try
            {
                var grouplicence = geoRiskAppsEntities.GroupLicences.FirstOrDefault(x => x.Id == groupLicencedto.Id);
                grouplicence.IsActive = groupLicencedto.IsActive;
                grouplicence.Name = groupLicencedto.Name;
                grouplicence.ModifyDate = DateTime.Now;
                grouplicence.ModifyBy = User.Identity.Name.ToLower();
                geoRiskAppsEntities.SaveChanges();
                return Ok(Mapper.Map<GroupLicenceDTO>(grouplicence));
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to Create Group Licence " + groupLicencedto.Name, ex));
            }
        }

        [Route("api/licence/individual/addusers")]
        [Authorize(Roles = "Administrator, Manager Local, Manager Portfolio")]
        [AcceptVerbs("POST")]
        public IHttpActionResult addUsersForService(UserForServiceDTO userForService)
        {
            try
            {
                List<IndividualUserService> ufs = new List<IndividualUserService>();
                foreach (var u in userForService.Users)
                {
                    ufs.Add(new IndividualUserService
                    {
                        ServiceId = int.Parse(userForService.ServiceId),
                        UserId = Guid.Parse(u.UserId),
                        ServiceName = userForService.ServiceName,
                        UserName = u.UserName
                    });
                }
                geoRiskAppsEntities.IndividualUserServices.AddRange(ufs);
                geoRiskAppsEntities.SaveChanges();
                return Ok(ufs);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to Add User to Licence withe id " + userForService.ServiceId, ex));
            }

        }
        [Route("api/licence/individual/user/delete")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(string))]
        public IHttpActionResult DeleteIndividualLicenceUser(string Id, int serviceId)
        {
            try
            {
                var userId = Guid.Parse(Id);
                IndividualUserService userToDelete =
                    geoRiskAppsEntities.IndividualUserServices.FirstOrDefault(u => u.UserId == userId && u.ServiceId == serviceId);

                if (userToDelete == null) { return NotFound(); }

                geoRiskAppsEntities.IndividualUserServices.Remove(userToDelete);
                geoRiskAppsEntities.SaveChanges();
                return Ok(userToDelete.UserName);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to delete Group Licence " + Id, ex));
            }
        }


        [Route("api/licence/group/delete")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(string))]
        public IHttpActionResult DeleteGroupLicence(int Id)
        {
            try
            {
                var grouplicenceToDelete = geoRiskAppsEntities.GroupLicences.Include("Services").FirstOrDefault(u => u.Id == Id);

                IEnumerable<GroupLicenceUser> grouplicenceUserToDelete = geoRiskAppsEntities.GroupLicenceUsers.Where(u => u.GroupLicenceId == Id);

                if (grouplicenceToDelete == null) { return NotFound(); }

                geoRiskAppsEntities.GroupLicenceUsers.RemoveRange(grouplicenceUserToDelete);
                geoRiskAppsEntities.GroupLicences.Remove(grouplicenceToDelete);
                geoRiskAppsEntities.SaveChanges();

                return Ok(grouplicenceToDelete.Name);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to delete Group Licence " + Id, ex));
            }
        }

        [Route("api/licence/group/deleteservice")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(string))]
        public IHttpActionResult DeleteServiceFromGroupLicence(GroupLincenceUserServiceDTO groupLincence)
        {
            try
            {
                GroupLicence grouplicenceServiceToDelete =
                    geoRiskAppsEntities.GroupLicences.FirstOrDefault(u => u.Id == groupLincence.GroupId);

                if (grouplicenceServiceToDelete == null) { return NotFound(); }

                var serviceToDelete = geoRiskAppsEntities.Services.FirstOrDefault(x => x.ServiceId == groupLincence.Services.FirstOrDefault());
                grouplicenceServiceToDelete.Services.Remove(serviceToDelete);

                geoRiskAppsEntities.SaveChanges();

                return Ok(true);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to delete service from group licence", ex));
            }
        }

        [Route("api/licence/group/deleteuser")]
        [AcceptVerbs("POST")]
        [ResponseType(typeof(string))]
        public IHttpActionResult DeleteUserFromGroupLicence(GroupLincenceUserServiceDTO groupLincence)
        {
            try
            {
                GroupLicence grouplicenceUserToDelete =
                    geoRiskAppsEntities.GroupLicences.FirstOrDefault(u => u.Id == groupLincence.GroupId);

                if (grouplicenceUserToDelete == null) { return NotFound(); }

                var userDelete = geoRiskAppsEntities.GroupLicenceUsers.FirstOrDefault(x =>
                          x.UserId == groupLincence.Users.FirstOrDefault() && x.GroupLicenceId == groupLincence.GroupId);
                grouplicenceUserToDelete.GroupLicenceUsers.Remove(userDelete);

                geoRiskAppsEntities.SaveChanges();
                return Ok(true);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to delete user from group licence", ex));
            }
        }


        [Route("api/licence/individual/usersforservice")]
        [AcceptVerbs("GET")]
        [ResponseType(typeof(List<UserDTO>))]
        public IHttpActionResult GetIndividualUsersForService(int serviceId)
        {
            try
            {
                var userGuids = geoRiskAppsEntities.IndividualUserServices.Where(u => u.ServiceId == serviceId).Select(x => x.UserId).ToList();
                List<UserDTO> individualUsersForService = Mapper.Map<List<UserDTO>>(adminDb.aspnet_Users.Where(x => userGuids.Contains(x.UserId)));
                return Ok(individualUsersForService);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception("Unable to get individual users for service: " + serviceId, ex));
            }
        }

        [Route("api/licence/allusersforautocomplete")]
        [ResponseType(typeof(List<UserDTO>))]
        [AcceptVerbs("GET")]
        public IHttpActionResult GetAllUsers(int? licenceId, LicenceTypeEnum type)
        {
            try
            {
                var applicationUsers = adminDb.aspnet_Users
                    .Select(u => new UserDTO
                    {
                        UserId = u.UserId.ToString(),
                        UserName = u.UserName,
                        LoweredUserName = u.LoweredUserName,
                        FullNameSearch = u.UserName + " " + u.FirstName + " " + u.LastName,
                        FirstName = u.FirstName,
                        LastName = u.LastName,
                        Email = u.Email,
                        ApproverEmail = u.ApproverEmail,
                    }).ToList().GroupBy(i => i.LoweredUserName, (key, group) => group.First()).ToList();

                return Ok(applicationUsers);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to find users  ", e));
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                geoRiskAppsEntities.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
