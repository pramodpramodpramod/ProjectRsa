﻿using System;
using System.Configuration;
using System.Net;
using System.Web.Http;
using RSA.GeoRisk.Admin.Web.Code.Entities;
using System.Web.Http.Description;
using System.Threading.Tasks;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Services.Email;
using RSA.GeoRisk.Admin.Web.Models;
using System.Linq;

namespace RSA.GeoRisk.Admin.Web.Controllers
{
    [Authorize]
    public class EmailController : ApiController
    {
        private readonly adminEntities _adminEntitiesContext;
        private readonly EmailService _emailService;

        public EmailController()
        {
            _adminEntitiesContext = new adminEntities();
            _emailService = new EmailService();
        }

        [System.Web.Http.Route("api/email/send")]
        [ResponseType(typeof(Object))]
        [System.Web.Http.HttpPost]
        public async Task<IHttpActionResult> SendEmail(string applicationName, [FromBody] User user)
        {
            string blackListedMails = ConfigurationManager.AppSettings["BlacklistedMails"];

            var emailSettings = _adminEntitiesContext.EmailSettings.FirstOrDefault(x => x.ApplicationName == applicationName);
            var emailParameters = new EmailParameters
            {
                ApplicationName = applicationName,
                Sender = "georisk.enquiry@uk.rsagroup.com",
                Recipient = user.email,
                CcRecipient = user.approverEmail,
                CreatedUsername = user.userName,
                EmailContent = emailSettings.EmailContent,
                EmailSubejct = emailSettings.EmailSubject
            };
            IEmailService emailService = new SendGridEmailService();

            try
            {

                if (string.IsNullOrEmpty(blackListedMails))
                {
                    await emailService.SendEmailAsync(emailParameters);
                }
                else if (blackListedMails != null && !blackListedMails.Split(';').Contains(user.approverEmail))
                {
                    await emailService.SendEmailAsync(emailParameters);
                }

                return Ok(HttpStatusCode.OK);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to send email", e));
            }
        }


        [System.Web.Http.Route("api/email/saveemailsettings")]
        [ResponseType(typeof(Object))]
        [System.Web.Http.HttpPost]
        public IHttpActionResult SaveEmailSettings(EmailSettingsDTO emailSettings)
        {
            try
            {
                _emailService.SaveEmailSettings(emailSettings);
                return Ok(HttpStatusCode.OK);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to save email settings", e));
            }
        }

        [System.Web.Http.Route("api/email/getemailsettings")]
        [ResponseType(typeof(EmailSettingsDTO))]
        [System.Web.Http.HttpGet]
        public IHttpActionResult GetEmailSettings(string appName)
        {
            try
            {
                var result = _emailService.GetEmailSettings(appName);
                return Ok(result);
            }
            catch (Exception e)
            {
                return Ok(new Exception("Unable to get email settings", e));
            }
        }
    }
}
