﻿
using RSA.GeoRisk.Admin.Web.Models;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System;
using RSA.GeoRisk.Admin.Web.Directory;
using System.Threading.Tasks;
using RSA.GeoRisk.Admin.Web.Services.Email;
using RSA.GeoRisk.Admin.Web.Persistence;
using RSA.GeoRisk.Admin.Web.DTOs;
using System.Collections.Generic;
using System.Configuration;

namespace RSA.GeoRisk.Admin.Web.Services
{
    public class ScheduleService
    {
        private readonly adminEntities _adminEntitiesContext;
        private readonly IActiveDirectoryScanner _activeDirectoryScanner;
        private readonly IEmailService _emailService;
        private readonly IAuditUsersRepository _auditUsersRepository;

        public ScheduleService()
        {
            _adminEntitiesContext = new adminEntities();
            _activeDirectoryScanner = new ActiveDirectoryScanner();
            _emailService = new SendGridEmailService();
            _auditUsersRepository = new AuditUsersRepository(_adminEntitiesContext);
        }

        public void AutomatedUserCleanUp()
        {

            try
            {
                if (ConfigurationManager.AppSettings["AutomatedUserCleanUpCronExpression"] != null)
                {
                    var users = _adminEntitiesContext.aspnet_Users.Where(u => u.aspnet_Applications.ApplicationName == "local-ii" || u.aspnet_Applications.ApplicationName == "portfolio").ToList();
                    var active_users = users.Where(x => x.IsActive == true).ToList();
                    var suspended_users = users.Where(x => x.IsActive == false).ToList();
                    List<aspnet_Users> activeUsersNotInAD = new List<aspnet_Users>();
                    List<aspnet_Users> activeToSuspenedUsers = new List<aspnet_Users>();
                    List<aspnet_Users> archiveSuspendedUsers = new List<aspnet_Users>();


                    foreach (var user in active_users)
                    {
                        var searchNameOrEmail = user.LoweredUserName;
                        var emailExist = _activeDirectoryScanner.GetActiveDirectoryUser(searchNameOrEmail.Trim());
                        if (emailExist.Data == null && emailExist.Message.Contains("There is no user found with this user id."))
                        {
                            user.IsActive = false;
                            user.LastSuspendedDate = DateTime.Now;
                            user.SuspendedBy = "AutomatedJob - Don't exists in AD";
                            user.ActivatedBy = null;
                            user.ActivatedByDate = null;
                            activeUsersNotInAD.Add(user);

                        }

                        else if (emailExist.Data == null && emailExist.Message.Contains("The server is not operational."))
                        {
                            NotificationEmailforInactiveAD();
                        }                                              
                    }

                    foreach (var susUser in suspended_users)
                    {
                        if (susUser.LastSuspendedDate != null) // Null check added on 6/24/2020
                        {
                            if (susUser.LastSuspendedDate.Value < DateTime.Now.AddMonths(-6))
                            {
                                AchiveSuspendUsers(susUser);
                                archiveSuspendedUsers.Add(susUser);
                            }
                        }
                    }
                     
                    _adminEntitiesContext.SaveChanges();

                    UsersActivityCheck(active_users.Where(x => x.IsActive).ToList(), activeToSuspenedUsers);

                    AutomatedUserCleanUpNotificatiopEmail(activeUsersNotInAD, archiveSuspendedUsers, activeToSuspenedUsers);

                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        public void UsersActivityCheck(List<aspnet_Users> users, List<aspnet_Users> activeToSuspenedUsers)
        {            
            try { 
            foreach (var u in users)
            {
                if (u.RegistrationDate.HasValue && u.RegistrationDate.Value <= DateTime.Now.AddDays(-14) &&
                    u.LastActivityDate == null && u.IsActive && !u.ActivatedByDate.HasValue)
                {
                    u.IsActive = false;
                    u.LastSuspendedDate = DateTime.Now;
                    u.SuspendedBy = "AutomatedJob - 14 days grace period";
                    activeToSuspenedUsers.Add(u);
                }
                else if (u.RegistrationDate.HasValue && u.RegistrationDate.Value <= DateTime.Now.AddDays(-14) &&
                    u.LastActivityDate == null && u.IsActive && u.ActivatedByDate.HasValue && u.ActivatedByDate.Value <= DateTime.Now.AddDays(-14))
                {
                    u.IsActive = false;
                    u.LastSuspendedDate = DateTime.Now;
                    u.SuspendedBy = "AutomatedJob - 14 days grace period";
                    u.ActivatedBy = null;
                    u.ActivatedByDate = null;
                    activeToSuspenedUsers.Add(u);
                }
                else if (u.LastActivityDate.HasValue && u.LastActivityDate.Value < DateTime.Now.AddDays(-104) &&
                         u.IsActive && !u.ActivatedByDate.HasValue)
                {
                    u.IsActive = false;
                    u.LastSuspendedDate = DateTime.Now;
                    u.SuspendedBy = "AutomatedJob - 100 days of inactivity";
                    activeToSuspenedUsers.Add(u);
                }
                else if (u.LastActivityDate.HasValue && u.LastActivityDate.Value < DateTime.Now.AddDays(-104) && u.IsActive &&
                    u.ActivatedByDate.HasValue && u.ActivatedByDate.Value <= DateTime.Now.AddDays(-14))
                {
                    u.IsActive = false;
                    u.LastSuspendedDate = DateTime.Now;
                    u.SuspendedBy = "AutomatedJob - 100 days of inactivity";
                    u.ActivatedBy = null;
                    u.ActivatedByDate = null;
                    activeToSuspenedUsers.Add(u);
                }
                //Notification email will be sended
                else if (u.LastActivityDate.HasValue && u.LastActivityDate.Value <= DateTime.Now.AddDays(-90) && (!u.IsNotified.HasValue || !u.IsNotified.Value))
                {
                    NotificationEmailforInactiveUsers(u);
                    u.IsNotified = true;
                }
            }
            _adminEntitiesContext.SaveChanges();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void AutomatedUserCleanUpNotificatiopEmail(List<aspnet_Users> usersNotInAD, List<aspnet_Users> archiveSuspendedUsers, List<aspnet_Users> activeToSuspenedUsers)
        {
            var emailParameters = new EmailParameters
            {
                Sender = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                Recipient = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                EmailContent = "",
                EmailSubejct = "Automated User Clean Up"
            };

            try
            {
                emailParameters.EmailContent = @"<style>table, th, td {
                                                  border: 1px solid black;
                                                }</style>
                                                <p><strong>Hello Georisk Admin</strong></p>
                                                <p></p>
                                                <p>Automation clean up Job has run successfuly </p>";
                if (usersNotInAD.Count > 0)
                {
                    emailParameters.EmailContent += @"<p>These are the users that are not in Active Directory:</p>";
                    emailParameters.EmailContent += @"<table>
                                                      <tr>
                                                        <th>User ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
	                                                    <th>last activity date</th>
                                                        <th>location</th>
                                                        <th>approver</th>
	                                                    <th>role</th>
                                                        <th>status was</th>
                                                        <th>status now</th>
                                                      </tr>";
                    foreach (var u in usersNotInAD)
                    {
                        emailParameters.EmailContent += "<tr>";
                        emailParameters.EmailContent += "<td>" + u.UserName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.FirstName + " " + u.LastName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.Email + "</td>";
                        //emailParameters.EmailContent += "<td>" + u.LastActivityDate.Value + "</td>";
                        if (u.LastActivityDate.HasValue)
                        { emailParameters.EmailContent += "<td>" + u.LastActivityDate.Value + "</td>"; }
                        else { emailParameters.EmailContent += "<td>" + u.LastActivityDate + "</td>"; }
                        emailParameters.EmailContent += "<td>" + u.Location + "</td>";
                        emailParameters.EmailContent += "<td>" + u.ApproverEmail + "</td>";
                        emailParameters.EmailContent += "<td>" + u.aspnet_Roles.FirstOrDefault()?.RoleName + "</td>";
                        emailParameters.EmailContent += "<td>True</td>";
                        emailParameters.EmailContent += "<td>" + u.IsActive + "</td>";
                        emailParameters.EmailContent += "</tr>";
                    }
                    emailParameters.EmailContent += "</table>";
                }
                else
                {
                    emailParameters.EmailContent += @" <p>All Active users were in Active Directory</p>";
                }

                if (archiveSuspendedUsers.Count > 0)
                {
                    emailParameters.EmailContent += @"<p>These are the users that were suspended for more then 6 months and moved to archive:</p>";
                    emailParameters.EmailContent += @"<table>
                                                      <tr>
                                                        <th>User ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
	                                                    <th>last activity date</th>
                                                        <th>location</th>
                                                        <th>Application Name</th>
                                                        <th>approver</th>
	                                                    <th>role</th>
                                                        <th>status</th>
                                                        <th>last suspended date</th>
                                                      </tr>";
                    foreach (var u in archiveSuspendedUsers)
                    {
                        emailParameters.EmailContent += " <tr>";
                        emailParameters.EmailContent += "<td>" + u.UserName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.FirstName + " " + u.LastName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.Email + "</td>";
                        // emailParameters.EmailContent += "<td>" + u.LastActivityDate.Value + "</td>";
                        if (u.LastActivityDate.HasValue)
                        { emailParameters.EmailContent += "<td>" + u.LastActivityDate.Value + "</td>"; }
                        else { emailParameters.EmailContent += "<td>" + u.LastActivityDate + "</td>"; }
                        emailParameters.EmailContent += "<td>" + u.Location + "</td>";
                        emailParameters.EmailContent += "<td>" + u.ApplicationName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.ApproverEmail + "</td>";
                        emailParameters.EmailContent += "<td>" + u.aspnet_Roles.FirstOrDefault()?.RoleName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.IsActive + "</td>";
                        emailParameters.EmailContent += "<td>" + u.LastSuspendedDate.Value + "</td>";
                        emailParameters.EmailContent += "<td>" + u.SuspendedBy + "</td>";
                        emailParameters.EmailContent += "</tr>";
                    }
                    emailParameters.EmailContent += "</table>";
                }
                else
                {
                    emailParameters.EmailContent += @"<p>No suspended users were moved to archive</p>";
                }

                if (activeToSuspenedUsers.Count > 0)
                {
                    emailParameters.EmailContent += @"<p>These are the users that were suspended:</p>";
                    emailParameters.EmailContent += @"<table>
                                                      <tr>
                                                        <th>User ID</th>
                                                        <th>Name</th>
                                                        <th>Email</th>
	                                                    <th>Last activity date</th>
                                                        <th>Location</th>
                                                        <th>Application Name</th>
                                                        <th>Approver</th>
	                                                    <th>Role</th>
                                                        <th>Status</th>
                                                        <th>Last suspended date</th>
                                                        <th>Suspended By</th>
                                                      </tr>";
                    foreach (var u in activeToSuspenedUsers)
                    {
                        emailParameters.EmailContent += " <tr>";
                        emailParameters.EmailContent += "<td>" + u.UserName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.FirstName + " " + u.LastName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.Email + "</td>";
                        if (u.LastActivityDate.HasValue)
                        { emailParameters.EmailContent += "<td>" + u.LastActivityDate.Value + "</td>"; }
                        else { emailParameters.EmailContent += "<td>" + u.LastActivityDate + "</td>"; }

                        emailParameters.EmailContent += "<td>" + u.Location + "</td>";
                        emailParameters.EmailContent += "<td>" + u.ApplicationName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.ApproverEmail + "</td>";
                        emailParameters.EmailContent += "<td>" + u.aspnet_Roles.FirstOrDefault()?.RoleName + "</td>";
                        emailParameters.EmailContent += "<td>" + u.IsActive + "</td>";
                        emailParameters.EmailContent += "<td>" + u.LastSuspendedDate.Value + "</td>";
                        emailParameters.EmailContent += "<td>" + u.SuspendedBy + "</td>";
                        emailParameters.EmailContent += "</tr>";
                    }
                    emailParameters.EmailContent += "</table>";
                }
                else
                {
                    emailParameters.EmailContent += @"<p>No suspended users</p>";
                }

                emailParameters.EmailContent += @"<p>Kind regards,&nbsp;</p>
                                                <p>GeoRisk Enquiry</p>";

                _emailService.SendEmailAsync(emailParameters);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void NotificationEmailforInactiveUsers(aspnet_Users user)
        {
            var emailParameters = new EmailParameters
            {
                Sender = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                Recipient = user.Email,
                CcRecipient = user.ApproverEmail,
                EmailContent = "",
                EmailSubejct = "GeoRisk - Your access will be suspended"
            };
            if (ConfigurationManager.AppSettings["NotificationTestConfiguration"] != null)
            {
                emailParameters = new EmailParameters
                {
                    Sender = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                    Recipient = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                    CcRecipient = ConfigurationManager.AppSettings["CCNotificationMail"],
                    EmailContent = "",
                    EmailSubejct = "GeoRisk - Your access will be suspended"
                };
            }


            try
            {
                emailParameters.EmailContent = "<p>Dear <strong>" + user.UserName + "</strong>";
                emailParameters.EmailContent += @"<p>You have not accessed the GeoRisk -" + user.ApplicationName.Replace("ii", "") + " application in the last 90 days.</p>";
                emailParameters.EmailContent += @"<p>If you continue to require access to this application please log in within the next week.</p>
                                                <p>If you fail to do so your account will be suspended.</p>

                                                <p>Kind regards,&nbsp;</p>
                                                <p>GeoRisk Enquiry</p>";
                _emailService.SendEmailAsync(emailParameters);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void NotificationEmailforInactiveAD()
        {
            try
            {
                var emailParameters = new EmailParameters
                {
                    Sender = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                    Recipient = ConfigurationManager.AppSettings["AutomatedUserCleanUpEmail"],
                    CcRecipient = ConfigurationManager.AppSettings["CCNotificationMail"],
                    // EmailContent = "",
                    EmailSubejct = "Auto clean up job unsuccessful "
                };
                emailParameters.EmailContent = @"<style>table, th, td {
                                                  border: 1px solid black;
                                                }</style>
                                                <p><strong>Hello Georisk Admin</strong></p>
                                                <p></p>
                                                <p> Unable to connect to Active Directory.Apps user clean up job did not run today.</p >
                                                <p>Kind regards,&nbsp;</p>
                                                <p>GeoRisk Enquiry</p>";            

                _emailService.SendEmailAsync(emailParameters);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void AchiveSuspendUsers(aspnet_Users user)
        {
            try
            {
                ObjectParameter numTablesDeletedFrom = new ObjectParameter("numTablesDeletedFrom", typeof(Int32));
                _adminEntitiesContext.aspnet_Users_DeleteUser(user.aspnet_Applications.ApplicationName, user.UserName, 15, numTablesDeletedFrom);

                var userAudit = AuditUserDto.FromUser(user);
                userAudit.ArchivedBy = "AutomatedJob";
                _auditUsersRepository.Add(userAudit);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}