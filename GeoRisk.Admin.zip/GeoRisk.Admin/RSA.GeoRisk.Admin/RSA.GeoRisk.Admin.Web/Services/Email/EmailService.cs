﻿using AutoMapper;
using RSA.GeoRisk.Admin.Web.DTOs;
using RSA.GeoRisk.Admin.Web.Models;
using System.Data.Entity.Migrations;
using System.Linq;

namespace RSA.GeoRisk.Admin.Web.Services.Email
{
    public class EmailService
    {
        private readonly adminEntities _adminEntitiesContext;

        public EmailService()
        {
            _adminEntitiesContext = new adminEntities();
        }

        public void SaveEmailSettings(EmailSettingsDTO settings)
        {
            _adminEntitiesContext.EmailSettings.AddOrUpdate(x => x.ApplicationName, Mapper.Map<EmailSetting>(settings));
            _adminEntitiesContext.SaveChanges();
        }

        public EmailSettingsDTO GetEmailSettings(string appName)
        {
            return Mapper.Map<EmailSettingsDTO>(_adminEntitiesContext.EmailSettings.FirstOrDefault(x => x.ApplicationName == appName));
        }
    }
}