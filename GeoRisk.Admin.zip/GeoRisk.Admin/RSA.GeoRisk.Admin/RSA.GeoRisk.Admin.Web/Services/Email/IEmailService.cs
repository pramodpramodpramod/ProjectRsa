﻿using System.Threading.Tasks;

namespace RSA.GeoRisk.Admin.Web.Services.Email
{
    interface IEmailService
    {
        Task SendEmailAsync(EmailParameters emailParameters);
    }
}
