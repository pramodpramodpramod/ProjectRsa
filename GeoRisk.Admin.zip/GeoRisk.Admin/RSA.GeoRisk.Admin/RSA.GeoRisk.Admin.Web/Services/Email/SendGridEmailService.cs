﻿using System.Net;
using System.Threading.Tasks;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace RSA.GeoRisk.Admin.Web.Services.Email
{
    public class SendGridEmailService : IEmailService
    {
        private readonly string _apiKey = "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";
        public async Task SendEmailAsync(EmailParameters emailParameters)
        {
            var proxy = new WebProxy("http://rsaproxy.uk.rsa-ins.com:8080") { UseDefaultCredentials = true };
            var client = new SendGridClient(proxy, _apiKey);
            var from = new EmailAddress(emailParameters.Sender);
            var to = new EmailAddress(emailParameters.Recipient, "Example User");
            var subject = CreateEmailSubject(emailParameters.CreatedUsername, emailParameters.EmailSubejct);
            var htmlContent = CreateEmailBody(emailParameters.ApplicationName, emailParameters.CreatedUsername, emailParameters.EmailContent);
            var msg = MailHelper.CreateSingleEmail(from, to, subject, null, htmlContent);
            if (!string.IsNullOrEmpty(emailParameters.CcRecipient) && emailParameters.CcRecipient != emailParameters.Recipient)
            {
                msg.AddCc(new EmailAddress(emailParameters.CcRecipient));
            }

            await client.SendEmailAsync(msg);
        }

        public string CreateEmailBody(string applicationName, string userName, string emailContent)
        {
            return emailContent.Replace("{user}", userName);
        }

        public string CreateEmailSubject(string userName, string emailSubject)
        {
            return emailSubject.Replace("{user}", userName);
        }
    }
}