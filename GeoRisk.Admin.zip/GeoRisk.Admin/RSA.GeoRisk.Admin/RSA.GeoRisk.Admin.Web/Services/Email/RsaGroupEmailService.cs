﻿using System.Net.Mail;
using System.Threading.Tasks;

namespace RSA.GeoRisk.Admin.Web.Services.Email
{
    public class RsaGroupEmailService : IEmailService
    {
        public async Task SendEmailAsync(EmailParameters emailParameters)
        {
            using (SmtpClient client = new SmtpClient("webmail.rsagroup.com", 25))
            {
                ConfigureSmtpClient(client);

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(emailParameters.Sender);
                mail.To.Add(new MailAddress(emailParameters.Recipient));
                mail.CC.Add(new MailAddress(emailParameters.CcRecipient));
                mail.Subject = CreateEmailSubject(emailParameters.CreatedUsername, emailParameters.EmailSubejct);
                mail.SubjectEncoding = System.Text.Encoding.UTF8;
                mail.Body = CreateEmailBody(emailParameters.ApplicationName, emailParameters.CreatedUsername, emailParameters.EmailContent);
                mail.BodyEncoding = System.Text.Encoding.UTF8;
                mail.IsBodyHtml = true;

                await client.SendMailAsync(mail);
            }
        }

        public string CreateEmailBody(string applicationName, string userName, string emailContent)
        {
            return emailContent.Replace("{user}", userName);
        }

        public string CreateEmailSubject(string userName, string emailSubject)
        {
            return emailSubject.Replace("{user}", userName);
        }

        private void ConfigureSmtpClient(SmtpClient smtpClient)
        {
            // smtpClient.Credentials = new NetworkCredential("", "");
            smtpClient.UseDefaultCredentials = true;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.EnableSsl = true;
        }
    }
}