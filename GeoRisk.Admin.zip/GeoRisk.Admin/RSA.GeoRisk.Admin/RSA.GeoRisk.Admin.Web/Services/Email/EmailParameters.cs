﻿namespace RSA.GeoRisk.Admin.Web.Services.Email
{
    public class EmailParameters
    {
        public string Sender { get; set; }
        public string Recipient { get; set; }
        public string CcRecipient { get; set; }
        public string ApplicationName { get; set; }
        public string CreatedUsername { get; set; }
        public string EmailContent { get; set; }
        public string EmailSubejct { get; set; }
    }
}