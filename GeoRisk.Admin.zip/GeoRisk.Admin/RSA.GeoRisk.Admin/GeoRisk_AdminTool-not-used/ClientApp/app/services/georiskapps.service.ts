﻿import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

import { App } from '../objects/georiskapps/app';
import { Service } from '../objects/georiskapps/service';
import { APPS } from '../mocks/mock-apps'

//injectable makes this class something that can be used in dependency injection
@Injectable()

export class GeoriskAppsService {

    constructor(private http: Http) { }

    private georiskappsUrl = 'http://localhost:53866/api';//;api/applications';  // URL to web api

    getApps(): Promise<App[]> {
        //return Promise.resolve(APPS);

        return this.http.get(this.georiskappsUrl+'/apps')
            .toPromise()
            //The response JSON has a single data property, which holds the array of APPS that the caller wants. So you grab that array and return it as the resolved Promise value.
            .then(response =>
                response.json() as App[]
            )
            .catch(this.handleError);
    }

    getAppServices(appName): Promise<Service[]> {
        return this.http.get(this.georiskappsUrl+ '/services/' + appName)
            .toPromise()
            //The response JSON has a single data property, which holds the array of APPS that the caller wants. So you grab that array and return it as the resolved Promise value.
            .then(response => response.json() as Service[])
            .catch(this.handleError);
    }

    getBusinessTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/businesstypes')
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    getBaseMapStyles(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/basemapstyles')
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    getLeafletTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/leaflettypes')
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    getMapServiceTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/mapservicetypes')
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    getServiceTypes(): Promise<any> {
        return this.http.get(this.georiskappsUrl + '/servicetypes')
            .toPromise()
            .then(response => response.json())
            .catch(this.handleError);
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error); // for demo purposes only
        return Promise.reject(error.message || error);
    }
}