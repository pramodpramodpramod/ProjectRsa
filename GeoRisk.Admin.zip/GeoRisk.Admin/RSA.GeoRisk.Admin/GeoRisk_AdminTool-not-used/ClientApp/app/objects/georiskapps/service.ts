﻿export class Service {
    arcGisServiceLayerName;
    attribution;
    baseMapStyle;
    businessType: { businessTypeId: Number, name: String };
    identify;
    isActive;
    isDefault;
    layers;
    leafletType: { leafletTypeId: Number, name: String };
    legendImage;
    legendImageUrl;
    mandated;
    mapId;
    mapServiceType: { mapServiceTypeId: Number, name: String };
    name;    
    opacity;
    regions;
    serviceId;
    serviceType: { serviceTypeId: Number, name: String };
    token;
    url;
    visible;
}