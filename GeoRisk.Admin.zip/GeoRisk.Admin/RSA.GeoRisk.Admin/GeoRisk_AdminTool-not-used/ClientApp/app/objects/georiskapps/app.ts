﻿import { Map } from './map';

export class App {
    appId: number;
    name: string;
    currencies: string;
    map: Map[];
}