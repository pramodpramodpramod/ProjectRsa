﻿import { Component, OnInit, Inject } from '@angular/core';
import { AdminService } from "../../services/admin.service";
import { ActivatedRoute, Router } from "@angular/router";
//import { ToastrService } from "../../services/service-barrel";


@Component({
    selector: 'admin',
    //providers: [AdminService],
    templateUrl: './admin.component.html'
    
})

export class AdminComponent implements OnInit {
        
    selectedUser: any;   

    editsMade: boolean = false;
    foundUserInAD: any;
    userAlreadyExistsInAdminDB: boolean;
    createUserMode: boolean = false;
    usersRoles: any;
    allRoles: any;
    users: any;
    newUsersRoles: any = [];
    newUserAllRoles: any = [];
    currentApp: string

    selectedAllRoles: any[]=[];
    selectedUsersRoles: any[]=[];
    selectedNewUserRoles:any[]=[]
    selectedNewAllRoles:any[]=[]

    //constructor(private adminService: AdminService, private activatedRoute: ActivatedRoute, private router: Router, private toastr: ToastrService) { }
    constructor(private adminService: AdminService, private activatedRoute: ActivatedRoute, private router: Router) { }

    ngOnInit(): void {
        this.currentApp = this.activatedRoute.snapshot.data['appName'];
        this.getUsers();
    }

    deleteUser() {
        
        this.adminService.deleteUser(this.selectedUser.UserName, this.currentApp).then(deleteResponse => {
            if (deleteResponse.ClassName = "System.Exception") {
                //this.toastr.error(deleteResponse.InnerException.InnerException.Message, deleteResponse.Message);
            }
            //let c = deleteResponse;
        });
    }

    createUser() {
        this.adminService.createUser(this.foundUserInAD.domainAccountName, this.currentApp).then(addUserResponse => {
            if (addUserResponse.ClassName = "System.Exception") {
                //this.toastr.error(addUserResponse.InnerException.InnerException.Message, addUserResponse.Message);
            }
            //let v = addUserResponse;
        });
    }
    

    getUsers(): void {

        this.adminService.getUsers(this.activatedRoute.snapshot.data['appName']).then(users =>
            this.users = users
        );
    }

    onUserSelected(selectedUser): void {

        this.getAllRolesForUser(selectedUser.UserName);
    }

    getAllRolesForUser(selectedUser: any): void {

        this.adminService.getRolesForUser(this.activatedRoute.snapshot.data['appName'], selectedUser).then(roles => {
            this.usersRoles = roles
            //this.getAllRolesForApplication(this.usersRoles)
            this.adminService.getAllRoles(this.activatedRoute.snapshot.data['appName']).then(roles => {
                this.allRoles = roles.filter(role => {
                    return this.usersRoles.findIndex(x => x.RoleName === role.RoleName) === -1;
                })
            });
        });
    }

    //getAllRolesForApplication(userRoles): void {
    //    //get all the roles for the application, and remove the ones that the user already belongs to
    //    this.adminService.getAllRoles(this.activatedRoute.snapshot.data['appName']).then(roles => {
    //        this.allRoles = roles.filter(role => {
    //            return userRoles.findIndex(x => x.RoleName === role.RoleName) === -1;
    //        })
    //    });
    //}

    searchForUser(windowsLogin): void {
        this.adminService.findUserInActiveDirectory(windowsLogin).then(user => {
            this.foundUserInAD = user;
            //this.getAllRolesForUser(this.foundUser.domainAccountName);
            this.checkIfUserExists(this.foundUserInAD.domainAccountName);
        })
    }

    checkIfUserExists(selectedUser: any): void {

        this.adminService.getRolesForUser(this.activatedRoute.snapshot.data['appName'], selectedUser).then(roles => {
            this.newUsersRoles = roles
            this.userAlreadyExistsInAdminDB = this.newUsersRoles.length > 0;
            //this.getAllRolesForApplication(this.newUsersRoles)
            this.adminService.getAllRoles(this.activatedRoute.snapshot.data['appName']).then(roles => {
                this.newUserAllRoles = roles.filter(role => {
                    return this.newUsersRoles.findIndex(x => x.RoleName === role.RoleName) === -1;
                })
            });
        });
    }

    selectionMoveCheck(element) {
        if (element.selected) {
            element.selected = false;
            return true;
        }
    }

    setSelected(roles, role) {
        let ind = roles.findIndex(x => x.RoleName === role);
        if (ind > -1) {
            roles[ind].selected = true;
        }
    }

    moveElements(source, target, moveCheck) {
        for (var i = 0; i < source.length; i++) {
            var element = source[i];
            if (moveCheck(element)) {
                this.editsMade = true;
                source.splice(i, 1);
                target.push(element);
                i--;
            }
        }
    }

    shiftRoles(source: any, target: any, roles: any) {

        if (roles && roles.length > 0){
            for (let role of roles) {
                this.setSelected(source, role)
                this.moveElements(source, target, this.selectionMoveCheck);
            }

            this.selectedNewUserRoles = [];
            this.selectedNewAllRoles = [];
            this.selectedUsersRoles = [];
            this.selectedAllRoles = [];
        }
        
    }
    cancelNewUserCreation() {
        this.createUserMode = false;
    }

    createNewUserMode() {
        this.createUserMode = true;
        this.foundUserInAD = {};
    }

    notReadyToCreate() {
        return this.newUsersRoles.length <= 0 
    }

    
       
}