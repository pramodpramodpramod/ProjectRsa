﻿import { Component, Input, OnInit} from "@angular/core";
import { Service } from "../../objects/georiskapps/service";
import { GeoriskAppsService } from "../../services/georiskapps.service";

@Component({
    selector: 'service-details',
    templateUrl: './app-service-detail.component.html',
    //providers: [GeoriskAppsService]
})

export class AppServiceDetailComponent implements OnInit {

    @Input() selectedService: Service
    businessTypes: any;
    baseMapStyles: any;
    leafletTypes: any;
    mapServiceTypes: any;
    serviceTypes: any;

    constructor(private georiskAppsService: GeoriskAppsService) { }

    ngOnInit(): void {
        this.getBusinessTypes();
        this.getBaseMapStyles();
        this.getLeafletTypes();
        this.getMapServiceTypes();
        this.getServiceTypes();
    }
    
    getBusinessTypes(): void {
        this.georiskAppsService.getBusinessTypes().then(businessTypes => {
            this.businessTypes = businessTypes;
        })
    }

    getBaseMapStyles(): void {
        this.georiskAppsService.getBaseMapStyles().then(baseMapStyles => {
            this.baseMapStyles = baseMapStyles
        })
    }

    getLeafletTypes(): void {
        this.georiskAppsService.getLeafletTypes().then(leafletTypes => {
            this.leafletTypes = leafletTypes;
        })
    }

    getMapServiceTypes(): void {
        this.georiskAppsService.getMapServiceTypes().then(mapServiceTypes => {
            this.mapServiceTypes = mapServiceTypes;
        })
    }

    getServiceTypes(): void {
        this.georiskAppsService.getServiceTypes().then(serviceTypes => {
            this.serviceTypes = serviceTypes;
        })
    }
}