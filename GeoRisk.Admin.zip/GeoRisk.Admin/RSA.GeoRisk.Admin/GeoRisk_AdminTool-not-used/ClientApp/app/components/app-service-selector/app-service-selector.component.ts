﻿import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Service } from "../../objects/georiskapps/service";

@Component({
    selector: 'service-selector',
    templateUrl: './app-service-selector.component.html',
    styles: [`
        .service-selector-margin{margin-top:20px; margin-bottom:20px}
    `]
})

export class AppServiceSelectorComponent {

    @Output() serviceSelected = new EventEmitter<Service>();
    @Input() services: Service[];
    //selectedService: any;

    onServiceSelected(service: Service) {
        this.serviceSelected.emit(service);
    }
}
