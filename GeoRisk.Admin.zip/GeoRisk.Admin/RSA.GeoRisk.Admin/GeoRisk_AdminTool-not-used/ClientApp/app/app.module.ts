import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
//import { HttpModule } from '@angular/http';
import { UniversalModule } from 'angular2-universal';

import { AppComponent } from './components/app/app.component'
import { NavMenuComponent } from './components/navmenu/navmenu.component';
import { HomeComponent } from './components/home/home.component';

import { LocalComponent } from './components/local/local.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { AdminComponent } from './components/admin/admin.component';
import { AppServicesComponent } from './components/app-services/app-services.component';
import { AppServiceSelectorComponent } from "./components/app-service-selector/app-service-selector.component";
import { AppServiceDetailComponent } from "./components/app-service-details/app-service-detail.component";
import { AdminService, GeoriskAppsService } from "./services/service-barrel"
//import { ToasterModule, ToasterService } from 'angular2-toaster';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { ToastrModule } from 'ngx-toastr';





//the backend security stuff will most likely follow this
//http://bitoftech.net/2015/01/21/asp-net-identity-2-with-asp-net-web-api-2-accounts-management/
//https://www.asp.net/identity

//this project is based on this scaffolding tool
//https://blogs.msdn.microsoft.com/webdev/2017/02/14/building-single-page-applications-on-asp-net-core-with-javascriptservices/

//let toastr: IToastr

@NgModule({
    bootstrap: [ AppComponent ],
    declarations: [
        AppComponent,
        NavMenuComponent,
        HomeComponent,
        LocalComponent,
        PortfolioComponent,
        AdminComponent,
        AppServicesComponent,
        AppServiceSelectorComponent,
        AppServiceDetailComponent

    ],
    providers: [
        AdminService,
        GeoriskAppsService
        
        //{
        //    provide: TOASTR_TOKEN,
        //    useValue: toastr
        //}
    ],
    imports: [
        //BrowserAnimationsModule, // required animations module
        //ToastrModule.forRoot(), // ToastrModule added
        UniversalModule, // Must be first import. This automatically imports BrowserModule, HttpModule, and JsonpModule too.
        FormsModule,
        RouterModule.forRoot([        
            {
                path: 'local',
                component: LocalComponent,
                children: [ {
                                path: 'admin',
                                component: AdminComponent,
                                data:
                                {
                                    appName: 'local-ii'
                                }
                    //,
                    //            children: [{
                    //                    path: 'users',
                    //                    component: UsersComponent,
                    //                    data:
                    //                    {
                    //                        appName: 'local-ii'
                    //                    }
                    //            },
                    //            //{
                                //        path: 'new',
                                //        component: NewUserComponent,
                                //        data:
                                //        {
                                //            appName: 'local-ii'
                                //        }
                                //    }
                                //]
                                
                            },
                            
                            {
                                path: 'services',
                                component: AppServicesComponent,
                                data:
                                {
                                    appName: 'local'
                                }
                            }
                ]
            },
            {
                path: 'portfolio',
                component: PortfolioComponent,
                children: [{
                    path: 'admin',
                    component: AdminComponent,
                    data:
                    {
                        appName: 'portfolio'
                    }
                    //children: [{
                    //    path: 'users',
                    //    component: UsersComponent,
                    //    data:
                    //    {
                    //        appName: 'portfolio'
                    //    }
                    //},
                    //{
                    //    path: 'new',
                    //    component: NewUserComponent,
                    //    data:
                    //    {
                    //        appName: 'portfolio'
                    //    }
                    //}
                    //]
                }, {
                        path: 'services',
                        component: AppServicesComponent,
                        data: {
                            appName: 'portfolio'
                        }
                }]
            },          
            { path: '**', redirectTo: 'home' }
        ], { enableTracing: false })
    ]
})
export class AppModule {

}
