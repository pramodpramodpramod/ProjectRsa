using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GeoRisk_AdminTool.Models.admin;

namespace GeoRisk_AdminTool.Controllers.admin
{
    //for stored procedures...
    //https://docs.microsoft.com/en-us/ef/core/querying/raw-sql

    //Getting started...
    //https://docs.microsoft.com/en-us/aspnet/core/data/ef-mvc/intro

    [Produces("application/json")]
    [Route("api/Applications")]
    public class ApplicationsController : Controller
    {
        private readonly adminContext _context;

        public ApplicationsController(adminContext context)
        {
            _context = context;
        }

        // GET: api/Applications
        [HttpGet]
        public IEnumerable<AspnetApplications> GetAspnetApplications()
        {
            return _context.AspnetApplications;
        }

        // GET: api/Applications/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetAspnetApplications([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var aspnetApplications = await _context.AspnetApplications.SingleOrDefaultAsync(m => m.ApplicationId == id);

            if (aspnetApplications == null)
            {
                return NotFound();
            }

            return Ok(aspnetApplications);
        }

        // PUT: api/Applications/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAspnetApplications([FromRoute] Guid id, [FromBody] AspnetApplications aspnetApplications)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != aspnetApplications.ApplicationId)
            {
                return BadRequest();
            }

            _context.Entry(aspnetApplications).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AspnetApplicationsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Applications
        [HttpPost]
        public async Task<IActionResult> PostAspnetApplications([FromBody] AspnetApplications aspnetApplications)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.AspnetApplications.Add(aspnetApplications);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAspnetApplications", new { id = aspnetApplications.ApplicationId }, aspnetApplications);
        }

        // DELETE: api/Applications/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAspnetApplications([FromRoute] Guid id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var aspnetApplications = await _context.AspnetApplications.SingleOrDefaultAsync(m => m.ApplicationId == id);
            if (aspnetApplications == null)
            {
                return NotFound();
            }

            _context.AspnetApplications.Remove(aspnetApplications);
            await _context.SaveChangesAsync();

            return Ok(aspnetApplications);
        }

        private bool AspnetApplicationsExists(Guid id)
        {
            return _context.AspnetApplications.Any(e => e.ApplicationId == id);
        }
    }
}