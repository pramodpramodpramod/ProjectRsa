﻿using System;
using System.Collections.Generic;

namespace GeoRisk_AdminTool.Models.admin
{
    public partial class Sessions
    {
        public string SessionId { get; set; }
        public DateTime Created { get; set; }
        public DateTime Expires { get; set; }
        public DateTime LockDate { get; set; }
        public int LockCookie { get; set; }
        public bool Locked { get; set; }
        public byte[] SessionItem { get; set; }
        public int Flags { get; set; }
        public int Timeout { get; set; }
    }
}
