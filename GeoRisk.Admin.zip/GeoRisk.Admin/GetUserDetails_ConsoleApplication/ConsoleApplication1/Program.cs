﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
   public class ADPropValue {
        public string propertyName { get; set; }
        public string value { get; set; }
       public ADPropValue(string propertyName, string value) {
            this.value = value;
            this.propertyName = propertyName;
        }
    }
    class Program
    {
        public static List<string> failed = new List<string>();
        static void Main(string[] args)
        {
            var path = args[0];
            string line;
            List<string> theResult = new List<string>();
            // Read the file and display it line by line.
            using (StreamReader file = new StreamReader(path))
            {
                while ((line = file.ReadLine()) != null)
                {

                    char[] delimiters = new char[] { '\t' };
                    string[] parts = line.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                    var result = GetActiveDirectoryUser(parts[1]);
                    if (result != null)
                    {
                        List<ADPropValue> adProps = new List<ADPropValue>();
                        theResult.Add(
                            parts[1] + ", " +
                            (result.Properties["displayname"] != null ? result.Properties["displayname"][0].ToString() : "") + ", " +
                            (result.Properties["mail"] != null ? result.Properties["mail"][0].ToString() : ""));
                            //+", "+
                            //(result.Properties["department"] != null ? result.Properties["department"][0].ToString():"") + ", " +
                            //(result.Properties["title"] != null ? result.Properties["title"][0].ToString():""));

                        //foreach (DictionaryEntry item in result.Properties)
                        //{


                        //    Console.WriteLine("{0} = {1}", item.Key, item.Value);
                        //    string key = item.Key.ToString();
                        //    ResultPropertyValueCollection values = result.Properties[key];
                        //    var value = values[0].ToString();

                        //    adProps.Add(new ADPropValue(key, value));

                        //}

                        //    for (int i = 0; i < adProps.Count; i++)
                        //    {
                        //        if (adProps[i].propertyName == "mail")
                        //            theResult.Add(adProps[i].value);
                        //    }

                    }

                }

                file.Close();
            }
            using (System.IO.StreamWriter file =
          new System.IO.StreamWriter(args[1], true))
            {
                file.WriteLine("Opd, Displayname, Email, Department, Title");
                foreach (var item in theResult)
                {
                    file.WriteLine(item);
                }
                file.WriteLine("--Removed users--");
                foreach (var item in failed)
                {
                    file.WriteLine(item);
                }
            }

            // Suspend the screen.
            Console.ReadLine();
        }

        private static SearchResult GetActiveDirectoryUser(string searchName)
        {
            System.DirectoryServices.SearchResult result = null;
           

            string[] searchNameSplit = searchName.Split('\\');

            if (searchNameSplit.Count() == 2)
            {
                string activeDirectoryQuery;
                if (searchNameSplit[0].ToUpper() == "ACTDIR")
                {
                    //for ACTDIR we can just search with the full name, domain\fullname
                    activeDirectoryQuery =
                        string.Format("(&(objectCategory=user)(objectClass=user)(sAMAccountName={0}))",
                                      searchNameSplit[1]);
                }
                else
                {
                    activeDirectoryQuery = string.Format("(&(objectCategory=user)(objectClass=user)(uid={0}))",
                                                         searchName.Replace("\\", "\\5C"));
                    //activeDirectoryQuery = string.Format("(&(objectCategory=user)(objectClass=user)(uid={0}))",
                    //                                     searchNameSplit[1]);
                }
                List<string> domains = new List<string>() { "OPD", "DOMAIN", "MGA", "IAA", "ADEP01", "IE.RSA-INS.COM", "ACTDIR", "NHODOM01","" };
                foreach (var item in domains)
                {
                    
                    using (DirectoryEntry entry = GetDirectoryObject(item))
                    {

                        using (DirectorySearcher searcher = new DirectorySearcher(entry) { ClientTimeout = new TimeSpan(0, 1, 0) })
                        {
                            searcher.Filter = activeDirectoryQuery;
                            try
                            {
                                SearchResultCollection results = searcher.FindAll();
                                result = (results.Count != 0) ? results[0] : null;
                                if (result == null)
                                {
                                    throw new Exception("Try searching with email.");
                                }

                            }
                            catch (Exception exception)
                            {
                                //throw new Exception("Unable to find user: " + searchName + " with searcher Filter = " + activeDirectoryQuery + " on DirectoryEntry path: " + entry.Path + " ....Further exception: " + exception);
                                //throw new Exception("Unable to find user: " + searchName + " : " + exception.Message);
                                //Console.WriteLine();
                               
                            }
                           if(result!=null)
                                return result;
                        }
                    }
                }

            }
            failed.Add(searchName);
            return result;
        }

        private static DirectoryEntry GetDirectoryObject(string domain)
        {
            if (domain.ToUpper() == "OPD")
            {
                //go the actdir route
                return new DirectoryEntry()
                {
                    Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/OU=USERS,OU=UK,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                }; ;

            }
            if (domain.ToUpper() == "DOMAIN")
            {
                //go the actdir route
                return new DirectoryEntry()
                {
                    Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/OU=USERS,OU=IRE123,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                }; ;

            }
            if (domain.ToUpper() == "MGA")
            {
                //go the actdir route
                return new DirectoryEntry()
                {
                    Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/OU=USERS,OU=MGA,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                }; ;

            }
            if (domain.ToUpper() == "IAA")
            {
                //go the actdir route
                return new DirectoryEntry()
                {
                    Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/OU=USERS,OU=IAA,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                }; ;

            }
            if (domain.ToUpper() == "ADEP01")
            {
                //go the actdir route
                return new DirectoryEntry()
                {
                    Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/OU=USERS,OU=SCANDI,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                }; ;

            }
            if (domain.ToUpper() == "IE.RSA-INS.COM")
            {
                //go the actdir route
                return new DirectoryEntry()
                {
                    Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/OU=Users,OU=IRE,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                }; ;

            }
            //"CN=PaulWhite,OU=Users,OU=Users and Computers,OU=USERS,OU=IRE,DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM"
            if (domain.ToUpper() == "ACTDIR")
            {
                //go the actdir route
                return new DirectoryEntry("LDAP://hor-ad-m01.actdir.rsa-ins.com/OU=External Users,DC=ACTDIR,DC=RSA-INS,DC=COM");

            }
            if (domain.ToUpper() == "NHODOM01")
            {
                //these are the UK GCC servers, either one will allow us to check the Canadian AD and stay within firewall rules
                //hor-uds-ads-v04.can.gbl.uds.rsa-ins.com[10.111.41.220]
                //lxw-uds-ads-v04.can.gbl.uds.rsa-ins.com[10.114.144.34]
                return new DirectoryEntry()
                {
                    //Path = "LDAP://can.gbl.uds.rsa-ins.com/DC=CAN,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    Path = "LDAP://hor-uds-ads-v04.can.gbl.uds.rsa-ins.com/OU=User Mailboxes,OU=Exchange Mailboxes,OU=UDS-CAN,DC=CAN,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                    AuthenticationType = AuthenticationTypes.Secure,
                    //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                    //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
                };
            }
            //go the uds route 
            return new DirectoryEntry()
            {
                Path = "LDAP://hor-uds-ads-v03.eur.gbl.uds.rsa-ins.com/DC=EUR,DC=GBL,DC=UDS,DC=RSA-INS,DC=COM",
                AuthenticationType = AuthenticationTypes.Secure,
                //Username = ConfigurationManager.AppSettings["ActiveDirectoryUser"],
                //Password = ConfigurationManager.AppSettings["ActiveDirectoryPass"]
            };

        }
    }
}
